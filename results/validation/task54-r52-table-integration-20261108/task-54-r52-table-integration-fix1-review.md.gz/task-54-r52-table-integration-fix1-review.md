# R52 table integration fix1 scoped independent re-review

Date: 2026-11-08.

SPEC: **PASS**.
QUALITY: **PASS**.
Prior P2 projection-only finding: **ADDRESSED**. No fix-induced actionable finding in this bounded scope.

## Reviewed correction

Reviewed the fix1 report's original 12 projection-only RED errors, correction narrative, exact prior-candidate diff, final test claims, actual changed source and added tests. The immutable deployed queue source remains SHA256 `1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9`; its lines 298-310 write projection.txt before deciding whether a stop can occur.

- `tools/paper_tables.py:563-575` now validates an optional projection observation independently of partial-stop evidence. A below-limit or above-limit projection alone does not force partial classification. Its original bytes/hash and line 1 source attribution are retained.
- Actual partial.txt, partial-identities.json, or a partial queue state still require the complete coherent stop trio. Missing/malformed projection, wrong limit, incomplete stop files and partial state without stop evidence remain rejected.
- The producer-compatible rounding tolerance and queue output-validation override are unchanged. Coherent failed/watchdog outputs remain unmeasured; successful intake still requires all prior terminal/digest/provenance/scientific-field checks.
- The added positive test covers both jobs, below/above-limit projections, success, ordinary failure and watchdog (12 subcases), checking row outcome, original bytes, hash and source attribution. Negative fixtures invoke the selected job reader directly so a different malformed job cannot supply a false-positive rejection.

I reversed only the reported two source hunks and removed only the two new test methods **in memory**. The resulting SHA256 values exactly equal the prior reviewed candidates. This confirms the source changes are limited to the reported P2 correction and affected tests; no other code was silently altered. The original author report and prior review hashes are unchanged.

## Exact identities and scope verification

Read-only Python SHA256/byte inventory and in-memory reversal comparison completed with exit 0 and empty stderr:

```jsonl
{"reverse_in_memory_only":true,"prior_source_sha256":"8ea48895c062dc96c4ab00e15a393ae4c701f4072dc92afa994ffbd4696e1d1d","prior_test_sha256":"02e5e75239ab6b4211a22fbaca95649865b227286e4143f53dc034cf90e346b8","exact_reported_changes_only":true}
{"source":"tools/paper_tables.py","bytes":84060,"sha256":"10c1425caf4e8ff7c0903fdbc020c2ed5790ce36620466f237292ce711bba67d"}
{"source":"tools/test_paper_tables.py","bytes":50235,"sha256":"2f0c88435f7552d40a0f2fc9c9a456189c1e9a532bb2b159a85681205b3b70b1"}
{"source":".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-fix1-report.md","bytes":46657,"sha256":"58b1cb4a247394c1921b19d9a8a40e527673ad0a8e69b8553d6ade6390deee32"}
{"source":".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-report.md","bytes":171788,"sha256":"95646f17d1dab8473a2ba9903741e867a398fd2dddd179b2db04682064b06077"}
{"source":".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-review.md","bytes":18217,"sha256":"96cb8715e2a99ef1e62bad8329a2fa564cc4c6d0cca9322c8ed9150bbf76bbe8"}
{"source":"results/quadruped/scripts/post_full_queue.py","bytes":23840,"sha256":"1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9"}
```

The in-memory reversal replaced the new projection/partial decision and source-attribution hunks with their old text from the retained diff, and removed the two contiguous added test methods. It wrote no source file.

## Independent focused validation

All subprocesses inherited `PYTHONDONTWRITEBYTECODE=1` and used a 60-second timeout. The focused suite passed 36 methods, including the prior R47/R52 cases and the new projection-only branches. Both real-root check-only entrypoints and diff whitespace check passed. Exact raw command outputs:

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 36 tests in 4.492s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `git diff --check fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout:
```text
```

stderr:
```text
```

## Limitations

This is a scoped source/synthetic re-review of P2 and affected regressions, not a fresh broad producer audit, real R52 experiment, historical execution proof, native/scientific acceptance or whole Task54 completion. Prior producer/schema review and its limitations remain applicable. The author RED was read from the retained report; it was not rerun by changing production source. No source/Git mutation, Rust/Cargo/native/SSH/GPU/HE work, actual result/generated-table write, PDF layout check or subagent work occurred. Only this review report was written persistently.

