# R52 concise manuscript hash-note fix2

Presentation-only correction against frozen fix1 source10c1425caf4e8ff7c0903fdbc020c2ed5790ce36620466f237292ce711bba67d and tests2f0c88435f7552d40a0f2fc9c9a456189c1e9a532bb2b159a85681205b3b70b1. No numerical/provenance acceptance change. Original reports retained.

## Test-first RED

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ERROR
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ERROR
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 786, in test_explicit_tex_note_override_keeps_markdown_default_and_sources
    table.note(full, [('synthetic/input', 'raw bytes')], tex_text='SYNTHETIC concise manuscript note')
    ~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
TypeError: Table.note() got an unexpected keyword argument 'tex_text'

======================================================================
ERROR: test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 809, in test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes
    overridden = [note for note in table.notes if note.tex_text is not None]
                                                  ^^^^^^^^^^^^^
AttributeError: 'Cell' object has no attribute 'tex_text'

----------------------------------------------------------------------
Ran 38 tests in 4.642s

FAILED (errors=2)
```

## Implementation and verification scope

Added optional Cell/Note tex_text with default None. Only the LaTeX note renderer uses a supplied override; Markdown keeps the full original text and source_lines retains every original source pair. The only production override supplied is the R52 captured original/source SHA inventory note, for both accepted and unmeasured R52 outcomes. The concise manuscript text accurately directs readers to results/tables/accuracy_vs_reboot.md for full hashes and results/tables/sources.tsv for source fields. It states captured/current byte identity rather than historical execution or consumed-input proof. Numerical/coverage/seed/handoff/precondition notes, all validators and the R47 functions remain unchanged. No TeX package, margins, fonts, data or provenance schema was changed.

The root's marked synthetic preflight manifest records nine overflow boxes (maximum99.72386pt), with page7 clipping R52 inventory paragraphs. This worker read that manifest; it did not rebuild/render a PDF. Root will separately rebuild and visually inspect the marked synthetic PDF after this source freeze. This is not an actual-result PDF or publication.

Only the two owned Python files plus this separate report were written. All previous author/review/fix1 reports were retained. Tests/byte comparisons used temporary clearly synthetic input/output objects; no real result JSON, generated repository table, Git mutation, native/Cargo/SSH/HE/GPU or subagent work occurred.

## GREEN / focused regressions / current check-only outputs

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 38 tests in 4.681s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `git diff --check fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

## Independent fix1/fix2 populated-artifact byte comparison

A second stdlib-only harness loaded the captured exact fix1 Python source into an isolated in-memory module (no source file writes), built the same temporary synthetic eMLP2/eMLP3 success and failed cases with both versions, and asserted exact Markdown and source_lines equality. It also asserted the populated synthetic R47 TeX is identical. Baseline module source SHA256: `10c1425caf4e8ff7c0903fdbc020c2ed5790ce36620466f237292ce711bba67d`. Exit0; stderr empty; comparison output:

```json
[
  {
    "state": "successful",
    "md_byte_identical_to_fix1": true,
    "source_index_identical_to_fix1": true,
    "md_sha256": "2566d87ee0f0df1843a75115b46b4e1bfe1ab95bed32221b6009248efada9223"
  },
  {
    "state": "failed",
    "md_byte_identical_to_fix1": true,
    "source_index_identical_to_fix1": true,
    "md_sha256": "0c5bf042b88e9ce1391518127d5fe93e502e2f35c8bb7f721a8ecc8649776000"
  },
  {
    "R47_synthetic_populated_tex_identical_to_fix1": true
  }
]
```

## Preserved source functions

- `r52_input`: exact source unchanged from frozen fix1.
- `read_r52_input`: exact source unchanged from frozen fix1.
- `r47_batch_input`: exact source unchanged from frozen fix1.
- `table_gpu`: exact source unchanged from frozen fix1.
- `source_lines`: exact source unchanged from frozen fix1.
- `render_md`: exact source unchanged from frozen fix1.

## Final pins and exact diff against frozen fix1

- `tools/paper_tables.py`: fix1 SHA256 `10c1425caf4e8ff7c0903fdbc020c2ed5790ce36620466f237292ce711bba67d`; fix2 SHA256 `2eb7f241d0bc6302ad5d1892ab3bb1980120d92787c76cf70f0c15fef85da1c1`.

```diff
--- frozen-fix1/tools/paper_tables.py
+++ fix2/tools/paper_tables.py
@@ -60,10 +60,11 @@
 class Cell:
     """A rendered value and the (file, field) pairs it was computed from."""
 
-    def __init__(self, text, sources=(), formula=''):
+    def __init__(self, text, sources=(), formula='', tex_text=None):
         self.text = text
         self.sources = list(sources)
         self.formula = formula
+        self.tex_text = tex_text
 
 
 def plain(text):
@@ -157,8 +158,8 @@
         require(len(cells) == len(self.columns), f'{self.name}: row width {len(cells)} != {len(self.columns)}')
         self.rows.append(('row', cells))
 
-    def note(self, text, sources=()):
-        self.notes.append(Cell(text, sources))
+    def note(self, text, sources=(), tex_text=None):
+        self.notes.append(Cell(text, sources, tex_text=tex_text))
 
 
 # ---------------------------------------------------------------------------------------------
@@ -843,7 +844,10 @@
                    'Scientific acceptance and handoff-precondition interpretation remain separate review.', src)
         t.note(f'{key} captured original/source SHA256 (not historical execution proof): ' +
                '; '.join(f'{path} = {hashlib.sha256(raw).hexdigest()}' for path, raw in result['raw'].items()),
-               [(path, 'raw bytes (SHA256 at table generation)') for path in result['raw']])
+               [(path, 'raw bytes (SHA256 at table generation)') for path in result['raw']],
+               tex_text=f'{key}: Full captured/current byte hashes: results/tables/accuracy_vs_reboot.md; '
+                        'source fields: results/tables/sources.tsv. These identify captured/current bytes, '
+                        'not historical execution or consumed-input proof.')
     t.section('Reference only: the paper value and the released code at the paper setting (R-REB-3)')
     paper, ps = s.num(TASK51['mnist'][0], 'target.test_acc_mean')
     paper_sd, pss = s.num(TASK51['mnist'][0], 'target.test_acc_std')
@@ -1314,7 +1318,7 @@
     out += [r'\bottomrule', r'\end{tabular}}']
     if t.notes:
         out.append(r'\par\smallskip\begin{minipage}{\linewidth}\scriptsize')
-        out += [tex_prose(n.text) + r'\par' for n in t.notes]
+        out += [tex_prose(n.tex_text if n.tex_text is not None else n.text) + r'\par' for n in t.notes]
         out.append(r'\end{minipage}')
     out.append(f'\\end{{{env}}}')
     return '\n'.join(out) + '\n'
```
- `tools/test_paper_tables.py`: fix1 SHA256 `2f0c88435f7552d40a0f2fc9c9a456189c1e9a532bb2b159a85681205b3b70b1`; fix2 SHA256 `8cf932dd06c41c3405c62db2361ef78ece5ae649b41cfe3c72c2b62130d345c5`.

```diff
--- frozen-fix1/tools/test_paper_tables.py
+++ fix2/tools/test_paper_tables.py
@@ -778,6 +778,59 @@
         s=tables.Store(self.root)
         with self.assertRaises(tables.TableError):tables.table_accuracy(s,tables.Inputs(s,'full'))
 
+    def test_explicit_tex_note_override_keeps_markdown_default_and_sources(self):
+        # Break caught: a manuscript-only summary must not replace the inspectable original note/source index.
+        table = tables.Table('synthetic_note', 'SYNTHETIC note test', ['Value'])
+        table.row(['synthetic'])
+        full = 'SYNTHETIC full hash ' + 'a'*64 + '; not historical execution proof'
+        table.note(full, [('synthetic/input', 'raw bytes')], tex_text='SYNTHETIC concise manuscript note')
+        table.note('SYNTHETIC ordinary default note', [('synthetic/input', 'field')])
+        md = tables.render_md(table, 'synthetic/')
+        tex = tables.render_tex(table, 'synthetic/')
+        self.assertIn(full, md)
+        self.assertNotIn('concise manuscript', md)
+        self.assertIn('SYNTHETIC concise manuscript note', tex)
+        self.assertNotIn('a'*64, tex)
+        self.assertIn('SYNTHETIC ordinary default note', md)
+        self.assertIn('SYNTHETIC ordinary default note', tex)
+        self.assertIsNone(table.notes[1].tex_text)
+        self.assertEqual(tables.source_lines(table), [
+            'synthetic_note\tnote 1\t\t\tsynthetic/input\traw bytes\t',
+            'synthetic_note\tnote 2\t\t\tsynthetic/input\tfield\t'])
+
+    def test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes(self):
+        # Break caught: long source-path/SHA inventories clip the paper; all acceptance caveats must remain.
+        digests = []
+        for number in (2, 3):
+            dest, _ = put_r52(self.root, number)
+            digests.append(hashlib.sha256(dest.read_bytes()).hexdigest())
+        table = self.build(tables.table_accuracy)
+        md, tex = tables.render_md(table, 'synthetic/'), tables.render_tex(table, 'synthetic/')
+        overridden = [note for note in table.notes if note.tex_text is not None]
+        self.assertEqual(len(overridden), 2)
+        self.assertTrue(all('captured original/source SHA256' in note.text for note in overridden))
+        for digest in digests:
+            self.assertIn(digest, md)
+            self.assertNotIn(digest, tex)
+        self.assertIn('not historical execution proof', md)
+        self.assertIn('results/tables/accuracy_vs_reboot.md', overridden[0].tex_text)
+        self.assertIn('results/tables/sources.tsv', overridden[0].tex_text)
+        self.assertIn('captured/current bytes', tex)
+        self.assertIn('not historical execution or consumed-input proof', tex)
+        for caveat in ('21 updates; 1008 samples', 'RNG32', 'not independent seeds',
+                       'compared 64512 valid-sample/width slots', 'precondition hit false',
+                       'not historical input-byte proof'):
+            self.assertIn(caveat, tex)
+        sources = tables.source_lines(table)
+        for note in overridden:
+            note.tex_text = None
+        self.assertEqual(sources, tables.source_lines(table))
+        self.assertTrue(all(note.tex_text is None for note in self.build(tables.table_gpu).notes))
+        # The same concise inventory treatment applies to an unmeasured failed original.
+        put_r52(self.root, 2, rc=1, output=False)
+        failed = self.build(tables.table_accuracy)
+        self.assertEqual(len([note for note in failed.notes if note.tex_text is not None]), 2)
+
     def test_r52_error_atomicity_quick_and_both_entrypoints(self):
         # Break caught: partial paper writes, quick contamination, or entrypoint divergence.
         dest,archive=put_r52(self.root);(archive/'post.txt').write_text('JOB_DONE rc=1\n')
```

## Retained evidence identities

- `task-54-r52-table-integration-report.md`: 171788 bytes; SHA256 `95646f17d1dab8473a2ba9903741e867a398fd2dddd179b2db04682064b06077`.
- `task-54-r52-table-integration-review.md`: 18217 bytes; SHA256 `96cb8715e2a99ef1e62bad8329a2fa564cc4c6d0cca9322c8ed9150bbf76bbe8`.
- `task-54-r52-table-integration-fix1-report.md`: 46657 bytes; SHA256 `58b1cb4a247394c1921b19d9a8a40e527673ad0a8e69b8553d6ade6390deee32`.
- `task-54-r52-table-integration-fix1-review.md`: 11220 bytes; SHA256 `c8f8aaa50304bd58cb4359df560c9ed95b25bba0ef5783dcc1a6661bdc659b3e`.
- `task-54-r52-table-integration-fix2-brief.md`: 2820 bytes; SHA256 `69028ffd3c008e5296403bfba874044abb39fc8247785645985311bc9c8c8a70`.
- `task-54-r52-layout-preflight.json`: 1829 bytes; SHA256 `259c6ca40c65f45204341a6fb44f7a171fe81e661166c6af1e805b9ec3689543`.

## Handoff

38 focused tests and both real-root check-only entrypoints pass, with no unresolved focused failure. Full hashes/warnings remain byte-identical in populated synthetic Markdown; source attribution and R47 TeX remain identical. Source/behavior verification is complete for this finite presentation change; root PDF rebuild/render inspection and independent review remain pending. No measurement, scientific acceptance, full Task54 completion or PDF publication is claimed.
