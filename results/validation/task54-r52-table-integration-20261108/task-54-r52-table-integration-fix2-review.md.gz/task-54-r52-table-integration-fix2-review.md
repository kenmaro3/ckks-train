# R52 table integration fix2 scoped independent review

Date: 2026-11-08.

SPEC: **PASS** for the finite presentation/source change.
QUALITY: **PASS** for the same scope.
No actionable finding. This verdict does not itself establish that a rendered PDF has no overflow; root's independent marked-synthetic PDF rebuild/visual inspection is separate.

## Reviewed change

Read the fix2 brief, retained RED/GREEN report, exact diff against frozen fix1, actual note/Cell/renderer changes, added regression tests and prior fix1 source verdict.

- Cell gains optional `tex_text=None`, and Table.note forwards it. Only the LaTeX note renderer consults this field; default note rendering follows the previous text path. Explicit note overrides still pass through the existing `tex_prose` escaping, so no raw TeX injection or new package/font/margin dependency was introduced.
- The sole production override is the long R52 captured-original/source hash inventory note. Both success and unmeasured outcomes get the concise TeX wording. It accurately directs readers to accuracy_vs_reboot.md for complete hashes and sources.tsv for source fields, without claiming that sources.tsv contains hash values.
- The concise note retains the captured/current byte versus historical execution/consumed-input proof distinction. Numerical, coverage, seed, handoff and precondition caveats remain unchanged; full hash inventory and warnings remain in Markdown, with all source pairs retained.
- No R52 validation, failure/success classification, partial/projection handling, source digest checks, R47 functions or other rendered-note defaults changed. Reversing only the four reported source hunks in memory yields exact frozen fix1 SHA256; removing only the two added tests yields exact fix1 test SHA256.

## Independent bounded checks

The full focused table suite passed **38 methods**. Both real-root check-only entrypoints and the scoped whitespace check passed. No actual output was generated.

An independent temporary synthetic harness loaded reconstructed exact fix1 source into an in-memory module, built eMLP2/eMLP3 success and child-1 failure cases with both versions, and compared actual Markdown strings, source-line arrays, and populated R47 TeX. They are exactly equal. The two new tests separately exercise the optional override/default paths and the R52 concise-only-in-TeX behavior while retaining caveats and original attribution.

All subprocesses inherited `PYTHONDONTWRITEBYTECODE=1` and had 60-second timeouts. Original source files were never rewritten. Exact source identities and comparison output:

```jsonl
{"reversed_in_memory":"tools/paper_tables.py","prior_sha256":"10c1425caf4e8ff7c0903fdbc020c2ed5790ce36620466f237292ce711bba67d","exact_reported_changes_only":true}
{"reversed_in_memory":"tools/test_paper_tables.py","prior_sha256":"2f0c88435f7552d40a0f2fc9c9a456189c1e9a532bb2b159a85681205b3b70b1","exact_reported_changes_only":true}
{"child_exit":0,"populated_R52_Markdown_identical":true,"populated_sources_identical":true,"populated_R47_TeX_identical":true}
{"child_exit":1,"populated_R52_Markdown_identical":true,"populated_sources_identical":true,"populated_R47_TeX_identical":true}
{"source":"tools/paper_tables.py","bytes":84478,"sha256":"2eb7f241d0bc6302ad5d1892ab3bb1980120d92787c76cf70f0c15fef85da1c1"}
{"source":"tools/test_paper_tables.py","bytes":53515,"sha256":"8cf932dd06c41c3405c62db2361ef78ece5ae649b41cfe3c72c2b62130d345c5"}
{"source":".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-fix2-report.md","bytes":26445,"sha256":"74b97dbef16123dc66ab8ee2e53c45d6d58b62637b3c19f668db505e6722f654"}
{"source":".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-fix2-brief.md","bytes":2820,"sha256":"69028ffd3c008e5296403bfba874044abb39fc8247785645985311bc9c8c8a70"}
{"source":".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-fix1-review.md","bytes":11220,"sha256":"c8f8aaa50304bd58cb4359df560c9ed95b25bba0ef5783dcc1a6661bdc659b3e"}
```

## Verification harness

The following complete command ran with exit 0 and empty stderr; its structured comparison/identity output is above, and subprocess transcripts are below:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 - <<'PY'
import re,hashlib,json,types,sys,tempfile,subprocess,ast
from pathlib import Path
l=Path('.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5')
report=(l/'task-54-r52-table-integration-fix2-report.md').read_text()
blocks=re.findall(r'```diff\n(.*?)\n```',report,re.S)
restored={}
for block,path,expected in zip(blocks,('tools/paper_tables.py','tools/test_paper_tables.py'),('10c1425caf4e8ff7c0903fdbc020c2ed5790ce36620466f237292ce711bba67d','2f0c88435f7552d40a0f2fc9c9a456189c1e9a532bb2b159a85681205b3b70b1')):
 current=Path(path).read_text(); previous=current
 for hunk in re.split(r'^@@[^\n]*\n',block,flags=re.M)[1:]:
  lines=hunk.splitlines(keepends=True)
  # A final fenced diff line is stored without its last newline by the regex.
  if lines and not lines[-1].endswith('\n'): lines[-1]+='\n'
  old=''.join(line[1:] for line in lines if line.startswith((' ','-')))
  new=''.join(line[1:] for line in lines if line.startswith((' ','+')))
  assert previous.count(new)==1,(path,new[:80])
  previous=previous.replace(new,old,1)
 digest=hashlib.sha256(previous.encode()).hexdigest(); assert digest==expected,(path,digest)
 restored[path]=previous
 print(json.dumps({'reversed_in_memory':path,'prior_sha256':digest,'exact_reported_changes_only':True}))
sys.path.insert(0,'tools')
import paper_tables as current
from test_paper_tables import archived_overlay,put_r52,put_r47
old=types.ModuleType('fix1_review_baseline');old.__file__=str(Path('tools/paper_tables.py').resolve())
exec(compile(restored['tools/paper_tables.py'],old.__file__,'exec'),old.__dict__)
for rc in (0,1):
 with tempfile.TemporaryDirectory(prefix='synthetic-r52-fix2-review-') as tmp:
  root=Path(tmp);archived_overlay(root)
  for number in (2,3):put_r52(root,number=number,rc=rc)
  put_r47(root)
  outputs=[]
  for module in (old,current):
   store=module.Store(root);inp=module.Inputs(store);table=module.table_accuracy(store,inp)
   outputs.append((module.render_md(table,'synthetic/'),module.source_lines(table),module.render_tex(module.table_gpu(store,inp),'synthetic/')))
  assert outputs[0]==outputs[1]
  print(json.dumps({'child_exit':rc,'populated_R52_Markdown_identical':True,'populated_sources_identical':True,'populated_R47_TeX_identical':True}))
for path in ('tools/paper_tables.py','tools/test_paper_tables.py',str(l/'task-54-r52-table-integration-fix2-report.md'),str(l/'task-54-r52-table-integration-fix2-brief.md'),str(l/'task-54-r52-table-integration-fix1-review.md')):
 raw=Path(path).read_bytes();print(json.dumps({'source':path,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}))
for cmd in (['python3','-m','unittest','discover','-s','tools','-p','test_paper_tables.py','-v'],['python3','tools/paper_tables.py','--check'],['python3','tools/tables.py','--check'],['git','diff','--check','fb54f2f356755a946008a2f1d26757365101b81f','--','tools/paper_tables.py','tools/test_paper_tables.py']):
 p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
 print(json.dumps({'argv':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr}))
PY
```

## Raw subprocess transcripts

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 38 tests in 4.675s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `git diff --check fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout:
```text
```

stderr:
```text
```

## Limits

This is source, renderer-string and synthetic Python validation, not a PDF visual inspection, actual experiment, historical result acceptance or publication. Root reported the earlier synthetic overflow and is independently rebuilding the marked synthetic PDF; no PDF overflow count or clipping claim is made by this reviewer. Previous scientific/measurement limitations remain unchanged. No Git/source mutation, Rust/Cargo/native/SSH/GPU/HE work, actual-data or generated-root-output writes, or subagents were used. Only this review report was written persistently.

