# R52 projection-only intake fix1

Prior candidate: paper_tables.py SHA8ea48895c062dc96c4ab00e15a393ae4c701f4072dc92afa994ffbd4696e1d1d; test_paper_tables.py SHA02e5e75239ab6b4211a22fbaca95649865b227286e4143f53dc034cf90e346b8. Root review SHA96cb8715e2a99ef1e62bad8329a2fa564cc4c6d0cca9322c8ed9150bbf76bbe8. Prior author report remains unchanged.

## Test-first RED

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... 
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=0, watchdog=False, projected=10000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=0, watchdog=False, projected=50000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=1, watchdog=False, projected=10000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=1, watchdog=False, projected=50000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=143, watchdog=True, projected=10000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=143, watchdog=True, projected=50000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=0, watchdog=False, projected=10000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=0, watchdog=False, projected=50000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=1, watchdog=False, projected=10000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=1, watchdog=False, projected=50000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=143, watchdog=True, projected=10000) ... ERROR
  test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=143, watchdog=True, projected=50000) ... ERROR
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=0, watchdog=False, projected=10000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=0, watchdog=False, projected=50000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=1, watchdog=False, projected=10000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=1, watchdog=False, projected=50000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=143, watchdog=True, projected=10000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=2, rc=143, watchdog=True, projected=50000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=0, watchdog=False, projected=10000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=0, watchdog=False, projected=50000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=1, watchdog=False, projected=10000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=1, watchdog=False, projected=50000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=143, watchdog=True, projected=10000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

======================================================================
ERROR: test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) (number=3, rc=143, watchdog=True, projected=50000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs
    t = self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 809, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 565, in read_r52_input
    check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: incomplete original partial evidence

----------------------------------------------------------------------
Ran 36 tests in 4.665s

FAILED (errors=12)
```

## Finite correction

The original queue writes projection.txt before its stop decision. The old consumer incorrectly treated that observation as stop evidence. The reader now validates and retains any optional projection observation independently, then treats only partial.txt, partial-identities.json, or a partial terminal state as a reason to require the complete coherent stop trio. Even a projection above the registered limit does not establish that the queue had a time.pid or successfully performed stop handling. Terminal state, child status, watchdog and result acceptance continue to determine success/failure. Projection-only bytes and their line1 attribution are retained in both successful and failed rows without claiming a stop.

The exact registered projection format and limit are still checked. Actual partial-stop records still require matching partial/projection text, original string/null process identities, rounded-projection consistency and coherent terminal state. Prior rounding and post-child0 output-rejection guards remain unchanged. The new negative cases call the real registered-job reader directly so a malformed prior job cannot make a different job's negative case pass accidentally.

Only the two owned Python files and this separate report were written. The original 171788-byte author report and the final independent review remain byte-identical. There was no R48, scientific gate, queue/producer, source input, real result, generated table, Git mutation, native/Cargo/SSH/GPU/HE work or subagent work. Populated cases are tiny synthetic temporary fixtures, not measurements.

## GREEN / focused regressions / check-only verification

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 36 tests in 4.601s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `git diff --check fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

## Final source hashes and diff against prior reviewed candidate

- `tools/paper_tables.py`: prior candidate SHA256 `8ea48895c062dc96c4ab00e15a393ae4c701f4072dc92afa994ffbd4696e1d1d`; final SHA256 `10c1425caf4e8ff7c0903fdbc020c2ed5790ce36620466f237292ce711bba67d`.

```diff
--- prior-reviewed-candidate/tools/paper_tables.py
+++ fix1/tools/paper_tables.py
@@ -560,13 +560,19 @@
     check(watchdog or not any(line.startswith('WATCHDOG:') for line in log.splitlines()), 'watchdog contradiction')
     skips = [line for line in log.splitlines() if 'SKIP' in line]
     check(state.get('skip') is bool(skips) and state.get('skip_lines') == skips, 'inconsistent skip record')
-    partial = any(present(rel) for rel in partial_paths)
+    # The queue writes a projection observation before deciding whether it can stop.
+    # Even an above-limit projection alone does not establish partial_stopped.
+    projection = None
+    if present(partial_paths[1]):
+        projection = re.fullmatch(r'after 5 updates: (\d+) s / 21 updates; limit ([0-9.]+) s\n?',
+                                  text(partial_paths[1]))
+        check(projection is not None and float(projection[2]) == (12240.0 if number == 2 else 23040.0) and
+              math.isfinite(float(projection[1])), 'invalid original projection observation')
+    partial = present(partial_paths[0]) or present(partial_paths[2]) or state.get('status') == 'partial'
     if partial:
         check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
         a = re.fullmatch(r'partial: after >=5 updates; projected (\d+) > ([0-9.]+) s\n?', text(partial_paths[0]))
-        b = re.fullmatch(r'after 5 updates: (\d+) s / 21 updates; limit ([0-9.]+) s\n?', text(partial_paths[1]))
-        check(a is not None and b is not None and a.groups() == b.groups() and
-              float(a[2]) == (12240.0 if number == 2 else 23040.0) and
+        check(a is not None and a.groups() == projection.groups() and
               float(a[1]) + 0.5 > float(a[2]), 'inconsistent partial projection')
         # The queue decides with unrounded projection, then prints it to whole seconds.
         identities = json.loads(read(partial_paths[2]), object_pairs_hook=rq1.unique_object)
@@ -589,8 +595,8 @@
     sources += [(state_rel, field) for field in ('rc', 'wrapper_rc', 'status', 'command', 'workdir', 'log')]
     sources += [(post_rel, f'line {terminals[0][0]}'), (cmd_rel, 'line 1')]
     for rel in partial_paths:
-        if partial:
-            sources.append((rel, 'original bytes'))
+        if present(rel):
+            sources.append((rel, 'line 1' if rel == partial_paths[1] else 'original bytes'))
     result = {'sources': sources, 'rel': selected, 'raw': raw,
               'status': 'partial/unmeasured' if partial and not watchdog else 'failed/unmeasured',
               'rc': rc, 'watchdog': watchdog, 'reason': state['status']}
```
- `tools/test_paper_tables.py`: prior candidate SHA256 `02e5e75239ab6b4211a22fbaca95649865b227286e4143f53dc034cf90e346b8`; final SHA256 `2f0c88435f7552d40a0f2fc9c9a456189c1e9a532bb2b159a85681205b3b70b1`.

```diff
--- prior-reviewed-candidate/tools/test_paper_tables.py
+++ fix1/tools/test_paper_tables.py
@@ -671,6 +671,64 @@
         r=next(r for r in rows(self.build(tables.table_accuracy)) if r[0].startswith('hekit encrypted eMLP-2,'))
         self.assertIn('partial/unmeasured',r[3])
 
+    def test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs(self):
+        # Break caught: projection is written before deciding to stop; it is not stop evidence.
+        for number in (2, 3):
+            for rc, watchdog in ((0, False), (1, False), (143, True)):
+                for projected in (10000, 50000):
+                    with self.subTest(number=number, rc=rc, watchdog=watchdog, projected=projected):
+                        dest, archive = put_r52(self.root, number, rc=rc, watchdog=watchdog)
+                        limit = 12240.0 if number == 2 else 23040.0
+                        projection = f'after 5 updates: {projected} s / 21 updates; limit {limit} s\n'
+                        (archive / 'projection.txt').write_text(projection)
+                        t = self.build(tables.table_accuracy)
+                        r = next(r for r in rows(t) if r[0].startswith(f'hekit encrypted eMLP-{number},'))
+                        if rc:
+                            self.assertIn('failed/unmeasured', r[3])
+                            self.assertEqual(r[4], '—')
+                        else:
+                            self.assertEqual(r[3:5], ['90.00', '90.00'])
+                            self.assertEqual(r[7], 'twin check')
+                        self.assertNotIn('partial/unmeasured', r[3])
+                        sources = '\n'.join(tables.source_lines(t))
+                        self.assertIn(f'raw/R-52/R-52-{number - 1}/projection.txt\tline 1', sources)
+                        self.assertIn(hashlib.sha256(projection.encode()).hexdigest(), tables.render_md(t, 'synthetic/'))
+                        self.assertEqual((archive / 'projection.txt').read_text(), projection)
+
+    def test_r52_projection_and_stop_evidence_must_each_match_original_format(self):
+        # Break caught: fixing projection-only intake must not allow malformed projection or incomplete stops.
+        def read_job(number):
+            store = tables.Store(self.root)
+            return tables.r52_input(store, tables.Inputs(store), f'R-52-{number - 1}')
+
+        for number in (2, 3):
+            limit = 12240.0 if number == 2 else 23040.0
+            for projection in ('synthetic malformed\n',
+                               f'after 4 updates: 10000 s / 21 updates; limit {limit} s\n',
+                               'after 5 updates: 10000 s / 21 updates; limit 1 s\n'):
+                with self.subTest(number=number, projection=projection):
+                    _, archive = put_r52(self.root, number)
+                    (archive / 'projection.txt').write_text(projection)
+                    with self.assertRaises(tables.TableError):
+                        read_job(number)
+            for stop_file in ('partial.txt', 'partial-identities.json'):
+                with self.subTest(number=number, stop_file=stop_file):
+                    _, archive = put_r52(self.root, number, rc=143, partial=True, output=False)
+                    (archive / stop_file).unlink()
+                    with self.assertRaises(tables.TableError):
+                        read_job(number)
+                    for name in ('partial.txt', 'projection.txt', 'partial-identities.json'):
+                        if (archive / name).exists():
+                            (archive / name).unlink()
+            _, archive = put_r52(self.root, number)
+            state = json.loads((archive / 'state.json').read_text())
+            state['status'] = 'partial'
+            (archive / 'state.json').write_text(json.dumps(state))
+            (archive / 'projection.txt').write_text(f'after 5 updates: 50000 s / 21 updates; limit {limit} s\n')
+            with self.assertRaises(tables.TableError):
+                read_job(number)
+            (archive / 'projection.txt').unlink()
+
     def test_r52_nonzero_errors_and_registered_input_prefix_validation(self):
         # Break caught: demanding null for every log2 error, or accepting a different input prefix.
         dest,archive=put_r52(self.root);d=json.loads(dest.read_text())
```

Queue source read-only SHA256 `1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9`; relevant producer control flow remains at lines298-310. This hash is source identity, not historical execution proof.

Preserved original author report: 171788 bytes, SHA256 `95646f17d1dab8473a2ba9903741e867a398fd2dddd179b2db04682064b06077`.

Preserved independent review SHA256 `96cb8715e2a99ef1e62bad8329a2fa564cc4c6d0cca9322c8ed9150bbf76bbe8`.

R47 `r47_batch_input` remains exact-source-identical to adopted BASE.

R47 `table_gpu` remains exact-source-identical to adopted BASE.

## Handoff / limits

36 focused methods pass, including 12 both-job projection-only success/failure/watchdog subcases below/above the limit and malformed/stop-record guards. Both current real-root check-only entrypoints pass, so generated outputs remain byte-identical with real R52 inputs absent. No projection observation is turned into a stop or measurement claim. Root re-review remains required before integration; no full Task54 or scientific acceptance claim is made. No unresolved focused failure remains.
