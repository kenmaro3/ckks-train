# R52 table integration archive/docs independent review

Date: 2026-11-08.

SPEC: **PASS**. QUALITY: **PASS**. No actionable findings.

Scope: the 13 files currently in `results/validation/task54-r52-table-integration-20261108/` and only the final R52 section appended to `docs/m5-report.md`. This review itself is not yet part of that 13-file snapshot; root may add its exact original bytes afterward.

## Archive and source identity

All ten compressed evidence originals decompress byte-for-byte to their exact ledger files. Original lengths, original SHA256 and stored-gzip SHA256 agree with every manifest entry. Earlier RED failures, initial CHANGES REQUIRED review, fix1/fix2 reports and PASS reviews, original overflow observation and final synthetic-layout verification remain intact. Nothing was extracted to disk.

The manifest pins exactly the frozen reviewed Python sources and BASE `fb54f2f356755a946008a2f1d26757365101b81f`. The decompressed reviewed.diff.gz has the manifest hash and exactly the two expected paths. Reversing its hunks against the current frozen sources **in memory** restores the exact previously reviewed BASE source hashes (`29223799...` and `ac1fb95c...`). This checks the diff/source association without running Git or changing files.

The directory inventory is exactly README.md, manifest.json, reviewed.diff.gz, and the ten declared original-evidence files. No undeclared file is present in this reviewed snapshot.

## Claims and documentation

README and the new M5 section match the retained source reports and reviews: 38 focused tests and both check-only entrypoints passed; projection-only classification was corrected; original failed output is not promoted to successful accuracy; baseline seed 0 versus binary RNG seed 32 and 21-update/1008-sample subset limits remain explicit. The source pins still match that validation. No new behavioral test run was needed for this packaging-only review.

The initial layout record preserves nine overfull boxes and observed R52 page-7 clipping. The final layout record explicitly identifies a marked synthetic-only fixture, ten pages, compiler exit 0, zero Overfull warnings and separate page-7/page-8 observations of no clipping/overlap. It includes PDF/log/PNG byte sizes and hashes at the recorded MicroSD location. Thus the README/M5 claims accurately summarize root's retained build/visual evidence and do not claim a final scientific PDF or actual measurements. This reviewer did not reopen or independently inspect the PDF/PNGs or rehash the MicroSD artifacts; the comparison is against those retained root observations.

The M5 relative source link resolves to this archive's README. The final section expressly excludes Task54-wide completion, R52 scientific adoption and final-PDF completion. Its exact 852-byte section hash is recorded separately from the whole-document observation hash.

## Read-only verification output

A `PYTHONDONTWRITEBYTECODE=1 python3 -` harness read files, decompressed in memory, checked byte equality/length/SHA256, reversed the diff in memory, checked the exact inventory/link and compared the two layout-record claims. Exit: 0. stderr: empty. Raw stdout:

```jsonl
{"source": "tools/paper_tables.py", "bytes": 84478, "sha256": "2eb7f241d0bc6302ad5d1892ab3bb1980120d92787c76cf70f0c15fef85da1c1", "matches_frozen_review": true}
{"source": "tools/test_paper_tables.py", "bytes": 53515, "sha256": "8cf932dd06c41c3405c62db2361ef78ece5ae649b41cfe3c72c2b62130d345c5", "matches_frozen_review": true}
{"file": "task-54-r52-table-integration-brief.md.gz", "stored_bytes": 2412, "stored_sha256": "62f7e0cee09c1626e40c7c215d6262644e274d2dc648ad56aae754727b5917c5", "original_bytes": 4734, "original_sha256": "c229673f4abf92d0a15024f2798062e1eec5950c3d92717e6f07a88a64b378d7", "ledger_exact": true}
{"file": "task-54-r52-table-integration-report.md.gz", "stored_bytes": 23384, "stored_sha256": "f8b498d9fbdc1328a5babd717ccca632accdb89105c53124e01abab5119ef38f", "original_bytes": 171788, "original_sha256": "95646f17d1dab8473a2ba9903741e867a398fd2dddd179b2db04682064b06077", "ledger_exact": true}
{"file": "task-54-r52-table-integration-review.md.gz", "stored_bytes": 6185, "stored_sha256": "75ac3cdf05645a36067822cc5bb22b8098fed8449d4dbbef60b017997358542f", "original_bytes": 18217, "original_sha256": "96cb8715e2a99ef1e62bad8329a2fa564cc4c6d0cca9322c8ed9150bbf76bbe8", "ledger_exact": true}
{"file": "task-54-r52-table-integration-fix1-report.md.gz", "stored_bytes": 5793, "stored_sha256": "60090c6be2e53d23fd8ca19763cb650618e98d467827351748503289d852eaa5", "original_bytes": 46657, "original_sha256": "58b1cb4a247394c1921b19d9a8a40e527673ad0a8e69b8553d6ade6390deee32", "ledger_exact": true}
{"file": "task-54-r52-table-integration-fix1-review.md.gz", "stored_bytes": 3565, "stored_sha256": "6648d167f052a71bdbab759e88f7f61e1c83a8505efd9ea5e104b7484d9bd419", "original_bytes": 11220, "original_sha256": "c8f8aaa50304bd58cb4359df560c9ed95b25bba0ef5783dcc1a6661bdc659b3e", "ledger_exact": true}
{"file": "task-54-r52-table-integration-fix2-brief.md.gz", "stored_bytes": 1576, "stored_sha256": "b025a637dcec7db135e92b744a514e8ba6a954075e884bce76f8c2470a66fb5e", "original_bytes": 2820, "original_sha256": "69028ffd3c008e5296403bfba874044abb39fc8247785645985311bc9c8c8a70", "ledger_exact": true}
{"file": "task-54-r52-table-integration-fix2-report.md.gz", "stored_bytes": 5925, "stored_sha256": "26da68bfa089ef8e5b44067c1c1518cc26ea4457f34af395219f06a8f69e6d77", "original_bytes": 26445, "original_sha256": "74b97dbef16123dc66ab8ee2e53c45d6d58b62637b3c19f668db505e6722f654", "ledger_exact": true}
{"file": "task-54-r52-table-integration-fix2-review.md.gz", "stored_bytes": 4801, "stored_sha256": "171613c8d310401b17e81c0ee14f3579e3ac54c2f4319ee08bfc2171bed6555c", "original_bytes": 14919, "original_sha256": "fc9789f80c5a259fc482342c5e1b922a1b06c625e47de3b701a3641fc5705ffc", "ledger_exact": true}
{"file": "task-54-r52-layout-preflight.json.gz", "stored_bytes": 912, "stored_sha256": "a4d7ff6fb8063b16aa65ec7101f32a590dbb18816c815dbd3d47ce738b7dc591", "original_bytes": 1829, "original_sha256": "259c6ca40c65f45204341a6fb44f7a171fe81e661166c6af1e805b9ec3689543", "ledger_exact": true}
{"file": "task-54-r52-layout-fix2-verification.json.gz", "stored_bytes": 719, "stored_sha256": "187e7928bacfc821a40bb6e68ed50caf60162e4b9496ac1ee8651b033038502c", "original_bytes": 1333, "original_sha256": "96b75ec13f74e5f67114359d7fcbd77c6b40824a3caaa6af13a4f519ed639724", "ledger_exact": true}
{"reverse_diff_in_memory": "tools/paper_tables.py", "baseline_sha256": "29223799b8f2c975e08cf97ee20e30438147866f2d8a6bb3c5b21398268088df", "matches_previously_reviewed_BASE": true}
{"reverse_diff_in_memory": "tools/test_paper_tables.py", "baseline_sha256": "ac1fb95cf891c37d41061d68799f39ab0b37ac759b8386b2d7048fd5fb373657", "matches_previously_reviewed_BASE": true}
{"file": "reviewed.diff.gz", "stored_sha256": "2141bec411f9ff73d42406bbd7e0f15aac269474383d467a28cd7054d69d3eea", "diff_bytes": 56759, "diff_sha256": "ec31ddc0d293ceb0b8322c3cd0e7777f2403f2addeb4ff7a5b6572f66aa56074"}
{"file": "README.md", "bytes": 1625, "sha256": "2503987a9e5a5139ee34ea7989b2552ec56049160b859fa3f00d2ccb5fa219e6"}
{"file": "manifest.json", "bytes": 3431, "sha256": "0597d3f178f63f74fa5e2e5df2207070f1292e297deecf764dc570d5ae5a4ff2"}
{"document": "docs/m5-report.md", "bytes": 175887, "sha256": "7d93fe50eb731946716bfbf1f1aa6d77646c58040f5b152296992e5f93096991", "reviewed_section_bytes": 852, "reviewed_section_sha256": "cf86196508f4785fe2164ba4d8b2922a9ffb300fcc0f0c2013415594d67cbfc5", "source_link_correct": true}
PASS: 13-file archive, all original bytes, frozen sources, exact two-file diff reversal, R52 section link and recorded layout claims agree
```

## Limitations

This is bounded packaging/documentation review, not a new scientific, native or visual validation. It relies on the preserved source/test review and root's explicitly labeled synthetic-layout observations. No source edits, Git invocation, native/Cargo/SSH/GPU/HE execution, real result/generated-table writes, subagents or archive mutation occurred. Only this ledger review report was written persistently.

