# Task54 R52 table integration independent review

Date: 2026-11-08. BASE: `fb54f2f356755a946008a2f1d26757365101b81f`.

SPEC: **CHANGES REQUIRED**.
QUALITY: **CHANGES REQUIRED**.
One P2 correctness/producer-compatibility finding. No source fixes were made by this reviewer.

## P2: projection-only records are incorrectly treated as partial-stop evidence

Affected source: `tools/paper_tables.py:563-565` (and the resulting classification at lines 578-595).

The validator sets `partial = any(present(rel) for rel in partial_paths)`, where partial_paths includes projection.txt. Any projection-only archive therefore requires both partial.txt and partial-identities.json and fails with “incomplete original partial evidence”.

The actual deployed queue explicitly supports projection-only terminal records. In `results/quadruped/scripts/post_full_queue.py:298-310`, the first available five-update projection is written to projection.txt at line 302 **before** the `projection > partial` stop condition. The stop condition can be false; then the job completes normally and no partial.txt/partial-identities.json is produced. It may also fail or hit the runner watchdog after that observation. A projection above the threshold alone still does not prove that stopping happened: the queue additionally requires time.pid and successful stop handling before setting partial_stopped.

Consequence: the registered collector correctly preserves optional projection.txt, but this consumer rejects legitimate successful full-subset records and coherent failed/watchdog records once that original file is included. The current positive fixtures omit projection.txt unless partial=True, so the 34 passing tests do not cover this deployed producer branch. This is not a speculative malformed-file scenario.

Independent synthetic reproduction: for both R-52-1 and R-52-2, a valid original-shaped fixture is first accepted as success (child 0), failed/unmeasured (child 1), or failed/unmeasured (watchdog/child 143). Adding only the legitimate original-format projection line with projected 10000 seconds and registered limit 12240.0/23040.0 changes every result to TableError. Full probe and output are below.

Finite fix requested:
- Distinguish a projection observation from evidence that a partial stop occurred. Preserve/source-check projection-only records without switching the terminal outcome to partial.
- Require the complete coherent partial trio when actual stop evidence or a partial state is present; keep incomplete/contradictory stop records rejected and retain the already covered rounded-projection/output-rejection behavior.
- Add producer-shaped projection-only success and coherent failure/watchdog cases for both registered jobs. Also exercise a projection above the limit without stop evidence, since the projection alone does not establish partial_stopped. No queue, producer, scientific thresholds, output values or unrelated schemas need changing.

## Scope and positive checks

Read the exact two-file BASE diff, brief, relevant compatibility-audit sections, bounded report RED/GREEN/source/limitations sections, exact pinned P52 source/control flow and original queue/runner. Root's unrelated documentation append is not part of this review.

- The producer writes JSON before returning failed-check Err; its caller exits 1. Current new consumer branches on coherent failed/watchdog/partial/queue-output-rejection outcomes before extracting successful accuracy. Successful intake requires the raw binary digest to equal state.output_sha256. Generic run_all new_result cannot bypass this path, and a conflicting canonical/alias pair is rejected.
- Fixed invocation, P52 pin/clean marker, runner job/workdir/CPU/nice/thread fields, child/post status, binary writer/build/host/thread/timestamps, four actual producer checks, scalar errors/accuracy, coverage and aggregate counter relations are validated against the P52 block schema. No eMLP1 training-field requirement was introduced.
- P52 defaults binary seed to 32, whereas imported init-weight/index identity is baseline seed 0. New rendering distinguishes them and reports only 21 updates/1008 samples, without independent-seed SD or full-length/KS/wall-time claims.
- P52 handoff diagnostics compare valid samples times block width, outside the timed trainer step. The required slots=1008*width and visible max-input/inputs-above-1/precondition-hit/error values match this scope. Numerical success does not erase a nonzero precondition hit. Legitimate zero error with null logarithm is accepted.
- Supported current weight/data manifest hashes and registered index prefixes are checked. Notes explicitly state that P52 does not emit consumed input digests; these checks/hashes are not historical input-byte or execution proof.
- Fixture overlays exclude future R-52 archive and both canonical result paths. Synthetic payload directories detach the archived weight symlink before writing; data fixture directories are local. All reviewer-added inputs were temporary synthetic files. No actual result/generated table writes occurred.
- The R47 parser and GPU table functions are byte-identical to adopted BASE (AST source comparison below). Both current check-only entrypoints pass with R52 originals absent.

Quality assessment: correctness requires the finite P2 fix above. No additional actionable security/data-integrity, performance or maintainability finding was established in the bounded review.

## Independent check-only and focused tests

All commands inherited `PYTHONDONTWRITEBYTECODE=1` and used a 60-second subprocess timeout. Exact stdout/stderr/exit values follow. The existing suite is GREEN despite the additional reproduced producer-compatibility bug.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 34 tests in 3.895s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `git diff --check fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout:
```text
```

stderr:
```text
```

## Independent projection-only reproduction

Exact command:

```sh
PYTHONDONTWRITEBYTECODE=1 python3 - <<'PY'
import sys,tempfile,json
from pathlib import Path
sys.path.insert(0,'tools')
import paper_tables as p
from test_paper_tables import archived_overlay,put_r52
for number in (2,3):
 for rc,watchdog in ((0,False),(1,False),(143,True)):
  with tempfile.TemporaryDirectory(prefix='synthetic-r52-projection-review-') as tmp:
   root=Path(tmp); archived_overlay(root)
   dest,archive=put_r52(root,number=number,rc=rc,watchdog=watchdog)
   key=f'R-52-{number-1}'
   s=p.Store(root); before=p.r52_input(s,p.Inputs(s),key)['status']
   limit=12240.0 if number==2 else 23040.0
   (archive/'projection.txt').write_text(f'after 5 updates: 10000 s / 21 updates; limit {limit} s\n')
   try:
    s=p.Store(root); p.r52_input(s,p.Inputs(s),key)
   except p.TableError as exc:
    print(json.dumps({'job':key,'child_exit':rc,'watchdog':watchdog,'before_projection':before,'after_projection':str(exc),'BUG_reproduced':True}))
   else:
    raise AssertionError('expected to reproduce projection-only rejection')
PY
```

Exit: 0. Exit 0 means the reproducer confirmed all six erroneous rejections; it is not a PASS of expected table behavior. stderr: empty.

stdout:
```jsonl
{"job": "R-52-1", "child_exit": 0, "watchdog": false, "before_projection": "success", "after_projection": "R-52-1: incomplete original partial evidence", "BUG_reproduced": true}
{"job": "R-52-1", "child_exit": 1, "watchdog": false, "before_projection": "failed/unmeasured", "after_projection": "R-52-1: incomplete original partial evidence", "BUG_reproduced": true}
{"job": "R-52-1", "child_exit": 143, "watchdog": true, "before_projection": "failed/unmeasured", "after_projection": "R-52-1: incomplete original partial evidence", "BUG_reproduced": true}
{"job": "R-52-2", "child_exit": 0, "watchdog": false, "before_projection": "success", "after_projection": "R-52-2: incomplete original partial evidence", "BUG_reproduced": true}
{"job": "R-52-2", "child_exit": 1, "watchdog": false, "before_projection": "failed/unmeasured", "after_projection": "R-52-2: incomplete original partial evidence", "BUG_reproduced": true}
{"job": "R-52-2", "child_exit": 143, "watchdog": true, "before_projection": "failed/unmeasured", "after_projection": "R-52-2: incomplete original partial evidence", "BUG_reproduced": true}
```

## Exact source identities, preserved R47 functions and current absence

Read-only SHA256/byte inventory and AST comparison output, exit 0, stderr empty:

```jsonl
{"source": "tools/paper_tables.py", "bytes": 83582, "sha256": "8ea48895c062dc96c4ab00e15a393ae4c701f4072dc92afa994ffbd4696e1d1d"}
{"source": "tools/test_paper_tables.py", "bytes": 46444, "sha256": "02e5e75239ab6b4211a22fbaca95649865b227286e4143f53dc034cf90e346b8"}
{"source": "results/quadruped/scripts/post_full_queue.py", "bytes": 23840, "sha256": "1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9"}
{"source": "results/quadruped/scripts/run_job.sh", "bytes": 4998, "sha256": "46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736"}
{"source": "results/quadruped/raw/reboot_emlp23_full/config_values.json", "bytes": 193960, "sha256": "76c493e28692531d07d54337dfcf89a21d8d78fa2979e02b20dccad47fb303c5"}
{"source": "results/quadruped/data/reboot_emlp1_full/data_manifest.json", "bytes": 2904, "sha256": "0ddec87635b5c0e6326c49932a79e0cf8a035d25705b22d6f7d176fb1ee2dd98"}
{"source": "results/reboot_emlp2_seed0_steps1-21_indices.txt", "bytes": 5163, "sha256": "8a4db0c6cd2300744c4bbac8cadfa2a3e9d259b254b20fe0d127eeb1fc3b92dd"}
{"source": "results/reboot_emlp3_seed0_steps1-21_indices.txt", "bytes": 5156, "sha256": "e18ee927cdcbefd2b472b406a80d402bc808ac90a31a1fc9a3b6fda047a8316e"}
{"source": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-brief.md", "bytes": 4734, "sha256": "c229673f4abf92d0a15024f2798062e1eec5950c3d92717e6f07a88a64b378d7"}
{"source": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-postqueue-table-compatibility-audit.md", "bytes": 24877, "sha256": "5a75a08feb5e4b66bfb01b59fe766be8389ff82a52d7e52d4b7e714ee63e4851"}
{"source": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r52-table-integration-report.md", "bytes": 171788, "sha256": "95646f17d1dab8473a2ba9903741e867a398fd2dddd179b2db04682064b06077"}
{"source": "9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-bench/src/bin/mnist/blocks.rs", "bytes": 49961, "sha256": "4293cbf07a1c0903bdf692791153937e0d49929e57102eb2edbe828a6c6ecab2"}
{"source": "9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-bench/src/bin/mnist.rs", "bytes": 155848, "sha256": "08a30b028b84b228f2333c3555a495d87c524fe63ead3e6afe110c8bf62926c6"}
{"source": "9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-bench/src/provenance.rs", "bytes": 6686, "sha256": "4d519fec381e63141185ba87aa1638f12d18698fb91f6285555d8f546c65820b"}
{"R47_function": "r47_batch_input", "unchanged_from_base": true, "sha256": "280543fe111d2c280b928b954ee31c0b3b3a25e492d69feb8a9d78d0b1fe7997"}
{"R47_function": "table_gpu", "unchanged_from_base": true, "sha256": "1dabd388533fa6fa9e345fa4673852b4e546398d6c6a66a16a4b6eefb8fce519"}
{"canonical": "results/quadruped/mnist196_emlp2_ni_b48_subset1008_seed0.json", "exists": false, "archive": "results/quadruped/raw/R-52/R-52-1", "archive_exists": false}
{"canonical": "results/quadruped/mnist196_emlp3_ni_b48_subset1008_seed0.json", "exists": false, "archive": "results/quadruped/raw/R-52/R-52-2", "archive_exists": false}
```

## Limits

This is source and synthetic Python validation only. No Cargo/Rust execution, SSH/GPU/HE/native work, subagents, Git mutation, real scientific data writes, generated-table writes, PDF layout review or scientific acceptance occurred. The brief, compatibility audit and implementation report remain retained originals; earlier RED history was read, not independently rerun. Aggregate validation is not a replay of every update or stage predictor. Real R52 result/terminal files are absent. Only this review report was written persistently. Re-review should be confined to the projection/partial distinction and affected regressions, keeping the frozen source identities and prior findings explicit.

