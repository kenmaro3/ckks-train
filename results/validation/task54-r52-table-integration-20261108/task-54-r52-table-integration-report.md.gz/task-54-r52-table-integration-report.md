# Bounded R52 table integration report

Final bounded status: ready for root independent review. 34 focused tests pass, both real-root check-only entrypoints and owned-file diffcheck pass. Actual R52 inputs remain absent. The final hash/diff snapshot is at the end; earlier snapshots and failures are intentionally retained. No full Task54/scientific acceptance claim.

## Test-first RED

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... FAIL
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... 
  test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=1, watchdog=False, partial=False) ... FAIL
  test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=143, watchdog=True, partial=False) ... FAIL
  test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=0, watchdog=True, partial=False) ... FAIL
  test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=143, watchdog=False, partial=True) ... FAIL
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... FAIL
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... 
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='program.log') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='post.txt') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='cmd.txt') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='hekit_synced_commit') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='threads_cap') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='nice') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='gpu_job') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='exit_status') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='start') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='workdir') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='rc') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='status') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='output_sha256') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='command') ... FAIL
  test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='job') ... FAIL
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... FAIL
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... FAIL
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... FAIL
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... 
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='all_checks_pass') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='checks.handoff_err_within_2^-10') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.git_commit') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.written_by') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.git_modified_tracked_files') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.command_line') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.build.features.cuda') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.threads') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.finished_unix') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.seed') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.params') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.init_weights') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='plan.stage_dims') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.updates') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.samples') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.total.key_switches') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.predicted_ks_this_run') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.handoff_bootstraps') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.max_abs_diff') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.log2_max_abs_diff') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.slots_compared') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.max_abs_err_vs_twin') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.precondition_hit') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.inputs_above_1') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='evaluation.test_acc_twin') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='evaluation.test_acc_encrypted_trained') ... FAIL
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
FAIL: test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 678, in test_r52_error_atomicity_quick_and_both_entrypoints
    self.assertEqual(tables.main(['--root',str(self.root)]),2)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2

======================================================================
FAIL: test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=1, watchdog=False, partial=False)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 598, in test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy
    self.assertIn('partial/unmeasured' if partial else 'failed/unmeasured',r[3])
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'failed/unmeasured' not found in '90.00'

======================================================================
FAIL: test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=143, watchdog=True, partial=False)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 598, in test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy
    self.assertIn('partial/unmeasured' if partial else 'failed/unmeasured',r[3])
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'failed/unmeasured' not found in '90.00'

======================================================================
FAIL: test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=0, watchdog=True, partial=False)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 598, in test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy
    self.assertIn('partial/unmeasured' if partial else 'failed/unmeasured',r[3])
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'failed/unmeasured' not found in '90.00'

======================================================================
FAIL: test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=143, watchdog=False, partial=True)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 598, in test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy
    self.assertIn('partial/unmeasured' if partial else 'failed/unmeasured',r[3])
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'partial/unmeasured' not found in 'pending (R-52-1)'

======================================================================
FAIL: test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 652, in test_r52_registered_input_hash_failure_is_not_success
    with self.assertRaises(tables.TableError):self.build(tables.table_accuracy)
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='program.log')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 609, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                 ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 609, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                 ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='post.txt')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 609, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                 ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='cmd.txt')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 609, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                 ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 609, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                 ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='hekit_synced_commit')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='threads_cap')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='nice')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='gpu_job')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='exit_status')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='start')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='meta.json', key='workdir')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='rc')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='status')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='output_sha256')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='command')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) (name='state.json', key='job')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 617, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 619, in test_r52_rejects_missing_partial_or_inconsistent_original_terminal
    with self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 664, in test_r52_run_all_alias_requires_same_terminal_originals_and_bytes
    self.assertTrue(any('1 (baseline seed 0; RNG 32)' in r for r in rows(t)))
    ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: False is not true

======================================================================
FAIL: test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 578, in test_r52_success_models_validate_original_schema_and_seed_handoff_sources
    self.assertEqual(r[2],'1 (baseline seed 0; RNG 32)')
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: '1 (seed 0)' != '1 (baseline seed 0; RNG 32)'
- 1 (seed 0)
+ 1 (baseline seed 0; RNG 32)


======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='all_checks_pass')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='checks.handoff_err_within_2^-10')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.git_commit')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.written_by')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.git_modified_tracked_files')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.command_line')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.build.features.cuda')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.threads')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='provenance.finished_unix')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.seed')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.params')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.init_weights')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='plan.stage_dims')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.updates')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.samples')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.total.key_switches')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.predicted_ks_this_run')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='measured.handoff_bootstraps')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.max_abs_diff')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.log2_max_abs_diff')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.slots_compared')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.max_abs_err_vs_twin')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.precondition_hit')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='twin.handoff_bootstraps.0.inputs_above_1')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='evaluation.test_acc_twin')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='evaluation.test_acc_encrypted_trained')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

----------------------------------------------------------------------
Ran 31 tests in 3.489s

FAILED (failures=52)
```

## Initial GREEN trial: registered full index-source correction

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... FAIL
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ERROR
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ERROR
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 663, in test_r52_run_all_alias_requires_same_terminal_originals_and_bytes
    s=tables.Store(self.root);t=tables.table_accuracy(s,tables.Inputs(s,'full'))
                                ~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 792, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 698, in read_r52_input
    check(len(selected_indices) == 1008 and len(baseline_indices) == 4800 and
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          selected_indices == baseline_indices[:1008], 'wrong registered first-21-update indices')
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: wrong registered first-21-update indices

======================================================================
ERROR: test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 574, in test_r52_success_models_validate_original_schema_and_seed_handoff_sources
    t=self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 223, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 792, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 698, in read_r52_input
    check(len(selected_indices) == 1008 and len(baseline_indices) == 4800 and
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          selected_indices == baseline_indices[:1008], 'wrong registered first-21-update indices')
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: wrong registered first-21-update indices

======================================================================
FAIL: test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_error_atomicity_quick_and_both_entrypoints
    self.assertEqual(p.returncode,0,p.stderr)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 2 != 0 : paper_tables.py: R-52-1: wrong registered first-21-update indices


----------------------------------------------------------------------
Ran 31 tests in 3.470s

FAILED (failures=1, errors=2)
```

## Exact pinned config_json shape RED

The pinned backend config_json emits a fourth default field; the success fixture was corrected to its actual shape before adjusting the validator.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... FAIL
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ERROR
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ERROR
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 663, in test_r52_run_all_alias_requires_same_terminal_originals_and_bytes
    s=tables.Store(self.root);t=tables.table_accuracy(s,tables.Inputs(s,'full'))
                                ~~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 792, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 614, in read_r52_input
    check(setup['params'] == 'n16_boot' and type(setup['log_n']) is int and setup['log_n'] == 16 and
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          type(setup['batch']) is int and setup['batch'] == 48 and type(setup['seed']) is int and setup['seed'] == 32 and
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          setup['transpose_keys'] == 'reuse' and setup['init_weights'] == weights and setup['biases'] is False and
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          setup['lr_schedule'] == 'constant' and setup['eval_config'] == {'hoist': True, 'bsgs': True, 'lazy_relin': True}, 'wrong registered setup/seed')
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: wrong registered setup/seed

======================================================================
ERROR: test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 574, in test_r52_success_models_validate_original_schema_and_seed_handoff_sources
    t=self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 223, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 792, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 614, in read_r52_input
    check(setup['params'] == 'n16_boot' and type(setup['log_n']) is int and setup['log_n'] == 16 and
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          type(setup['batch']) is int and setup['batch'] == 48 and type(setup['seed']) is int and setup['seed'] == 32 and
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          setup['transpose_keys'] == 'reuse' and setup['init_weights'] == weights and setup['biases'] is False and
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          setup['lr_schedule'] == 'constant' and setup['eval_config'] == {'hoist': True, 'bsgs': True, 'lazy_relin': True}, 'wrong registered setup/seed')
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: wrong registered setup/seed

======================================================================
FAIL: test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 684, in test_r52_error_atomicity_quick_and_both_entrypoints
    self.assertEqual(p.returncode,0,p.stderr)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 2 != 0 : paper_tables.py: R-52-1: wrong registered setup/seed


----------------------------------------------------------------------
Ran 31 tests in 3.542s

FAILED (failures=1, errors=2)
```

## Queue output-rejection branch RED

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ERROR
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 653, in test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero
    r=next(r for r in rows(self.build(tables.table_accuracy)) if r[0].startswith('hekit encrypted eMLP-2,'))
                           ~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 223, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 792, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 576, in read_r52_input
    check(state.get('status') == expected, 'state contradicts original child/log/partial outcome')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: state contradicts original child/log/partial outcome

----------------------------------------------------------------------
Ran 33 tests in 3.682s

FAILED (errors=1)
```

## Exact queue process identity / strict field-type RED

The actual queue process_ticks returns a decimal string or null for an already-gone descendant; partial identities retain an identified time parent as the final pair. Fixtures now use that original shape.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... 
  test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=143, watchdog=False, partial=True) ... ERROR
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... 
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.eval_config.hoist') ... FAIL
  test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='plan.layout_d') ... FAIL
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) (rc=143, watchdog=False, partial=True)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 596, in test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy
    t=self.build(tables.table_accuracy)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 223, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 799, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 571, in read_r52_input
    check(isinstance(identities, list) and identities and all(isinstance(pair, list) and len(pair) == 2 and
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          all(type(v) is int and v > 0 for v in pair) for pair in identities), 'invalid partial identities')
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: invalid partial identities

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='setup.eval_config.hoist')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) (field='plan.layout_d')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 645, in test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff
    with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

----------------------------------------------------------------------
Ran 33 tests in 3.863s

FAILED (failures=2, errors=1)
```

## Implemented bounded behavior

- Only `tools/paper_tables.py`, `tools/test_paper_tables.py` and this required report were written for the R52 correction. BASE is fb54f2f356755a946008a2f1d26757365101b81f. R48 was not changed; no Rust/Cargo/native/SSH/GPU/HE/Git mutation, real result JSON or generated paper/table write was performed.
- R52 intake uses the adopted original terminal archive paths and raw binary canonical names. Missing all evidence remains the existing pending row. Partial/malformed identity evidence fails closed. Child failure, watchdog, actual partial termination and coherent queue-side output/provenance rejection produce unmeasured rows with no success accuracy, including a fully successful saved JSON followed by nonzero child termination. A failed outcome does not require a final JSON. Wrapper status is distinct from child status.
- Successful canonical or run_all full aliases require the same original terminal association and exact state.output_sha256. A present canonical original and alias must be byte-identical; no arbitrary historical substitute is selected. Quick mode ignores these results.
- Exact P52 writer, commit, clean marker, command, CPU release build, nice/thread limits, host and time containment are checked. The block schema uses measured.samples/updates and plan.placement; it does not invent the eMLP1 training object or bootstrap_time_total field.
- Four true producer checks, accuracy/error tolerances, zero-error/null-log2 semantics, counters and aggregate plan consistency, 21 updates/1008 samples/B48/n16_boot/reuse/when_needed, correct model stage dimensions, actual binary RNG32, and baseline seed0 initialization paths are validated. Stage handoff slots must equal valid samples times the reported block width, matching the pinned loop; padding or every ciphertext slot is not claimed.
- Handoff notes retain compared-slot coverage, input maximum, above-one count, precondition-hit flag and numerical error. A nonzero precondition hit remains visible even if numerical checks pass. One imported baseline-seed0 trajectory is labeled separately from RNG32; no independent-seed SD, full-length architecture outcome, new KS/time table or ReBoot wall-time ratio is claimed.
- Supported current input identities are checked against the registered sources: derived 1008-index order must match the imported seed0 full-order prefix; imported layer payloads must match their config manifest hash/shape/name/orientation; four data payloads must match data-manifest hashes/shapes. These checks read current registered bytes only. P52 does not emit consumed input digests, so this is explicitly not historical input-byte proof and does not justify fabricating new provenance fields.

## Source comparison corrections preserved in the RED ledger

The initial RED had 52 expected failures before production changes. The first implementation trial caught an incorrect full-order count assumption: the registered full order contains 48000 entries (ten epochs), rather than 4800 unique training images. Intake checks the required first1008 prefix, not an unrelated full-order length. Pinned backend config_json emits `default:true` alongside the three flags; the fixture/validator were corrected to that actual shape. The original queue process identity records use decimal-string start ticks, with null allowed for an already-gone descendant and a final identified time parent; fixtures/validator now preserve that producer format. Additional RED coverage caught the queue's post-child0 `failed: output checks/provenance` branch and strict flag/integer types. All of these negative results and final GREEN are retained rather than rewritten as uninterrupted success.

## Initial verification snapshot (superseded by final verification below)

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 33 tests in 3.814s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `git diff --check fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

## Adopted R47 source preservation

- `r47_batch_input`: exact function source unchanged from BASE; SHA256 `280543fe111d2c280b928b954ee31c0b3b3a25e492d69feb8a9d78d0b1fe7997`.
- `table_gpu`: exact function source unchanged from BASE; SHA256 `1dabd388533fa6fa9e345fa4673852b4e546398d6c6a66a16a4b6eefb8fce519`.

Both real-root --check entrypoints passed above: all current generated files remain byte-identical while R52 originals are absent. No actual regenerated files were written. The 23 adopted tests, including the R47 six-row and failure branches, remain green alongside 10 R52 tests (33 methods total, with multiple independent negative subcases).

## Exact source SHA256 identities

- `git show 9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-bench/src/bin/mnist/blocks.rs`: `4293cbf07a1c0903bdf692791153937e0d49929e57102eb2edbe828a6c6ecab2` (49961 bytes).
- `git show 9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-bench/src/bin/mnist.rs`: `08a30b028b84b228f2333c3555a495d87c524fe63ead3e6afe110c8bf62926c6` (155848 bytes).
- `git show 9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-bench/src/backend.rs`: `cafdcebb6fa4e54e4220cc096c7528cd3c53db78c0a34c22f3d066ba0b1ceaf5` (24543 bytes).
- `git show 9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-bench/src/provenance.rs`: `4d519fec381e63141185ba87aa1638f12d18698fb91f6285555d8f546c65820b` (6686 bytes).
- `git show 9305d2e1f4f9999296cd4b4aaf55ea631fbca78e:crates/hekit-nn/src/block.rs`: `49ddb88770e2977cb04ad8deb1728fa7388b0858e2f2743867e2e0e34daab295` (30291 bytes).
- Current local source `results/quadruped/scripts/post_full_queue.py`: `1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9` (23840 bytes).
- Current local source `results/quadruped/scripts/run_job.sh`: `46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736` (4998 bytes).
- Current local source `docs/post-full-queue.md`: `09bdab1997d0a1ee0352d159ee2c2d634c34f5c739313c5c5515ba3f7a0d06dc` (24704 bytes).
- Current local source `docs/m4-report.md`: `b270d88647819ad841d6082e3e5df00761e9509221ae7f90ae80dac5ced37ece` (40347 bytes).
- Current local source `docs/m5-report.md`: `586326fe74dbdfcea9bb133d86fb3440e9f0fbd26512d31cf3795b347d4bfbea` (175034 bytes).
- Current local source `results/quadruped/raw/reboot_emlp23_full/config_values.json`: `76c493e28692531d07d54337dfcf89a21d8d78fa2979e02b20dccad47fb303c5` (193960 bytes).
- Current local source `results/quadruped/data/reboot_emlp1_full/data_manifest.json`: `0ddec87635b5c0e6326c49932a79e0cf8a035d25705b22d6f7d176fb1ee2dd98` (2904 bytes).
- Current local source `results/reboot_emlp2_seed0_steps1-21_indices.txt`: `8a4db0c6cd2300744c4bbac8cadfa2a3e9d259b254b20fe0d127eeb1fc3b92dd` (5163 bytes).
- Current local source `results/reboot_emlp3_seed0_steps1-21_indices.txt`: `e18ee927cdcbefd2b472b406a80d402bc808ac90a31a1fc9a3b6fda047a8316e` (5156 bytes).

Source/capture hashes identify bytes at read time; they are not historical execution attestations.

The intermediate owned-file diff was superseded by the exact final BASE diff retained at the end. All RED/GREEN command stdout/stderr/exit transcripts above remain intact.

## Limits / concerns / handoff

No blocking contract fact remains unresolved for this bounded implementation. Root must independently review the exact two-file diff and retained evidence before integration. The consumer checks self-reported binary checks and aggregate plan/counter/slot consistency; it does not execute HE, replay every update, or independently recompute every stage predictor. The P52 result emits only the first update's counter, not all per-update counters. The source/runner clean markers, validated terminal fields and byte hashes cannot independently prove historical execution or which historical input bytes were consumed. Current input hash checks and their stated limitation remain visible.

All populated success/failure fixtures are deliberately tiny, synthetic schema-shaped records and tiny synthetic payloads in temporary directories. They are not actual CKKS results or valid scientific NPY/HE evaluations. Reference metadata and registered prefix text are read from the existing archive; temporary copies are detached before synthetic payload hashes are set, and future R52 canonical/raw archives are excluded from overlay links. The input-source positive tests prove hash/shape/identity consumption, not model computation. Zero numerical errors are actual supported producer representations, not invented uncertainty.

The real expected R52 binaries and terminal archives remain absent locally. No result was collected or accepted by this work. R48 remains the later separate slice; full Task54/Step3/4, scientific acceptance and the experiment matrix remain incomplete. No task or milestone completion beyond this bounded consumer implementation is claimed.

## Final source-control-flow edge RED (supersedes prior final snapshot)

The queue compares unrounded projected time, prints a whole second, and can overwrite a partial/watchdog status when post-child0 output validation fails. The exact source control flow requires preserving these cases as unmeasured. Partial fixtures now use the actual registered limit values.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ERROR
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 666, in test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow
    r=next(r for r in rows(self.build(tables.table_accuracy)) if r[0].startswith('hekit encrypted eMLP-2,'))
                           ~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 224, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 807, in table_accuracy
    result = r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 468, in r52_input
    return read_r52_input(s, inp, key)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 568, in read_r52_input
    check(a is not None and b is not None and a.groups() == b.groups() and
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
          float(a[1]) > float(a[2]), 'inconsistent partial projection')
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 509, in check
    require(ok, f'{key}: {message}')
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R-52-1: inconsistent partial projection

----------------------------------------------------------------------
Ran 34 tests in 4.262s

FAILED (errors=1)
```

## Final GREEN verification and final owned snapshot

The final source control-flow correction retains whole-second projection rounding and the original queue ordering of output-validation failures. Registered partial limits are 12240/23040 seconds. Final suite: 34 test methods (23 adopted and 11 R52), including original-shape string/null partial identities.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 34 tests in 3.943s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `git diff --check fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

R47 `r47_batch_input`: exact source unchanged from adopted BASE.

R47 `table_gpu`: exact source unchanged from adopted BASE.

Final source SHA256 identities:

- `tools/paper_tables.py`: `8ea48895c062dc96c4ab00e15a393ae4c701f4072dc92afa994ffbd4696e1d1d`.
- `tools/test_paper_tables.py`: `02e5e75239ab6b4211a22fbaca95649865b227286e4143f53dc034cf90e346b8`.

Final exact diff command: `git diff fb54f2f356755a946008a2f1d26757365101b81f -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```diff
diff --git a/tools/paper_tables.py b/tools/paper_tables.py
index fb6c4ed..fe8b1be 100644
--- a/tools/paper_tables.py
+++ b/tools/paper_tables.py
@@ -457,6 +457,289 @@ def hekit_time_row(t, s, rel, key, input_label, host, hsrc, reboot, rb_threads,
            Cell(f'rayon {m.group(1)}' if m else thr, [ths, hs, hsrc])])
 
 
+R52_PIN = '9305d2e1f4f9999296cd4b4aaf55ea631fbca78e'
+R52_WORKDIR = '/home/kmihara/hekit-post-full-clones/hekit-post-full-r52'
+R52_DATA = 'results/quadruped/data/reboot_emlp1_full'
+
+
+def r52_input(s, inp, key):
+    """Registered P52 block subset only; neither an eMLP1 FULL schema nor runner-made JSON."""
+    try:
+        return read_r52_input(s, inp, key)
+    except TableError:
+        raise
+    except (OSError, UnicodeError, ValueError, TypeError, KeyError, IndexError, OverflowError,
+            rq1.SummaryError) as exc:
+        raise TableError(f'{key}: invalid original R52 evidence: {exc}') from exc
+
+
+def read_r52_input(s, inp, key):
+    if inp.run_all == 'quick':
+        return None
+    number = 2 if key == 'R-52-1' else 3
+    blocks = [64] if number == 2 else [128, 64]
+    dims = [[196, 64, 16], [64, 32, 16]] if number == 2 else [[196, 128, 16], [128, 64, 16], [64, 32, 16]]
+    canonical, run_id, _ = RUN[key]
+    canonical = canonical[0]
+    selected = f'results/run_all/{inp.run_all}/{run_id}.json' if inp.run_all else canonical
+    archive = f'results/quadruped/raw/R-52/{key}'
+    paths = [f'{archive}/{name}' for name in ('program.log', 'meta.json', 'post.txt', 'cmd.txt', 'state.json')]
+    present = lambda rel: (s.root / rel).exists() or (s.root / rel).is_symlink()
+    partial_paths = [f'{archive}/{name}' for name in ('partial.txt', 'projection.txt', 'partial-identities.json')]
+    if not any(present(rel) for rel in paths + partial_paths + [selected, canonical]):
+        return None
+    require(all(present(rel) for rel in paths), f'{key}: incomplete original terminal evidence')
+    raw = {}
+
+    def read(rel):
+        if rel not in raw:
+            raw[rel] = (s.root / rel).read_bytes()
+        return raw[rel]
+
+    def text(rel):
+        return read(rel).decode('utf-8')
+
+    def doc(rel):
+        value = json.loads(read(rel), object_pairs_hook=rq1.unique_object)
+        rq1.finite_tree(value)
+        require(isinstance(value, dict), f'{rel}: expected object')
+        return value
+
+    def check(ok, message):
+        require(ok, f'{key}: {message}')
+
+    def num(value, name, integer=False, minimum=0):
+        check(type(value) is int if integer else type(value) in (int, float), f'{name}: invalid number type')
+        check(math.isfinite(value) and value >= minimum, f'{name}: invalid finite/range value')
+        return value
+
+    def same(a, b, name):
+        num(a, name)
+        check(math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-9), f'{name}: inconsistent value')
+
+    def stamp(value):
+        check(isinstance(value, str) and re.fullmatch(
+            r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}', value), 'timezone-qualified timestamp required')
+        return datetime.fromisoformat(value).timestamp()
+
+    def argv(value):
+        check(isinstance(value, str), 'missing command')
+        return shlex.split(value)
+
+    weights = f'results/quadruped/raw/reboot_emlp23_full/init_weights_emlp{number}_seed0'
+    indices = f'results/reboot_emlp{number}_seed0_steps1-21_indices.txt'
+    command = ['target/release/mnist', '--mode', 'noninteractive', '--placement', 'when_needed',
+               '--batch', '48', '--faithful', '--blocks', '64' if number == 2 else '128,64',
+               '--hidden', '32', '--dataset-npy', R52_DATA, '--indices', indices,
+               '--init-weights', weights, '--init-weights-manifest', REBOOT_23_CFG,
+               '--epochs', '1', '--transpose', 'reuse', '--out', canonical]
+    log_rel, meta_rel, post_rel, cmd_rel, state_rel = paths
+    log, meta, post, state = text(log_rel), doc(meta_rel), text(post_rel).splitlines(), doc(state_rel)
+    check(meta.get('job') == state.get('job') == key and
+          meta.get('workdir') == state.get('workdir') == R52_WORKDIR, 'wrong job/workdir')
+    check(meta.get('hekit_synced_commit') == ['commit 9305d2e', 'full ' + R52_PIN, 'dirty_files 0'], 'wrong source pin/clean marker')
+    check(argv(meta.get('command')) == argv(text(cmd_rel)) == command and state.get('command') == command, 'wrong argv')
+    check(type(meta.get('nice')) is int and meta['nice'] == 10 and
+          type(meta.get('threads_cap')) is int and meta['threads_cap'] == 12 and meta.get('gpu_job') is False and
+          meta.get('env_thread_caps') == {k: '12' for k in ('OMP_NUM_THREADS', 'RAYON_NUM_THREADS', 'CARGO_BUILD_JOBS')},
+          'wrong nice/thread/CPU limits')
+    start, end = stamp(meta.get('start')), stamp(meta.get('end'))
+    wall = num(meta.get('wall_s_runner'), 'runner wall')
+    check(end >= start and abs(wall - (end - start)) <= 2, 'incoherent runner times')
+    terminals = [(i, line) for i, line in enumerate(post, 1) if line.startswith('JOB_DONE')]
+    check(len(terminals) == 1 and terminals[0][0] == len(post), 'missing/duplicate/nonterminal JOB_DONE')
+    done = re.fullmatch(r'JOB_DONE rc=(\d+)', terminals[0][1])
+    check(done is not None, 'malformed JOB_DONE')
+    rc = num(meta.get('exit_status'), 'child exit', True)
+    check(rc <= 255 and type(state.get('rc')) is int and state['rc'] == rc == int(done[1]), 'child exit mismatch')
+    check(num(state.get('wrapper_rc'), 'wrapper exit', True) <= 255, 'invalid separate wrapper exit')
+    check(type(meta.get('watchdog_killed')) is bool, 'invalid watchdog')
+    check(post and post[0].startswith('date: ') and stamp(post[0][6:]) >= end, 'invalid post snapshot timestamp')
+    check(state.get('log') == f'/home/kmihara/hekit-runs/logs/{key}.log', 'wrong original log path')
+    watchdog = meta['watchdog_killed']
+    check(watchdog or not any(line.startswith('WATCHDOG:') for line in log.splitlines()), 'watchdog contradiction')
+    skips = [line for line in log.splitlines() if 'SKIP' in line]
+    check(state.get('skip') is bool(skips) and state.get('skip_lines') == skips, 'inconsistent skip record')
+    partial = any(present(rel) for rel in partial_paths)
+    if partial:
+        check(all(present(rel) for rel in partial_paths), 'incomplete original partial evidence')
+        a = re.fullmatch(r'partial: after >=5 updates; projected (\d+) > ([0-9.]+) s\n?', text(partial_paths[0]))
+        b = re.fullmatch(r'after 5 updates: (\d+) s / 21 updates; limit ([0-9.]+) s\n?', text(partial_paths[1]))
+        check(a is not None and b is not None and a.groups() == b.groups() and
+              float(a[2]) == (12240.0 if number == 2 else 23040.0) and
+              float(a[1]) + 0.5 > float(a[2]), 'inconsistent partial projection')
+        # The queue decides with unrounded projection, then prints it to whole seconds.
+        identities = json.loads(read(partial_paths[2]), object_pairs_hook=rq1.unique_object)
+        check(isinstance(identities, list) and identities and all(isinstance(pair, list) and len(pair) == 2 and
+              type(pair[0]) is int and pair[0] > 0 and (pair[1] is None or isinstance(pair[1], str) and
+              re.fullmatch(r'[1-9][0-9]*', pair[1])) for pair in identities) and
+              identities[-1][1] is not None and len({pair[0] for pair in identities}) == len(identities),
+              'invalid original partial process identities')
+    expected = ('failed: RSS watchdog' if watchdog else 'partial' if partial else
+                'failed: device OOM' if rc and re.search(r'device error|out of memory', log, re.I) else
+                'skipped' if rc == 3 and skips else 'failed' if rc else 'done_with_skips' if skips else 'done')
+    output_rejected = state.get('status') == 'failed: output checks/provenance'
+    if output_rejected:
+        check(rc == 0 and isinstance(state.get('output_error'), str) and
+              state['output_error'].strip() and 'output_sha256' not in state, 'incoherent queue output rejection')
+    else:
+        check(state.get('status') == expected, 'state contradicts original child/log/partial outcome')
+    sources = [(meta_rel, field) for field in ('job', 'workdir', 'hekit_synced_commit', 'command', 'nice',
+               'threads_cap', 'env_thread_caps', 'gpu_job', 'start', 'end', 'wall_s_runner', 'exit_status', 'watchdog_killed')]
+    sources += [(state_rel, field) for field in ('rc', 'wrapper_rc', 'status', 'command', 'workdir', 'log')]
+    sources += [(post_rel, f'line {terminals[0][0]}'), (cmd_rel, 'line 1')]
+    for rel in partial_paths:
+        if partial:
+            sources.append((rel, 'original bytes'))
+    result = {'sources': sources, 'rel': selected, 'raw': raw,
+              'status': 'partial/unmeasured' if partial and not watchdog else 'failed/unmeasured',
+              'rc': rc, 'watchdog': watchdog, 'reason': state['status']}
+    if output_rejected:
+        sources.append((state_rel, 'output_error'))
+    # Preserve failed-check JSON bytes for diagnostics, but never use their saved accuracies.
+    if rc or watchdog or partial or output_rejected:
+        for rel in set((selected, canonical)):
+            if present(rel):
+                read(rel)
+        return result
+    check(not skips, 'P52 CPU subset has no successful SKIP branch')
+    check(present(selected), 'successful terminal lacks selected original binary result')
+    digest = hashlib.sha256(read(selected)).hexdigest()
+    check(state.get('output_sha256') == digest, 'original result SHA256 mismatch')
+    if selected != canonical and present(canonical):
+        check(read(canonical) == read(selected), 'run_all alias contradicts canonical original')
+    d = doc(selected)
+    p, setup, plan, measured, twin, evaluation = [d[k] for k in ('provenance', 'setup', 'plan', 'measured', 'twin', 'evaluation')]
+    check(p['written_by'] == 'the mnist binary (raw output, not assembled)' and p['git_commit'] == R52_PIN and
+          p['git_modified_tracked_files'] == 'none' and p['command_line'] == ' '.join(command), 'wrong binary provenance')
+    check(p['build'] == {'debug_assertions': False, 'package_version': '1.0.0', 'target_os': 'linux',
+                        'target_arch': 'x86_64', 'features': {'parallel': True, 'cuda': False}} and
+          p['parallel_feature'] is True, 'wrong binary build')
+    check(isinstance(p['threads'], str) and re.search(r'RAYON_NUM_THREADS = 12(?:,|$)', p['threads']), 'wrong binary threads')
+    check(isinstance(meta.get('host'), str) and meta['host'].split('.')[0] == p['machine']['host'] and
+          all(isinstance(p['machine'][k], str) and p['machine'][k] not in ('', 'unknown') for k in ('host', 'cpu', 'os')), 'wrong binary/runner host')
+    ps, pe = num(p['started_unix'], 'binary start'), num(p['finished_unix'], 'binary finish')
+    check(start <= ps < pe < end + 1, 'binary timestamps outside terminal interval')
+    checks = ('every_update_equals_prediction', 'twin_weights_within_2^-10',
+              'test_acc_diff_within_0.005', 'handoff_err_within_2^-10')
+    check(d.get('all_checks_pass') is True and all(d['checks'].get(k) is True for k in checks), 'producer checks failed')
+    check(setup['params'] == 'n16_boot' and type(setup['log_n']) is int and setup['log_n'] == 16 and
+          type(setup['batch']) is int and setup['batch'] == 48 and type(setup['seed']) is int and setup['seed'] == 32 and
+          setup['transpose_keys'] == 'reuse' and setup['init_weights'] == weights and setup['biases'] is False and
+          setup['lr_schedule'] == 'constant' and setup['eval_config'] == {'hoist': True, 'bsgs': True, 'lazy_relin': True, 'default': True}, 'wrong registered setup/seed')
+    check(all(type(v) is bool for v in setup['eval_config'].values()), 'non-boolean config flags')
+    same(setup['lr_reference_on_mean_gradient'], 0.024, 'faithful constant learning rate')
+    check(plan['stage_dims'] == dims and plan['placement'] == 'when_needed' and plan['layout_d'] == 256 and
+          plan['lanes'] == 64 and plan['micro_batches_per_update'] == 1, 'wrong architecture/layout')
+    check(all(type(v) is int and v > 0 for stage in plan['stage_dims'] for v in stage), 'invalid stage dimensions')
+    for name in ('layout_d', 'lanes', 'micro_batches_per_update', 'start_level', 'bootstrap_output_level', 'levels_per_stage_step'):
+        num(plan[name], name, True, 1)
+    check(plan['start_level'] + 1 == plan['bootstrap_output_level'], 'inconsistent bootstrap output/start level')
+    for name, value, want in [('planned updates', plan['updates'], 21), ('updates', measured['updates'], 21),
+                              ('samples', measured['samples'], 1008), ('boot KS', setup['boot_ks'], 111),
+                              ('plan boot KS', plan['boot_ks_assumed'], 111)]:
+        check(num(value, name, True) == want, f'wrong {name} coverage')
+    check(measured['every_update_equals_prediction'] is True, 'measured prediction check failed')
+    schedules = plan['boot_schedules']
+    check(isinstance(schedules, list) and len(schedules) == len(dims) and all(isinstance(v, list) and
+          len(v) == 21 and all(type(x) is int and x in (0, 1) for x in v) for v in schedules), 'wrong bootstrap schedule coverage')
+    counter_keys = ('rotations', 'relins', 'sse_switches', 'key_switches', 'bootstraps', 'ct_ct_tensor', 'ct_pt_mults', 'rescales')
+    for label in ('total', 'per_update_first'):
+        c = measured[label]
+        for name in counter_keys:
+            num(c[name], label + '.' + name, True)
+        check(c['key_switches'] == c['rotations'] + c['relins'] + c['sse_switches'] and
+              c['sse_switches'] == 2 * c['bootstraps'] and c['rotations'] >= 69 * c['bootstraps'] and
+              c['relins'] >= 40 * c['bootstraps'], 'inconsistent block counters')
+    total, first = measured['total'], measured['per_update_first']
+    check(all(first[k] <= total[k] for k in counter_keys), 'first update exceeds total')
+    same(measured['predicted_ks_this_run'], total['key_switches'], 'predicted KS')
+    check(total['key_switches'] > 0, 'zero total KS')
+    same(measured['measured_over_predicted'], 1, 'measured/predicted')
+    same(measured['ks_per_sample_incl_bootstraps'], total['key_switches'] / 1008, 'KS/sample')
+    same(plan['predicted_ks_per_sample'], total['key_switches'] / 1008, 'planned KS/sample')
+    check(num(plan['handoff_bootstraps_per_update'], 'handoff/update', True) == len(blocks) and
+          num(measured['handoff_bootstraps'], 'handoff count', True) == len(blocks) * 21, 'wrong handoff count')
+    weight_boots = num(plan['weight_bootstraps_per_update_avg'], 'weight bootstrap average') * 21
+    check(math.isclose(weight_boots, round(weight_boots), abs_tol=1e-9) and
+          total['bootstraps'] == round(weight_boots) + measured['handoff_bootstraps'], 'bootstrap counts contradict plan')
+    stage_ks = plan['stage_nonboot_ks_per_update']
+    check(isinstance(stage_ks, list) and len(stage_ks) == len(dims), 'wrong stage counter coverage')
+    for value in stage_ks:
+        num(value, 'stage KS', True, 1)
+    check(num(plan['nonboot_ks_per_update'], 'nonboot KS', True) == sum(stage_ks) and
+          total['key_switches'] == sum(stage_ks) * 21 + 111 * total['bootstraps'], 'constant-lr plan/total mismatch')
+
+    def error(value, logarithm, label):
+        num(value, label)
+        check(value < 2 ** -10, f'{label}: numerical check failed')
+        check(logarithm is None if value == 0 else type(logarithm) in (int, float) and
+              math.isfinite(logarithm) and math.isclose(logarithm, math.log2(value), abs_tol=1e-9), f'{label}: inconsistent log2')
+
+    error(twin['max_abs_diff'], twin['log2_max_abs_diff'], 'twin error')
+    diagnostics = twin['handoff_bootstraps']
+    activations = twin['max_abs_handoff_activation_per_block']
+    check(isinstance(diagnostics, list) and len(diagnostics) == len(blocks) and
+          isinstance(activations, list) and len(activations) == len(blocks), 'wrong handoff diagnostic coverage')
+    for i, (width, diag) in enumerate(zip(blocks, diagnostics)):
+        slots = num(diag['slots_compared'], 'handoff slots', True)
+        above = num(diag['inputs_above_1'], 'handoff inputs above 1', True)
+        maximum = num(diag['max_abs_input_twin'], 'handoff max input')
+        check(slots == 1008 * width and above <= slots and type(diag['precondition_hit']) is bool and
+              diag['precondition_hit'] == (above > 0) == (maximum > 1), 'inconsistent handoff compared slots/precondition')
+        same(activations[i], maximum, 'handoff activation maximum')
+        error(diag['max_abs_err_vs_twin'], diag['log2_max_abs_err_vs_twin'], 'handoff error')
+    acc, tw = evaluation['test_acc_encrypted_trained'], evaluation['test_acc_twin']
+    check(num(acc, 'accuracy') <= 1 and num(tw, 'twin accuracy') <= 1 and abs(acc - tw) <= 0.005, 'accuracy check failed')
+    delta = evaluation['test_acc_diff']
+    check(type(delta) in (int, float) and math.isfinite(delta) and
+          math.isclose(delta, acc - tw, abs_tol=1e-12), 'inconsistent accuracy difference')
+    check(num(evaluation['test_samples'], 'test samples', True) == 10000, 'wrong test coverage')
+
+    # The P52 JSON has paths, not input digests. Verify supported current registered
+    # source/manifest hashes, and explicitly retain that limitation in the table note.
+    config = doc(REBOOT_23_CFG)
+    seed = config['models'][f'emlp{number}']['per_seed']['0']
+    base_indices = 'results/quadruped/raw/reboot_emlp23_full/' + seed['indices_file']
+    check(seed['indices_file'] == f'train_indices_emlp{number}_seed0.txt', 'wrong baseline seed index identity')
+
+    def index_values(rel):
+        values = []
+        for line in text(rel).splitlines():
+            if line.strip() and not line.lstrip().startswith('#'):
+                values.extend(int(v) for v in re.split(r'[\s,]+', line.strip().split('\t')[-1]))
+        check(all(0 <= v < 4800 for v in values), 'index outside registered data')
+        return values
+
+    selected_indices, baseline_indices = index_values(indices), index_values(base_indices)
+    check(len(selected_indices) == 1008 and len(baseline_indices) >= 1008 and
+          selected_indices == baseline_indices[:1008], 'wrong registered first-21-update indices')
+    expected_layers = []
+    for i, width in enumerate(blocks):
+        expected_layers += [(f'linear_fwd_{i:02}', [dims[i][0], width]), (f'linear_lrn_{i:02}', [width, 16])]
+    expected_layers += [(f'linear_{len(blocks):02}', [blocks[-1], 32]), (f'linear_{len(blocks)+1:02}', [32, 16])]
+    entries = seed['init_weights']
+    check(isinstance(entries, list) and len(entries) == len(expected_layers), 'wrong imported weight coverage')
+    for entry, (name, shape) in zip(entries, expected_layers):
+        rel = f'{weights}/{name}.npy'
+        check(entry['file'] == f'init_weights_emlp{number}_seed0/{name}.npy' and entry['shape'] == shape and
+              entry['orientation'] == 'in x out' and entry['sha256'] == hashlib.sha256(read(rel)).hexdigest(), 'imported weight manifest/hash mismatch')
+    manifest = doc(f'{R52_DATA}/data_manifest.json')
+    expected_data = {'train_images_14x14.npy': [4800, 196], 'train_labels.npy': [4800],
+                     'test_images_14x14.npy': [10000, 196], 'test_labels.npy': [10000]}
+    check(isinstance(manifest['files'], list) and len(manifest['files']) == 4 and
+          {v['file'] for v in manifest['files']} == set(expected_data), 'wrong data manifest files')
+    for entry in manifest['files']:
+        check(entry['shape'] == expected_data[entry['file']] and entry['sha256_npy_file'] ==
+              hashlib.sha256(read(f'{R52_DATA}/' + entry['file'])).hexdigest(), 'registered data manifest/hash mismatch')
+    result.update(status='success', data=d)
+    result['sources'] += [(selected, field) for field in ('provenance', 'all_checks_pass', 'checks', 'setup.seed',
+                           'plan.stage_dims', 'plan.updates', 'measured.updates', 'measured.samples', 'measured.total',
+                           'measured.every_update_equals_prediction', 'twin.max_abs_diff')]
+    result['sources'].append((state_rel, 'output_sha256'))
+    return result
+
+
 def table_accuracy(s, inp):
     t = Table('accuracy_vs_reboot', 'Test accuracy against ReBoot (R-M3-15)',
               ['Row', 'Setting', 'Seeds', 'Test acc (%)', 'Twin (%)', 'Reference (%)', 'Δ (pt)', 'Gate'], wide=True)
@@ -523,14 +806,38 @@ def table_accuracy(s, inp):
         t.row([f'hekit encrypted WN, B = {b}', 'subset', '1 (seed 0)', Cell(pct(acc), [acs]), Cell(pct(twin), [tws]),
                Cell(pct(rb), [rbs]), Cell(f'{100 * (acc - rb):+.2f}', [acs, rbs]), 'not a gate'])
     for key, label in (('R-52-1', 'hekit encrypted eMLP-2, B = 48 (196)'), ('R-52-2', 'hekit encrypted eMLP-3, B = 48 (196)')):
-        rel = inp.path(key)
-        if rel is None:
+        result = r52_input(s, inp, key)
+        if result is None:
             t.row([label, 'subset 1008', '1', inp.pending(key), inp.pending(key), '', '', 'twin check'])
+            continue
+        src, rel = result['sources'], result['rel']
+        if result['status'] != 'success':
+            t.row([label, 'registered subset (incomplete)', '—',
+                   Cell(f'{result["status"]} (child exit {result["rc"]}; watchdog {str(result["watchdog"]).lower()}; {result["reason"]})', src),
+                   '—', '—', '—', 'not accepted'])
         else:
-            acc, acs = s.num(rel, 'evaluation.test_acc_encrypted_trained')
-            twin, tws = s.num(rel, 'evaluation.test_acc_twin')
-            t.row([label, 'subset 1008', '1 (seed 0)', Cell(pct(acc), [acs]), Cell(pct(twin), [tws]), '—',
-                   Cell(f'{100 * (acc - twin):+.2f} vs twin', [acs, tws]), 'twin check'])
+            d = result['data']
+            acc, twin = d['evaluation']['test_acc_encrypted_trained'], d['evaluation']['test_acc_twin']
+            acs, tws = (rel, 'evaluation.test_acc_encrypted_trained'), (rel, 'evaluation.test_acc_twin')
+            t.row([label, Cell('subset 1008', [(rel, 'measured.samples')]),
+                   Cell('1 (baseline seed 0; RNG 32)', [(rel, 'setup.seed'), (rel, 'setup.init_weights')]),
+                   Cell(pct(acc), [acs] + src), Cell(pct(twin), [tws] + src), '—',
+                   Cell(f'{100 * (acc - twin):+.2f} vs twin', [acs, tws]), Cell('twin check', src)])
+            t.note(f'{key}: 21 updates; 1008 samples; one imported baseline seed0 trajectory with binary RNG32, '
+                   'not independent seeds or a full-length run. No ReBoot wall-time ratio is claimed.', src)
+            for i, diag in enumerate(d['twin']['handoff_bootstraps']):
+                fields = ('slots_compared', 'max_abs_input_twin', 'inputs_above_1', 'precondition_hit', 'max_abs_err_vs_twin')
+                t.note(f'{key} handoff {i + 1}: compared {diag["slots_compared"]} valid-sample/width slots; '
+                       f'max |input| {diag["max_abs_input_twin"]:.6g}; inputs above 1: {diag["inputs_above_1"]}; '
+                       f'precondition hit {str(diag["precondition_hit"]).lower()}; max error {diag["max_abs_err_vs_twin"]:.6g}. '
+                       'Numerical check success does not erase a precondition hit.',
+                       [(rel, f'twin.handoff_bootstraps[{i}].{field}') for field in fields])
+            t.note(f'{key}: P52 records input paths, not consumed input digests. Current registered index prefixes, '
+                   'weight/data manifest hashes are checked; this is not historical input-byte proof. '
+                   'Scientific acceptance and handoff-precondition interpretation remain separate review.', src)
+        t.note(f'{key} captured original/source SHA256 (not historical execution proof): ' +
+               '; '.join(f'{path} = {hashlib.sha256(raw).hexdigest()}' for path, raw in result['raw'].items()),
+               [(path, 'raw bytes (SHA256 at table generation)') for path in result['raw']])
     t.section('Reference only: the paper value and the released code at the paper setting (R-REB-3)')
     paper, ps = s.num(TASK51['mnist'][0], 'target.test_acc_mean')
     paper_sd, pss = s.num(TASK51['mnist'][0], 'target.test_acc_std')
diff --git a/tools/test_paper_tables.py b/tools/test_paper_tables.py
index 60f302a..572fab3 100644
--- a/tools/test_paper_tables.py
+++ b/tools/test_paper_tables.py
@@ -24,7 +24,9 @@ def archived_overlay(root, source=ROOT):
         dest.mkdir(parents=True, exist_ok=True)
         for p in (source / base).iterdir():
             q = dest / p.name
-            if (q.exists() or p.name in ('run_all', 'tables', 'R-41-FULL-1', 'R-41-FULL-2', 'R-47-3',
+            if (q.exists() or p.name in ('run_all', 'tables', 'R-41-FULL-1', 'R-41-FULL-2', 'R-47-3', 'R-52',
+                                         'mnist196_emlp2_ni_b48_subset1008_seed0.json',
+                                         'mnist196_emlp3_ni_b48_subset1008_seed0.json',
                                          'ablation_cuda.json', 'ablation_cpu_l7.json')):
                 continue
             if p.is_file() or (p.is_dir() and base.endswith('/raw')) or p.name == 'reference':
@@ -90,6 +92,126 @@ def put_r47(root, rc=0, watchdog=False, log=R47_LOG):
     return dest
 
 
+R52_PIN = '9305d2e1f4f9999296cd4b4aaf55ea631fbca78e'
+R52_WD = '/home/kmihara/hekit-post-full-clones/hekit-post-full-r52'
+
+
+def put_r52(root, number=2, rc=0, watchdog=False, partial=False, output=True):
+    """Tiny SYNTHETIC P52-shaped data and original-format records, never measurements."""
+    key = f'R-52-{number-1}'
+    rel = f'results/quadruped/mnist196_emlp{number}_ni_b48_subset1008_seed0.json'
+    archive = root / 'results/quadruped/raw/R-52' / key
+    archive.mkdir(parents=True, exist_ok=True)
+    raw = root / 'results/quadruped/raw/reboot_emlp23_full'
+    cfg = json.loads((ROOT / tables.REBOOT_23_CFG).read_bytes())
+    if raw.is_symlink():
+        raw.unlink()
+    raw.mkdir(exist_ok=True)
+    for model in (2, 3):
+        seed = cfg['models'][f'emlp{model}']['per_seed']['0']
+        for entry in seed['init_weights']:
+            dest = raw / entry['file']
+            dest.parent.mkdir(exist_ok=True)
+            dest.write_bytes(b'SYNTHETIC weight payload')
+            entry['sha256'] = hashlib.sha256(dest.read_bytes()).hexdigest()
+        (raw / seed['indices_file']).write_bytes((ROOT / f'results/reboot_emlp{model}_seed0_steps1-21_indices.txt').read_bytes())
+    (raw / 'config_values.json').write_text(json.dumps(cfg))
+    data = root / 'results/quadruped/data/reboot_emlp1_full'
+    data.mkdir(parents=True, exist_ok=True)
+    manifest = json.loads((ROOT / 'results/quadruped/data/reboot_emlp1_full/data_manifest.json').read_bytes())
+    for item in manifest['files']:
+        dest = data / item['file']
+        dest.write_bytes(b'SYNTHETIC data payload')
+        item['sha256_npy_file'] = hashlib.sha256(dest.read_bytes()).hexdigest()
+    (data / 'data_manifest.json').write_text(json.dumps(manifest))
+    argv = ['target/release/mnist', '--mode', 'noninteractive', '--placement', 'when_needed',
+            '--batch', '48', '--faithful', '--blocks', '64' if number == 2 else '128,64',
+            '--hidden', '32', '--dataset-npy', 'results/quadruped/data/reboot_emlp1_full',
+            '--indices', f'results/reboot_emlp{number}_seed0_steps1-21_indices.txt',
+            '--init-weights', f'results/quadruped/raw/reboot_emlp23_full/init_weights_emlp{number}_seed0',
+            '--init-weights-manifest', 'results/quadruped/raw/reboot_emlp23_full/config_values.json',
+            '--epochs', '1', '--transpose', 'reuse', '--out', rel]
+    start = 1794099600.0  # 2026-11-08T10:00:00+09:00
+    blocks = [64] if number == 2 else [128, 64]
+    dims = [[196, 64, 16], [64, 32, 16]] if number == 2 else [[196,128,16], [128,64,16], [64,32,16]]
+    boots = len(blocks)
+    def counter(mult):
+        return {'rotations': (60+69*boots)*mult, 'relins': (40+40*boots)*mult,
+                'sse_switches': 2*boots*mult, 'key_switches': (100+111*boots)*mult,
+                'bootstraps': boots*mult, 'ct_ct_tensor': 2*mult, 'ct_pt_mults': 3*mult, 'rescales': 4*mult}
+    doc = {
+      'provenance': {'written_by': 'the mnist binary (raw output, not assembled)', 'git_commit': R52_PIN,
+        'git_modified_tracked_files': 'none', 'command_line': ' '.join(argv),
+        'build': {'debug_assertions': False, 'package_version': '1.0.0', 'target_os': 'linux',
+                  'target_arch': 'x86_64', 'features': {'parallel': True, 'cuda': False}},
+        'parallel_feature': True, 'machine': {'host': 'synthetic-host', 'cpu': 'synthetic CPU', 'os': 'Linux'},
+        'threads': 'rayon (feature parallel), RAYON_NUM_THREADS = 12, 32 logical CPUs',
+        'started_unix': start+1, 'finished_unix': start+9},
+      'all_checks_pass': rc == 0,
+      'checks': {k: True for k in ('every_update_equals_prediction', 'twin_weights_within_2^-10',
+                                  'test_acc_diff_within_0.005', 'handoff_err_within_2^-10')},
+      'task': 'Task 52: ReBoot eMLP-2/3 block structure, non-interactive (bootstrapping)',
+      'setup': {'params':'n16_boot', 'log_n':16, 'batch':48, 'seed':32, 'transpose_keys':'reuse', 'boot_ks':111,
+                'init_weights': argv[argv.index('--init-weights')+1], 'biases':False,
+                'eval_config': {'hoist':True, 'bsgs':True, 'lazy_relin':True, 'default':True}, 'lr_reference_on_mean_gradient':0.024,
+                'lr_schedule':'constant'},
+      'plan': {'stage_dims':dims, 'layout_d':256, 'lanes':64, 'micro_batches_per_update':1,
+               'placement':'when_needed', 'updates':21, 'boot_ks_assumed':111,
+               'start_level':20, 'bootstrap_output_level':21, 'levels_per_stage_step':7,
+               'stage_nonboot_ks_per_update':[50,50] if number == 2 else [34,33,33], 'nonboot_ks_per_update':100,
+               'weight_bootstraps_per_update_avg':0.0, 'handoff_bootstraps_per_update':boots,
+               'velocity_reference_shift_rotations':10, 'predicted_ks_per_sample':counter(21)['key_switches']/1008,
+               'boot_schedules':[[0]*21 for _ in dims]},
+      'measured': {'updates':21, 'samples':1008, 'total':counter(21), 'per_update_first':counter(1),
+                   'ks_per_sample_incl_bootstraps':counter(21)['key_switches']/1008,
+                   'predicted_ks_this_run':counter(21)['key_switches'], 'measured_over_predicted':1.0,
+                   'every_update_equals_prediction':True, 'handoff_bootstraps':boots*21},
+      'time_s': {'keygen_total':1.0, 'train_total':2.0, 'bootstrap_total':1.0, 'wall_total':5.0,
+                 'per_update':{'min':0.1,'median':0.1,'mean':0.1,'max':0.1}},
+      'twin': {'max_abs_diff':0.0, 'log2_max_abs_diff':None,
+               'max_abs_handoff_activation_per_block':[0.5]*len(blocks),
+               'handoff_bootstraps':[{'slots_compared':1008*w, 'max_abs_input_twin':0.5, 'inputs_above_1':0,
+                 'precondition_hit':False, 'max_abs_err_vs_twin':0.0, 'log2_max_abs_err_vs_twin':None} for w in blocks]},
+      'evaluation':{'test_samples':10000, 'test_acc_encrypted_trained':0.9, 'test_acc_twin':0.9, 'test_acc_diff':0.0},
+      'memory':{'peak_rss_bytes':1000},
+    }
+    if rc:
+        doc['checks']['handoff_err_within_2^-10'] = False
+    dest = root / rel
+    if dest.is_symlink():
+        dest.unlink()
+    if output:
+        dest.write_text(json.dumps(doc))
+    elif dest.exists():
+        dest.unlink()
+    meta = {'job':key, 'host':'synthetic-host', 'workdir':R52_WD, 'command':' '.join(argv),
+            'hekit_synced_commit':['commit 9305d2e','full '+R52_PIN,'dirty_files 0'],
+            'threads_cap':12, 'env_thread_caps':{name:'12' for name in ('OMP_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS')},
+            'nice':10,'gpu_job':False,'start':'2026-11-08T10:00:00+09:00','end':'2026-11-08T10:00:10+09:00',
+            'wall_s_runner':10.0,'exit_status':rc,'watchdog_killed':watchdog}
+    state = {'job':key,'rc':rc,'wrapper_rc':0,'status':'failed: RSS watchdog' if watchdog else 'partial' if partial else 'failed' if rc else 'done',
+             'skip':False,'skip_lines':[],'command':argv,'workdir':R52_WD,'log':f'/home/kmihara/hekit-runs/logs/{key}.log',
+             'evidence_lines':[]}
+    if output and not rc:
+        state['output_sha256'] = hashlib.sha256(dest.read_bytes()).hexdigest()
+    for name,text in {'meta.json':json.dumps(meta),'state.json':json.dumps(state),'cmd.txt':' '.join(argv)+' \n',
+                      'post.txt':'date: 2026-11-08T10:00:10+09:00\nJOB_DONE rc='+str(rc)+'\n',
+                      'program.log':'SYNTHETIC terminal log\n'}.items():
+        (archive/name).write_text(text)
+    if partial:
+        limit = 12240.0 if number == 2 else 23040.0
+        (archive/'partial.txt').write_text(f'partial: after >=5 updates; projected {2*limit:.0f} > {limit} s\n')
+        (archive/'projection.txt').write_text(f'after 5 updates: {2*limit:.0f} s / 21 updates; limit {limit} s\n')
+        (archive/'partial-identities.json').write_text('[[122, null], [123, "456"]]')
+    return dest, archive
+
+
+def refresh_r52_digest(dest, archive):
+    state=json.loads((archive/'state.json').read_text())
+    state['output_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
+    (archive/'state.json').write_text(json.dumps(state))
+
+
 class PaperTablesTests(unittest.TestCase):
     def setUp(self):
         self.tmp = tempfile.TemporaryDirectory()
@@ -442,5 +564,188 @@ class PaperTablesTests(unittest.TestCase):
             self.assertEqual(sentinel.read_text(), 'SYNTHETIC original')
 
 
+    def test_r52_success_models_validate_original_schema_and_seed_handoff_sources(self):
+        # Break caught: raw two-number intake, wrong block schema, or hidden seed/precondition scope.
+        for number in (2,3):
+            dest, archive = put_r52(self.root, number)
+            doc=json.loads(dest.read_text())
+            doc['twin']['handoff_bootstraps'][0].update(max_abs_input_twin=1.2,inputs_above_1=2,precondition_hit=True)
+            doc['twin']['max_abs_handoff_activation_per_block'][0]=1.2
+            dest.write_text(json.dumps(doc)); refresh_r52_digest(dest,archive)
+        t=self.build(tables.table_accuracy)
+        new=[r for r in rows(t) if r[0].startswith('hekit encrypted eMLP-')]
+        self.assertEqual(len(new),2)
+        for r in new:
+            self.assertEqual(r[2],'1 (baseline seed 0; RNG 32)')
+            self.assertEqual(r[3:5],['90.00','90.00'])
+        md=tables.render_md(t,'synthetic/')
+        self.assertIn('21 updates; 1008 samples',md)
+        self.assertIn('inputs above 1: 2',md)
+        self.assertIn('not independent seeds',md)
+        self.assertIn('historical input-byte proof',md)
+        src='\n'.join(tables.source_lines(t))
+        self.assertIn('twin.handoff_bootstraps[0].slots_compared',src)
+        self.assertIn('raw/R-52/R-52-1/post.txt\tline 2',src)
+        self.assertIn('setup.seed',src)
+
+    def test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy(self):
+        # Break caught: P52 writes failed-check JSON before exiting nonzero.
+        for rc,watchdog,partial,output in ((1,False,False,True),(143,True,False,True),
+                                          (0,True,False,True),(1,False,False,False),(143,False,True,False)):
+            with self.subTest(rc=rc,watchdog=watchdog,partial=partial):
+                dest,archive=put_r52(self.root,rc=rc,watchdog=watchdog,partial=partial,output=output)
+                t=self.build(tables.table_accuracy)
+                r=next(r for r in rows(t) if r[0].startswith('hekit encrypted eMLP-2,'))
+                self.assertIn('partial/unmeasured' if partial else 'failed/unmeasured',r[3])
+                self.assertEqual(r[4],'—')
+                self.assertNotEqual(r[7],'twin check')
+                for name in ('partial.txt','projection.txt','partial-identities.json'):
+                    if (archive/name).exists(): (archive/name).unlink()
+
+    def test_r52_rejects_missing_partial_or_inconsistent_original_terminal(self):
+        # Break caught: binary-only success or incomplete/contradictory terminal association.
+        for name in ('program.log','meta.json','post.txt','cmd.txt','state.json'):
+            dest,archive=put_r52(self.root)
+            (archive/name).unlink()
+            with self.subTest(name=name),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
+        for name,key,value in [('meta.json','hekit_synced_commit',['full '+'a'*40]),('meta.json','threads_cap',1),
+            ('meta.json','nice',0),('meta.json','gpu_job',True),('meta.json','exit_status',1),
+            ('meta.json','start','2026-11-08T10:00:00'),('meta.json','workdir','/tmp/wrong'),
+            ('state.json','rc',1),('state.json','status','failed'),('state.json','output_sha256','a'*64),
+            ('state.json','command',['other']),('state.json','job','R-52-2')]:
+            dest,archive=put_r52(self.root)
+            d=json.loads((archive/name).read_text());d[key]=value;(archive/name).write_text(json.dumps(d))
+            with self.subTest(name=name,key=key),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
+        dest,archive=put_r52(self.root,output=False)
+        with self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
+        dest,archive=put_r52(self.root,partial=True,rc=143,output=False)
+        (archive/'projection.txt').unlink()
+        with self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
+
+    def test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff(self):
+        # Break caught: a plausible accuracy overrides failed scientific/provenance/coverage fields.
+        mutations=[
+          ('all_checks_pass',False),('checks.handoff_err_within_2^-10',False),
+          ('provenance.git_commit','a'*40),('provenance.written_by','runner'),
+          ('provenance.git_modified_tracked_files',' M tracked.rs'),('provenance.command_line','mnist'),
+          ('provenance.build.features.cuda',True),('provenance.threads','RAYON_NUM_THREADS = 1'),
+          ('provenance.finished_unix',1794099700),('setup.seed',0),('setup.params','small'),
+          ('setup.init_weights','other'),('setup.eval_config.hoist',1),('plan.layout_d',256.0),('plan.stage_dims',[[196,128,16],[128,64,16],[64,32,16]]),
+          ('measured.updates',20),('measured.samples',960),('measured.total.key_switches',0),
+          ('measured.predicted_ks_this_run',0),('measured.handoff_bootstraps',0),
+          ('twin.max_abs_diff',0.01),('twin.log2_max_abs_diff',-10),
+          ('twin.handoff_bootstraps.0.slots_compared',0),('twin.handoff_bootstraps.0.max_abs_err_vs_twin',0.01),
+          ('twin.handoff_bootstraps.0.precondition_hit',True),('twin.handoff_bootstraps.0.inputs_above_1',999999),
+          ('evaluation.test_acc_twin',0.8),('evaluation.test_acc_encrypted_trained',1.1),
+        ]
+        for field,value in mutations:
+            dest,archive=put_r52(self.root);d=json.loads(dest.read_text());node=d
+            parts=field.split('.')
+            for part in parts[:-1]: node=node[int(part)] if isinstance(node,list) else node[part]
+            node[parts[-1]]=value;dest.write_text(json.dumps(d));refresh_r52_digest(dest,archive)
+            with self.subTest(field=field),self.assertRaises(tables.TableError): self.build(tables.table_accuracy)
+
+    def test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero(self):
+        # Break caught: the queue can reject written output/provenance after a child exits zero.
+        dest,archive=put_r52(self.root)
+        state=json.loads((archive/'state.json').read_text())
+        state.update(status='failed: output checks/provenance',output_error='output checks/provenance do not match pinned invocation')
+        del state['output_sha256'];(archive/'state.json').write_text(json.dumps(state))
+        r=next(r for r in rows(self.build(tables.table_accuracy)) if r[0].startswith('hekit encrypted eMLP-2,'))
+        self.assertIn('failed/unmeasured',r[3]);self.assertEqual(r[4],'—')
+        state['output_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
+        (archive/'state.json').write_text(json.dumps(state))
+        with self.assertRaises(tables.TableError):self.build(tables.table_accuracy)
+
+    def test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow(self):
+        # Break caught: rounded projected time can equal the limit although the decision exceeded it;
+        # queue output validation may subsequently replace the partial/watchdog status after child0.
+        dest,archive=put_r52(self.root,rc=0,partial=True,output=True)
+        (archive/'partial.txt').write_text('partial: after >=5 updates; projected 12240 > 12240.0 s\n')
+        (archive/'projection.txt').write_text('after 5 updates: 12240 s / 21 updates; limit 12240.0 s\n')
+        r=next(r for r in rows(self.build(tables.table_accuracy)) if r[0].startswith('hekit encrypted eMLP-2,'))
+        self.assertIn('partial/unmeasured',r[3])
+        state=json.loads((archive/'state.json').read_text())
+        state.update(status='failed: output checks/provenance',output_error='stale output file')
+        del state['output_sha256'];(archive/'state.json').write_text(json.dumps(state))
+        r=next(r for r in rows(self.build(tables.table_accuracy)) if r[0].startswith('hekit encrypted eMLP-2,'))
+        self.assertIn('partial/unmeasured',r[3])
+
+    def test_r52_nonzero_errors_and_registered_input_prefix_validation(self):
+        # Break caught: demanding null for every log2 error, or accepting a different input prefix.
+        dest,archive=put_r52(self.root);d=json.loads(dest.read_text())
+        d['twin']['max_abs_diff']=2**-12;d['twin']['log2_max_abs_diff']=-12.0
+        d['twin']['handoff_bootstraps'][0].update(max_abs_err_vs_twin=2**-12,log2_max_abs_err_vs_twin=-12.0)
+        dest.write_text(json.dumps(d));refresh_r52_digest(dest,archive)
+        self.build(tables.table_accuracy)
+        indices=self.root/'results/reboot_emlp2_seed0_steps1-21_indices.txt'
+        content=indices.read_text()
+        if indices.is_symlink():indices.unlink()
+        indices.write_text('0 '*1008)
+        with self.assertRaises(tables.TableError):self.build(tables.table_accuracy)
+        indices.write_text(content)
+        # Late child failure invalidates even a fully successful saved result object.
+        meta=json.loads((archive/'meta.json').read_text());meta['exit_status']=1
+        (archive/'meta.json').write_text(json.dumps(meta))
+        state=json.loads((archive/'state.json').read_text());state.update(rc=1,status='failed')
+        (archive/'state.json').write_text(json.dumps(state))
+        (archive/'post.txt').write_text('date: 2026-11-08T10:00:10+09:00\nJOB_DONE rc=1\n')
+        r=next(r for r in rows(self.build(tables.table_accuracy)) if r[0].startswith('hekit encrypted eMLP-2,'))
+        self.assertIn('failed/unmeasured',r[3])
+
+    def test_r52_registered_input_hash_failure_is_not_success(self):
+        # Break caught: consuming result identities against mismatched supported input/manifest hashes.
+        dest,archive=put_r52(self.root)
+        weight=self.root/'results/quadruped/raw/reboot_emlp23_full/init_weights_emlp2_seed0/linear_fwd_00.npy'
+        weight.write_bytes(b'SYNTHETIC corrupt weight')
+        with self.assertRaises(tables.TableError):self.build(tables.table_accuracy)
+        dest,archive=put_r52(self.root)
+        data=self.root/'results/quadruped/data/reboot_emlp1_full/train_labels.npy'
+        data.write_bytes(b'SYNTHETIC corrupt data')
+        with self.assertRaises(tables.TableError):self.build(tables.table_accuracy)
+
+    def test_r52_run_all_alias_requires_same_terminal_originals_and_bytes(self):
+        # Break caught: generic new_result bypass or substituting an unrelated canonical original.
+        dest,archive=put_r52(self.root)
+        alias=self.root/'results/run_all/full/ni196_emlp2_b48_sub1008_s0.json'
+        alias.parent.mkdir(parents=True);alias.write_bytes(dest.read_bytes())
+        s=tables.Store(self.root);t=tables.table_accuracy(s,tables.Inputs(s,'full'))
+        self.assertTrue(any('1 (baseline seed 0; RNG 32)' in r for r in rows(t)))
+        d=json.loads(alias.read_text());d['evaluation']['test_acc_twin']=0.89;alias.write_text(json.dumps(d))
+        s=tables.Store(self.root)
+        with self.assertRaises(tables.TableError):tables.table_accuracy(s,tables.Inputs(s,'full'))
+        alias.write_bytes(dest.read_bytes());dest.unlink()
+        s=tables.Store(self.root);tables.table_accuracy(s,tables.Inputs(s,'full'))
+        (archive/'post.txt').unlink()
+        s=tables.Store(self.root)
+        with self.assertRaises(tables.TableError):tables.table_accuracy(s,tables.Inputs(s,'full'))
+
+    def test_r52_error_atomicity_quick_and_both_entrypoints(self):
+        # Break caught: partial paper writes, quick contamination, or entrypoint divergence.
+        dest,archive=put_r52(self.root);(archive/'post.txt').write_text('JOB_DONE rc=1\n')
+        with contextlib.redirect_stderr(io.StringIO()),contextlib.redirect_stdout(io.StringIO()):
+            self.assertEqual(tables.main(['--root',str(self.root)]),2)
+            self.assertFalse((self.root/'paper').exists())
+            self.assertEqual(tables.main(['--root',str(self.root),'--from-run-all','quick']),0)
+        put_r52(self.root)
+        for entry in ('paper_tables.py','tables.py'):
+            p=subprocess.run([sys.executable,str(ROOT/'tools'/entry),'--root',str(self.root),'--sources','accuracy_vs_reboot'],capture_output=True,text=True)
+            self.assertEqual(p.returncode,0,p.stderr)
+            self.assertIn('baseline seed 0; RNG 32',p.stdout)
+
+    def test_r52_future_archive_and_result_overlay_isolation(self):
+        # Break caught: a future real R52 raw/result symlink overwritten by synthetic fixture writes.
+        with tempfile.TemporaryDirectory() as source,tempfile.TemporaryDirectory() as fixture:
+            source,fixture=Path(source),Path(fixture)
+            for rel in ('docs','results/quadruped/raw/R-52'):(source/rel).mkdir(parents=True,exist_ok=True)
+            result=source/'results/quadruped/mnist196_emlp2_ni_b48_subset1008_seed0.json'
+            result.write_text('SYNTHETIC original');sentinel=source/'results/quadruped/raw/R-52/original'
+            sentinel.write_text('SYNTHETIC original');archived_overlay(fixture,source)
+            self.assertFalse((fixture/'results/quadruped/raw/R-52').exists())
+            self.assertFalse((fixture/'results/quadruped'/result.name).exists())
+            (fixture/'results/quadruped'/result.name).write_text('SYNTHETIC replacement')
+            self.assertEqual(result.read_text(),'SYNTHETIC original');self.assertEqual(sentinel.read_text(),'SYNTHETIC original')
+
+
 if __name__ == '__main__':
     unittest.main()
```

stderr (verbatim):
```text
```

Final handoff: source/terminal/data acceptance remains bounded as documented; no experiments were executed, real R52 results were not written or collected, R48 was not changed, and full Task54/Step3/4 remains incomplete. No unresolved focused test failure remains.
