# Root pre-edit ruling: owned SIGSTOP in the native grace test

Adopt the author's finite proposal only for the existing rss-term-grace-kill native scenario. A private native-only method may send Signal::STOP through the already acquired, unreaped, identity-checked pidfd of its own direct test child. No raw-PID signal, arbitrary signal option, additional process or production API expansion is allowed. Production stop dispatch remains TERM/KILL only. No current native/server execution is authorized.

The test must first observe the actual stopped state of that same live child, recording PID/start/boot, status and common-clock times. A STOP syscall success alone does not prove the child stopped; pre-existing exit or identity loss cannot count as success. Only then inject the threshold event into the actual stop/monitor path. Preserve real TERM, at least the existing five-second grace from the actual applicable TERM batch, actual survivor KILL and owned exit/reap. Check actual wait status and timestamps; do not label a child that exited before KILL as a successful KILL-escalation observation. Use current pending signal fields if claiming TERM pending was directly observed; otherwise describe only the issued TERM and measured stopped/live behavior.

Raw faults must explicitly contain owned-sigstop-injected and the existing threshold_event_injected=true only for this named scenario. It measures stop/grace/escalation under intentional SIGSTOP, not a 90GiB allocation/crossing, a naturally TERM-resistant workload or normal graceful termination. Other success/refusal probes still cover their actual distinct behavior.

All errors after STOP retain custody/lock and enter the same lawful own-child TERM/grace/KILL/reap cleanup. Do not strand a stopped child by returning an ordinary error. Existing60s validity deadline does not waive five-second grace, authorize unknown targets or fabricate closure. Clock loss uses only the adopted cleanup fallback and leaves the probe invalid/unresolved; no fabricated native elapsed time. Before edit add independent expected STOP-before-injection ordering, actual-state requirement, early-exit/identity-loss refusal, no-KILL-before-grace and post-STOP-error cleanup checks; retain original RED/snapshot. Later finalized Linux execution is still required.

Reason: a deliberately stopped child gives a bounded actual-kernel escalation case without installing a signal handler or adding project unsafe code. Pure synthetic signal traces do not test syscalls; changing production signal policy or installing new dependencies would broaden scope unnecessarily. Cost: one private fault method, actual stop/status observation, explicit injected-condition labels and additional cleanup cases. This does not claim SIGSTOP reproduces a real resource overrun or every unresponsive process.

Existing rustix1.1.6 process::pidfd_send_signal is a safe callable API and Signal::STOP is present in its cached source. Linux signal(7) documents STOP's stop action; pidfd_send_signal(2) documents targeting through the descriptor. These references establish API/semantics, not executed evidence:
- https://man7.org/linux/man-pages/man7/signal.7.html
- https://man7.org/linux/man-pages/man2/pidfd_send_signal.2.html

Recorded UTC 2026-11-07T23:31:59.779805+00:00
