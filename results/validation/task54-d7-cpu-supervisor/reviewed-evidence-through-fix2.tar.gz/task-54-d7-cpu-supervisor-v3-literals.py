#!/usr/bin/env python3
"""Independent small canonical byte fixture; imports no project implementation."""
import hashlib
import json
import pathlib
import struct

root = pathlib.Path(__file__).parent
out = root / "task-54-d7-cpu-supervisor-v3-literals.json"
u = lambda n: struct.pack("<Q", n)
def b(value):
    raw = value.encode("ascii") if isinstance(value, str) else value
    return u(len(raw)) + raw
def ref(path, digest):
    return bytes([4]) + b(path) + u(100) + b(digest)
domain = b("hekit-study-reference-encoding-v1") + b("hekit-study-local-approval-v3")
# Exact v2 payload field grammar. No arbitrary native PASS or authority fixture.
body = b("unit-approval") + u(1) + b("docs/study-training-design.md") + b("1" * 64)
body += b("2" * 40) + b("3" * 64) + u(1)
body += bytes([1]) + b("study-train-cpu-serial-linux-clean-v2")
body += b("study-train-session-v1") + b("4" * 64) + b("5" * 64) + b("6" * 64)
host = ref("resource/linux-cpu-observed-v1/host-origin.bin", "a" * 64)
projection = u(1000) + b("/home/unit") + u(21) + u(22)
projection += b("/home/unit/policy") + u(21) + u(23)
projection += b("/repo/results") + u(21) + u(24)
projection += b("7" * 64) + b("8" * 64) + host + host
projection += ref("resource/linux-cpu-observed-v1/native-validation.json", "b" * 64)
raw = domain + body + projection
fixture = {"description": "unit bytes only; no runtime/native facts", "hex": raw.hex(),
           "sha256": hashlib.sha256(raw).hexdigest(), "length": len(raw),
           "projection_offset": len(domain + body), "account_uid": 1000,
           "account_anchor": "/home/unit", "policy_origin": "/home/unit/policy",
           "observation_origin": "/repo/results", "bootstrap_sha256": "7" * 64,
           "physical_host": "8" * 64, "source_manifest": "3" * 64}
with out.open("x") as file:
    json.dump(fixture, file, indent=2)
    file.write("\n")
print(json.dumps({"path": str(out), "length": len(raw), "sha256": fixture["sha256"]}))
