# Runtime output ignore ruling, 2026-11-08

Adopt only /results/resource/ and /results/native-probes/ as anchored .gitignore
entries for the already specified supervisor-owned runtime metadata. Rationale and
alternatives are recorded before implementation in docs/study-resource-operational-design.md.
No clean-source or raw physical inventory gate is weakened, no scientific result /
Reference / Target exclusion is added, and gitignore is not an authority or pass.
Add positive own-runtime-output and negative unrelated-source cases. Native Linux
execution is still not performed. The source author owns the .gitignore edit/tests.
