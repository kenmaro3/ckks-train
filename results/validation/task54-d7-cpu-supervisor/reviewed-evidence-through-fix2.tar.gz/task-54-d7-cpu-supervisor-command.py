#!/usr/bin/env python3
"""Archive one source-task command without overwriting an earlier attempt."""
import datetime
import json
import pathlib
import subprocess
import sys
import time

base = pathlib.Path(__file__).parent / "task-54-d7-cpu-supervisor-evidence"
base.mkdir(exist_ok=True)
label, *argv = sys.argv[1:]
if not label or not argv or any(c not in "abcdefghijklmnopqrstuvwxyz0123456789-_" for c in label):
    raise SystemExit("label and exact argv required")
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
out = base / (stamp + "-" + label)
out.mkdir()
command = {"argv": argv, "cwd": str(pathlib.Path.cwd()), "started_utc": stamp}
(out / "command.json").write_text(json.dumps(command, indent=2) + "\n")
start = time.monotonic_ns()
with (out / "stdout.log").open("xb") as stdout, (out / "stderr.log").open("xb") as stderr:
    child = subprocess.Popen(argv, stdout=stdout, stderr=stderr)
    code = child.wait()
result = {"exit_code": code, "elapsed_ns": time.monotonic_ns() - start,
          "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"directory": str(out), **result}), flush=True)
raise SystemExit(code if code >= 0 else 128 - code)
