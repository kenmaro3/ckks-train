"""Check the correction patch against an isolated copy of reviewed source."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile
import tempfile

ledger = Path(__file__).resolve().parent
prefix = "task-54-d7-cpu-supervisor-"
root = Path.cwd()
original = json.loads((ledger / (prefix + "pins.json")).read_text())
current = json.loads((ledger / (prefix + "fix1-pins.json")).read_text())
with tempfile.TemporaryDirectory(prefix="task54-fix1-patch-") as temporary:
    work = Path(temporary)
    with tarfile.open(ledger / (prefix + "fix1-original.tar.gz")) as archive:
        for entry in original["source_files"]:
            path = entry["path"]
            raw = archive.extractfile(path).read()
            assert len(raw) == entry["bytes"]
            assert hashlib.sha256(raw).hexdigest() == entry["sha256"]
            destination = work / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(raw)
    patch = ledger / (prefix + "fix1.diff")
    subprocess.run(["git", "apply", "--check", "--whitespace=error", str(patch)], cwd=work, check=True)
    subprocess.run(["git", "apply", "--whitespace=error", str(patch)], cwd=work, check=True)
    for entry in current["all_author_source_files"]:
        raw = (work / entry["path"]).read_bytes()
        assert len(raw) == entry["bytes"]
        assert hashlib.sha256(raw).hexdigest() == entry["sha256"]
    print("Original 68 source pins verified; fix patch applied only in isolated temporary directory; all 71 resulting source pins match.")
