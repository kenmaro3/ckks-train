# Task54 integrated CPU Step2 finite test inventory

Written before executable filters and production edits at BASE a29dcf6613ed05d5e1ec7b5300458e74214b5ee9. Test names below are the planned exact constructors; origin tests depend on the pending root ruling and will be amended explicitly before their first execution if the ruling differs. No test has run. This inventory is not a test result.

Pre-edit ruling update: origin v3 and schema amendment adopted by root; same host/namespace FileRef required, fixed4096-byte host projection, per-probe common clock only, acyclic pre-probe filesystem capture/review, isolated native selector cannot create production authority,60s timeout is failure. Source fixtures use one compact bundle. Initial concrete scanner unit names are `d7_supervisor_origin_projection_literal`, `d7_supervisor_origin_reject_mutations`, and `d7_supervisor_origin_stream_fragments`; constructors are `scan_approval` over in-memory Cursor or a one-byte reader, no filesystem/context/registry. Whole fixture is1456 bytes (actual generator length will be recorded, not assumed); exhaustive truncation loop is bounded by that actual literal length. Initial expected RED may be missing module/API compilation, which is not behavioral failure. Additional schedule tests precede their implementation independently.

## Resources and allowed commands

Only deterministic pure unit/Python fixtures on Mac: byte buffers, event enums, fixed fake process tokens, bounded hand-authored proc strings and fake writes. No registry load, `RegisteredCases::select`, dataset decoding/materialization, `CkksParams`, plan geometry, keys/ciphertext, HE/security-N, FP32 training, real process spawn/kill or supervisor invocation. Tests must not dispatch to production context or origin acquisition. Maximum process model four, maximum literal event schedule64, preparation seeds10, work4096 bytes, frame8MiB, diagnostic8MiB, samples64MiB, aggregate raw64MiB/4096 files, each raw8MiB, source512/list65536; no multiplicative reservation. Bound vectors use compact declared lengths where possible rather than allocating cap-sized payloads. Requested Train values: geometry2, initial2, updates2 Quick/2400 Full, handoffs0, wrappers1, receipt64MiB/1,000,000 records. These are grammar checks only and do not execute that work.

Commands after fixtures/RED: exact `cargo test -p ckks-train-bench --lib d7_supervisor_ -- --test-threads=1`; exact selected affected existing tests after inspecting their constructors; pure Python `unittest` module for broker argv/transport using fake streams only. Compile-only `cargo check -p ckks-train-bench --target x86_64-unknown-linux-gnu --all-features --all-targets --locked --offline` uses the already installed target and existing cache; it is not a Linux run. Strict `cargo clippy -p ckks-train-bench --all-features --all-targets --locked --offline -- -D warnings` and appropriate `cargo fmt --check` after changed tests pass. Every attempt gets unique argv/stdout/stderr/result files and actual terminal exit; async handles followed until terminal, never restarted on timeout. No broad workspace tests or repeated passing suites absent changes.

## Fourteen deterministic supervisor schedules

All use the same production transition reducer with a test-only fake backend. Fake process token has an immutable generation and explicit ownership; no OS PID is signaled. Every test compares the whole ordered action list and terminal state against a literal expected schedule authored before reducer code. `Scheduler::new`, `register_owned`, `on_event` are planned private names, not public authority APIs.

| Exact unit test | Input schedule | Required exact oracle |
|---|---|---|
| `d7_supervisor_s01_equal_threshold` | valid initial sample, then94371840KiB at10s | no TERM/KILL; next deadline20s; valid peak94371840 |
| `d7_supervisor_s02_threshold_plus_one` |94371841KiB at10s; one survivor at15s | TERM owned live set once, grace deadline15s, KILL verified survivor only, reap then closure eligibility |
| `d7_supervisor_s03_invalid_sample` | missing RSS or parse/identity/read failure without pidfd-confirmed exit | invalid, TERM, no zero-valued replacement or valid peak update |
| `d7_supervisor_s04_late_sample` |10s due; sample finishes10s+1ns | invalid/missed; no skipped interval or shifted deadline |
| `d7_supervisor_s05_worker_prestart_loss` | worker confirmed exits before durable Start | stop live helpers, prestart_refusal, no scientific result/success |
| `d7_supervisor_s06_worker_poststart_loss` | durable or visible-unconfirmed Start then worker loss | poststart failed/incomplete; never prestart refusal, SIGKILL never labeled OOM |
| `d7_supervisor_s07_supervisor_eof` | authenticated control EOF in worker/Python/trampoline | boundary stop; inherited hold retained through teardown; no pretend interruption of long HE |
| `d7_supervisor_s08_python_loss` | Python confirmed exit while Git live | stop owned live Git by token, retain lock/marker until reap/closure |
| `d7_supervisor_s09_git_loss` | Git failed status after raw switch | bounded failed HelperReply, stop route, no raw bytes interpreted as IPC |
| `d7_supervisor_s10_reparent` | known owned generation reparented to supervisor | preserve same token, sample once, only ledger-matched reap |
| `d7_supervisor_s11_unknown_child` | unknown descendant discovered | unresolved custody, no guessed signal/reap/closure, marker blocks |
| `d7_supervisor_s12_pid_reuse` | same PID with changed start/boot or proc identity | invalid identity, never signal replacement; old confirmed-exit token absent |
| `d7_supervisor_s13_cap_write_failure` | diagnostics/sample/raw cap exhaustion or write/fsync/visible-unconfirmed failure | fail authoritative publication, stop verified owned children, unresolved publication blocks success/closure as appropriate |
| `d7_supervisor_s14_teardown` | result/end then resources still live; final sample/reap/closure | custody outlives owners; no complete before all known exits, no unknown children, exact durable supervisor end and closed marker |

## Ordering, framing and broker

* `d7_supervisor_w23_claim_before_expansion`: literal pending -> waiting worker/pidfd -> initial sample -> durable immutable claim -> Run -> context -> registry -> select/bind -> materialization/parameters -> gates/start. Expected trace excludes any context/registry before Run and any materialization/parameters before bind. Test backend counts forbidden-expansion attempts.
* `d7_supervisor_w24_unconfirmed_claim_refuses_expansion`: context and registry requests before claim, after merely visible claim and after failed dir-sync each reject with no allocation/dispatch action.
* `d7_supervisor_frames_literal_roundtrip`: independently packed u32LE lengths, tags0..8, u64 sequences, exact payloads; partial reads/writes remain bounded and reassemble exact bytes.
* `d7_supervisor_frames_reject_bounds_order_eof`: zero/undersize/8MiB+1 length, unknown tag, duplicate/skipped/overflow sequence, Run-before-Ready, duplicate Hello/Ready, truncated header/body, unexpected EOF and unframed stdout reject.
* `d7_supervisor_poll_preserves_deadline`: continuous readable/writable helper traffic cannot delay a due sampler; bounded drain per poll turn, no blocking `read_to_end`/`wait` in monitor.
* `d7_supervisor_broker_exact_git_argv`: five literal approved suffixes under pinned executable/root and fixed `--no-pager -c core.fsmonitor=false -c core.untrackedCache=false -C ROOT`; diff includes `--no-ext-diff --no-textconv --quiet HEAD --`; argv extra/altered config/path/NUL/item257/byte4097 reject.
* `d7_supervisor_broker_direct_children_and_four_cap`: supervisor/worker/Python/Git only, parent owns every handle and obtains pidfd while unreaped before Run; extra Python/Git and fifth process reject before spawn action.
* `d7_supervisor_helper_exec_handshake`: flag alone fails; wrong parent PID/start/boot/executable/lock identity/common clock fails; expected fd0 continuity and fd1 Ready/Run, explicit Git raw transition only.
* Python `RuntimeBrokerTests.test_runtime_git_uses_broker_only`, `test_build_git_subprocess_stays_explicit`, `test_exact_git_argv`, `test_fragmented_frames_and_sequence`, `test_eof_stops_and_keeps_hold`: inject fake streams and fake build runner; assert runtime never calls `Popen` or kill. They prove Python control behavior, not actual exec/FD preservation.

## Origin, clocks, identity and storage

* `d7_supervisor_origin_projection_literal`: exact independent v3 or ruled launcher bytes, old versions cannot construct live owner; root/hash/source/recipe/physical/boot bindings checked against retained expected source, never parsed-record authority.
* `d7_supervisor_origin_reject_mutations`: fixed path/hash/UID/device/inode mismatch, duplicate/trailing fields, oversized length/count, unsupported namespace/topology/native facts, unpinned expected hash reject. Native origin acquisition itself is not invoked by this test.
* `d7_supervisor_clock_checked_common_origin`: seconds/nanoseconds -> checked u64 ns; negative seconds/nsec, nsec>=1e9, multiplication/add overflow, current<origin refuse; two simulated processes share the same origin and produce comparable elapsed values; absolute monotonic value is never written as elapsed.
* `d7_supervisor_requested_build_identity`: main_i/main_ni Full/Quick exact compiled request bytes and v2 serial/reference recipes; v1 receipt cannot mint owner; actual source/capsule/helper/recipe/executable mismatch refuses. Existing wire W01-W22 and history remain unchanged.
* `d7_supervisor_claim_marker_resolution`: pending-only, malformed/unknown names, unreadable root, wrong retained observation root/hash/end, unresolved end and record65537 block; exact closed link resolves old claim without granting live authority. No deletion, overwrite or PID cleanup.
* `d7_supervisor_capacity_checked_payload`: known incremental payload compared separately to MemAvailable and every finite cgroup ancestor headroom and destination bytes/inodes; equality passes, +1 rejects; overflow/hidden ancestor/unsupported mount/quota refuses. Unknown allocator/runtime/kernel overhead remains explicitly unknown.
* `d7_supervisor_proc_rss_identity`: one VmRSS with kB, duplicate/missing/bad unit/overflow reject; process ledger counted once, confirmed exits absent, disappearance without confirmation invalid.
* `d7_supervisor_storage_aggregate_caps`: checked aggregate before each file, cap equality/+1, file4096/4097, write/fsync/late-visible failure; never4096*8MiB reserved.

## Scope boundary

Source call-chain and Step3 borrow seams must be inspected independently in addition to pure schedules: actual binary -> supervisor -> authenticated worker -> bound owner -> context broker -> registry/request bind. A test-only fake trace cannot establish that routing. Step3's retained data/five producers and Step4's HE/endpoints/results remain separate; no test here calls those unimplemented flows or labels refusal as successful continuation. Existing retained anonymous publisher semantics are reused, not broadly rewritten; any directly changed helper receives its narrow existing tests after constructor inspection. Linux native inherited fd0/OFD, pidfd/start identity, subreaper, same-executable trampoline, nonblocking10s sampling, Git no-descendants, mount/quota/publication durability and actual stable host origin remain separately held gates. Cross-target compilation does not establish them.
