# Independent R48/R52 preparation archive and registration review

Date: 2026-11-08. SPEC: PASS. QUALITY: PASS. No actionable blocking findings. The reviewed archive is an exact preservation of the prior independently reviewed local preparation, and the two request entries and appended documentation accurately register prepared, not-invoked collection.

Scope is the 22 manifest-listed originals and README/manifest in results/validation/postqueue-terminal-collection-preparation-20261108/, the new R-48-COLLECT-1 and R-52-COLLECT-1 request sections, and the appended prepared-state paragraph in docs/post-full-queue.md. Prior collector/controller source verdicts remain unchanged. Only this review file was written; no tests rerun, SSH, source/result/table edits, deployment, Git/index mutation or subagent activity.

## Findings and validation

No required changes.

- All 22 original names and archive names are unique basename-only paths. Every ledger original matches its declared bytes and SHA256; every archive file matches archive_sha256; all 18 plain copies and four decompressed gzip copies equal the corresponding ledger original byte for byte. The archive contains exactly those 22 files plus manifest.json and README.md. No omitted listed item, unexpected extra file, truncation, recomposed result, or altered RED/GREEN transcript was found. Manifest kind is local_operations_preparation_not_measurement and scientific_acceptance is false.
- Archived collector, tests, both controller candidates and comparison-base R47 sources retain the reviewed pins. The independent collector review decompresses to 11908 bytes/SHA ed226271d30ef44509da7fcce2bd9f531e3245331c5d8d4a0b8e6408d4f1e383; the controller review remains 9142 bytes/SHA bb0a2695780eac430f4291ba7a2965342e8fd0f81461672d0f7dd0d42091d027. Both are the exact prior PASS reports, not rewritten verdict summaries.
- README.md:3-11 correctly distinguishes 20 collector tests from one controller unittest with 20 pure subcases; source-absence RED and the real type-RED are described separately. It preserves failed/missing/partial evidence boundaries, the original 15:23 negative check-only evidence, and unexecuted positive production transport branches. Its prepared-not-invoked language is consistent with the review records and the absence of both registered fetch prefixes. This local inspection is not a new remote-state attestation.
- results/quadruped/requests.md:1208-1232 defines exactly one R48 and one R52 collection request. Source size/hash, controller size/hash, compiled family remote command, expected roots, six fresh-only outputs and last-family-record-or-queue-terminal eligibility match the reviewed code. FULL2 final-path presence, original chain terminal/gone and released gate remain required. A family build record is deliberately not required; a released queue can fail before reaching that family. Missing states remain unknown and scientific_acceptance remains false.
- Both requests retain key-only fixed SSH, one attempt, nice 10, 110-second new-local-SSH-child timeout, no research process signals, no automatic retry, 8 MiB per-file / 32 MiB aggregate original-byte limits including rereads, and separate 64 MiB encoded-stdout post-capture validation. The stated RAM value is explicitly expected/unmeasured, not a measured cap. Neither the request prose nor README claims a streaming/stderr hard cap or remote completion on timeout.
- docs/post-full-queue.md:164 adds only the new prepared-state paragraph and links to the retained archive README. Removing this appended paragraph and its extra separator yields the exact previously reviewed document SHA256 09bdab1997d0a1ee0352d159ee2c2d634c34f5c739313c5c5515ba3f7a0d06dc, including the unchanged future canonical R48/R52 archive paragraph at :145. No earlier collection map, gate, scientific acceptance rule or future destination was changed by this append.
- Both new request links and the appended documentation link resolve locally to the intended archive README. Referenced fixed source files are present and byte-exact. The archive is preservation material; actual registered invocation points to the ignored ledger controller and an actual root-reviewed observer prefix, not invented synthetic terminal records.

## Independent read-only verification output

The following local Python verification performed plain/gzip byte comparison, all manifest hash/length checks, directory inventory equality, request pin/command/limit assertions, relative link existence checks, prior-doc hash comparison and prefix absence checks. Exit: 0. No unchanged test suite was rerun.

```text
ARCHIVE_VERIFIED {"originals": 22, "gzip": 4, "plain": 18, "extra_unmanifested_files": [], "all_restored_bytes_equal_ledger": true}
PRIOR_DOC_EXACT 09bdab1997d0a1ee0352d159ee2c2d634c34f5c739313c5c5515ba3f7a0d06dc
REQUEST_SECTIONS {"48": {"bytes": 2419, "sha256": "835c8a67c6c4241a9284e56471eb98d4d1adb0a59c4cc8765a2e9ec1d2f83c74"}, "52": {"bytes": 2418, "sha256": "75a84bfdf0ec634490afcbc3e92e74ba20cd49c968eebd55c7f4ab107e247d24"}}
NEW_LINKS_EXIST True
FETCH_OUTPUTS {"48": [], "52": []}
HASH {"path": "results/validation/postqueue-terminal-collection-preparation-20261108/manifest.json", "bytes": 7394, "sha256": "402cf0b01bc0544d5cd120eb66dbeb7ac08a8c1b4ea52d7bfe211563645f5a81"}
HASH {"path": "results/validation/postqueue-terminal-collection-preparation-20261108/README.md", "bytes": 1931, "sha256": "5a3bcb5121888b568cdc1a3ac4d148f0c31e3713a7f1ede7d9248a5ce425c782"}
HASH {"path": "docs/post-full-queue.md", "bytes": 25164, "sha256": "4db7e2c0aa00be375a8eff9b9f2c2aabb7801766ca515e71de297e6d47566340"}
HASH {"path": "results/quadruped/requests.md", "bytes": 157324, "sha256": "a934e97457d8d17902cef45acce1719f43e1ab5ef5bfb4bd2405dedfaa926bee"}
LINE docs/post-full-queue.md 164 R48/R52 terminal intake preparation is independently reviewed and registered as `R-48-COLLECT-1` / `R-52-COLLECT-1`, both not invoked. The [fixed collector and family controllers](../results/validation/postqueue-terminal-collection-preparation-20261108/README.md) preserve failed/partial outputs and require reviewed terminal observations before collection. This does not change the deployed queue, mark an experiment completed, or accept scientific results.
LINE results/quadruped/requests.md 1208 ## R-48-COLLECT-1: one-shot read-only R48 terminal collection
LINE results/quadruped/requests.md 1221 ## R-52-COLLECT-1: one-shot read-only R52 terminal collection
LINE results/validation/postqueue-terminal-collection-preparation-20261108/README.md 5 No remote collection has occurred. These are operational tools, not research-result JSON. Failed jobs' binary output is retained unchanged, including R52's write-before-failure behavior. Missing terminal records do not prove that a job never ran. R48's ten possible test outputs and conditional SGD paths are finite; R52 partial/projection records remain original evidence. Scientific validation is downstream.
```

The two request-section hashes above cover each heading plus its body through the separator before the next heading (R52 extends to EOF). Whole-file request hash is an observation at review time and may change when unrelated scheduled observation sections are updated.

## Reviewed top-level identities

| File | Bytes | SHA256 |
|---|---:|---|
| `results/validation/postqueue-terminal-collection-preparation-20261108/manifest.json` | 7394 | `402cf0b01bc0544d5cd120eb66dbeb7ac08a8c1b4ea52d7bfe211563645f5a81` |
| `results/validation/postqueue-terminal-collection-preparation-20261108/README.md` | 1931 | `5a3bcb5121888b568cdc1a3ac4d148f0c31e3713a7f1ede7d9248a5ce425c782` |
| `docs/post-full-queue.md` | 25164 | `4db7e2c0aa00be375a8eff9b9f2c2aabb7801766ca515e71de297e6d47566340` |
| `results/quadruped/requests.md` | 157324 | `a934e97457d8d17902cef45acce1719f43e1ab5ef5bfb4bd2405dedfaa926bee` |

Critical unchanged original code pins:

| Source | Bytes | SHA256 |
|---|---:|---|
| task-48-52-terminal-collector.remote.py | 19552 | 354b7787086d4a708579b90b115d598ef6217668f173a73cf4f0c79f2e42d2ea |
| test_task_48_52_terminal_collector.py | 23174 | d76b90d0ae1c75b70e72e4b5f522f4ed82e718b9f5147f3f5eaa9b90e6118ef8 |
| task-48-terminal-controller.py | 7611 | a2ada1a88e64d77372e728e30700e5798c7b02038fe79d81b459ca10efbbd01e |
| task-52-terminal-controller.py | 7611 | 24b142678ad57812625093994bfa5159ef57214d0d3b9846d2631104798388f1 |

Manifest identity above binds all remaining original/archive hashes, each independently checked in this review.

## Boundary

PASS applies to exact local archive custody and the new documentation/registration statements. It does not invoke or release collection, establish actual terminal job state, approve scientific measurements, or claim positive production transport validation. Deliberate root action after a qualifying actual registered observation remains required. Future measurement archive intake and table/report updates remain separate reviewed operations.

