# R48/R52 bounded terminal collector preparation

Status: IMPLEMENTED; local synthetic validation GREEN; independent review pending. No controller or request is registered or released by this report. The script has not been invoked against any production path or remote host.

## Scope and authority

This implements only the finite local preparation in task-48-52-terminal-collector-brief.md. Persistent writes are the owned collector, focused test module, this report and the uniquely prefixed raw local validation records listed below. No root docs, deployed queue/runner, Rust, source tools, real results, generated tables, Git/index or other agents were changed. No subprocess SSH/GPU/HE/Cargo/native/research work was invoked.

Read the deployed queue/runner, the intake map, the exact reviewed R47 source, its tests, initial review and fix1 re-review. Producer job names, source pins, commands and paths are compiled from the deployed queue. R48 has build, R-48-1 tests, R-48-2 NAG, optional R-48-2-sgd, R-48-3 exact NAG/SGD CPU variants and R-48-4 full-level CPU. R52 has build and the eMLP2/eMLP3 subset jobs. The only CLI input is exactly one family, r48 or r52. It accepts no path, executable or command parameters and executes no captured command.

## Implemented acquisition contract

- All payloads, including family-selection and acquisition refusals, carry kind=operational_capture_not_scientific_result and scientific_acceptance=false. An acquisition exit 0 means the bounded reads/operational checks completed; it does not mean every expected file exists, the job succeeded, or scientific acceptance.
- Fixed registered owner PID/start and released-gate configuration are checked before job intake. Primitive types, finite operational JSON, duplicate keys, source pin/clean marker, exact command variants, workdir/log identity, thread/nice/GPU fields, timezone-qualified start/end and runner wall coherence are validated. Gate configuration primitive types are also matched to the fixed original config.
- Runner timestamps have whole-second precision; the start lower bound uses floor(gate.at), preserving the R47 fix. Subsecond ordering remains unresolved. Post snapshot date must be between end and current observation and there must be exactly one final matching JOB_DONE. Wrapper return code is retained separately from the child exit.
- A job without a terminal state is labeled no_terminal_record_observed. Its log, runner artifacts and binary outputs are not read. This is not proof that it never ran. Unknown/missing artifacts are recorded; optional SGD absence is not interpreted as failure or an attempted measurement.
- Present original state/meta/cmd/workdir/post bytes are stored before semantic validation. Only once those identify a coherent terminal job is the program log read and checked against queue skip/evidence/status fields. Coherent failure, OOM, watchdog, SKIP, partial and failed-output-validation states are preserved. R52 partial is a queue operational classification, not a final scientific result.
- Original state/meta and program.log/cmd/workdir/post are captured; optional pre.txt, time.txt, rss.tsv, time.pid and synced-commit.txt are retained. R52 also retains optional partial.txt, projection.txt and partial-identities.json. These ancillary files are preserved verbatim; their scientific meaning is downstream.
- R48-1 reads only the ten documented test JSON paths. Each ablation/R52 binary path is selected by equality with one compiled command, never by trusting an arbitrary --out. Failed jobs' existing binary output is read too, including P52 child1 with all_checks_pass=false. Binary JSON is stored as bytes/hash/path without parsing, repairing or constructing replacement results; malformed scientific output is still original evidence. Missing binary output is explicitly missing, never a fabricated SKIP or success.
- Optional raw R-48-optimizer.json is captured, checked for its finite deployed schema and matched with an observed R-48-3 command when both exist. Optional queue terminal.json is preserved as an execution summary only. Original/final reads of observed job state/meta, optimizer, queue terminal, owner and gate must have identical SHA256 and read stamps. On mismatch, both acquired observations and earlier originals are retained in the refusal payload.
- The reviewed own-regular, O_NOFOLLOW at every path component, O_NONBLOCK and stable-read primitive is copied unchanged. Per-file limit is 8 MiB; total original acquired bytes are at most 32 MiB, including every retained reread. Rejected unsafe/oversized reads are not represented as captured originals. There is no walker or discovery, profiler binary intake, whole growing queue log, R47 recapture or other-family capture.

## Test-first sequence and honest evidence boundary

The first 16 tests were written before creating the new collector, with independent literal queue commands and temporary synthetic files. Initial RED consists of 16 explicit source-absence assertion failures in setup; it establishes missing implementation, not independent behavioral RED execution of each individual assertion. The initial implementation then passed all 16. Both raw transcripts are retained unchanged.

Four additional edge tests were then added. Their RED found a concrete bug: changing config.chain_pid from integer 1700979 to float 1700979.0 was accepted by ordinary Python dictionary numeric equality. The retained type-RED shows expected exit 2 versus actual exit 0. The finite fix now compares each config value's primitive type against the registered original. Final GREEN: 20 tests, 0 failures in 0.503 s. All commands used PYTHONDONTWRITEBYTECODE=1 and a 60 s subprocess timeout.

The focused suite exercises all registered jobs, NAG/SGD selected outputs, all ten R48 test filenames and omission of an unregistered FIFO, R52 failed/watchdog/partial/invalid-output bytes, missing states/required metadata/binary files, malformed/duplicate/nonfinite/deeply nested operational JSON, wrong commands/pins/identity/types/times, post/cmd/workdir mismatch, live-log avoidance, raw preservation on CLI refusal, each metadata reread mutation, symlink/fifo/wrong-owner refusal and byte limits including rereads. Fixtures are explicitly synthetic. Filesystem tests use resolved temporary roots only; no actual mounted/remote artifacts are referenced. Mocking is limited to controlled module path constants and targeted mutation/UID failure injection around the real reader.

The skill's broad project-suite suggestion is overridden by the explicit task prohibition on unrelated/native/HE/Cargo work. No such suite was run or claimed. The unchanged R47 source itself was not rerun: new focused tests exercise the copied reader and the exact helper equality below establishes no helper source change.

## Exact identities

SHA256 values identify bytes at preparation/report time, not historical execution or remote deployment:

```json
[
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector.remote.py",
    "bytes": 19552,
    "sha256": "354b7787086d4a708579b90b115d598ef6217668f173a73cf4f0c79f2e42d2ea"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py",
    "bytes": 23174,
    "sha256": "d76b90d0ae1c75b70e72e4b5f522f4ed82e718b9f5147f3f5eaa9b90e6118ef8"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-red.json",
    "bytes": 14789,
    "sha256": "7750a44480afa7dba2aeeb251893d31997a6777336b516ecc0011f31e18183e3"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-first-green.json",
    "bytes": 2665,
    "sha256": "2219297d8f7973b0fbb5d9fbe26331404eeb101d11065ce84bf3033fd9d97052"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-type-red.json",
    "bytes": 3923,
    "sha256": "7f660c28ae377689f774ca90d0f20b21a054c8f3fda049e349bed380b0669ea5"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-green.json",
    "bytes": 3261,
    "sha256": "94d2bcbc737b63c2088f432a6bebdee473e2e4b68040a773ef63c593a40baffd"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-helper-equality.json",
    "bytes": 623,
    "sha256": "09371b281f08f8746cc64290a0b139fdea2ac06cb6668bf4b295b9cfe89700e6"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-brief.md",
    "bytes": 4647,
    "sha256": "1d970e8412c3d4ef0531fb40464fb8ae22b0c4e9dd2a6dd339897965d8275701"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-47-terminal-collector.remote.py",
    "bytes": 11201,
    "sha256": "8e40fb7efa1cfdb90f826fe4b8b8c6046a876616f695790d5e5c27975c2a0d5a"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-47-terminal-collector-tests.py",
    "bytes": 8455,
    "sha256": "a7f3718992c56fc9e80cdad5d28188d86b5cf7f44da7c9dee1c7f220ecd539b4"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-47-terminal-collector-review.md",
    "bytes": 6697,
    "sha256": "4f1fb4d4fea493dccb8bfa661e7c4d179c72f1d1dd65157f376f24d2cbf7a040"
  },
  {
    "path": ".superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-47-terminal-collector-fix1-review.md",
    "bytes": 2742,
    "sha256": "364c7f4792549bced5e13b7113be9f9d99d2d8c5e8d90f327dd119a73a123d10"
  },
  {
    "path": "results/quadruped/scripts/post_full_queue.py",
    "bytes": 23840,
    "sha256": "1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9"
  },
  {
    "path": "results/quadruped/scripts/run_job.sh",
    "bytes": 4998,
    "sha256": "46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736"
  },
  {
    "path": "docs/post-full-queue.md",
    "bytes": 24704,
    "sha256": "09bdab1997d0a1ee0352d159ee2c2d634c34f5c739313c5c5515ba3f7a0d06dc"
  }
]
```

## Shared helper equality

A read-only Python ast.get_source_segment comparison verified exact equality of unique_object, stamp and read_stable against R47 source SHA256 8e40fb7efa1cfdb90f826fe4b8b8c6046a876616f695790d5e5c27975c2a0d5a. No statements in those helpers were edited. parse_object is deliberately extended for recursive nonfinite-value refusal; it is not claimed unchanged.

```json
{
  "original_sha256": "8e40fb7efa1cfdb90f826fe4b8b8c6046a876616f695790d5e5c27975c2a0d5a",
  "helpers": [
    {
      "helper": "unique_object",
      "bytes": 173,
      "sha256": "5257a0749a852fcf11a4ab7d0c0fa271c1936afa08bf6e84f30b697a7b3bf5cf",
      "unchanged": true
    },
    {
      "helper": "stamp",
      "bytes": 107,
      "sha256": "8f78aba7e9c8d5cffdf7ef3a154af75ed8e39f619d5056d3b69c4625a74810a7",
      "unchanged": true
    },
    {
      "helper": "read_stable",
      "bytes": 2665,
      "sha256": "c276420d527c7a628a5f02e56286bdd0c5b2c9d9fa9776a9b432386c1510234c",
      "unchanged": true
    }
  ]
}
```

## Raw command transcripts

These are the complete recorded stdout/stderr/exit values; no failed run was removed.

### task-48-52-terminal-collector-red.json

Command: `python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_all_r48_jobs_and_exact_ten_test_outputs (__main__.CollectorTests.test_all_r48_jobs_and_exact_ten_test_outputs) ... FAIL
test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader (__main__.CollectorTests.test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader) ... FAIL
test_bad_terminal_identity_argv_types_and_times_refuse_before_output (__main__.CollectorTests.test_bad_terminal_identity_argv_types_and_times_refuse_before_output) ... FAIL
test_cmd_workdir_post_mismatch_retained_before_log_reads (__main__.CollectorTests.test_cmd_workdir_post_mismatch_retained_before_log_reads) ... FAIL
test_each_reread_mutation_preserves_both_observations (__main__.CollectorTests.test_each_reread_mutation_preserves_both_observations) ... FAIL
test_failed_watchdog_partial_and_failed_output_bytes_are_preserved (__main__.CollectorTests.test_failed_watchdog_partial_and_failed_output_bytes_are_preserved) ... FAIL
test_invalid_family_or_cli_arity_refuses_before_reads (__main__.CollectorTests.test_invalid_family_or_cli_arity_refuses_before_reads) ... FAIL
test_malformed_duplicate_and_recursive_operational_json_retained (__main__.CollectorTests.test_malformed_duplicate_and_recursive_operational_json_retained) ... FAIL
test_missing_binary_does_not_imply_success_or_not_run (__main__.CollectorTests.test_missing_binary_does_not_imply_success_or_not_run) ... FAIL
test_missing_states_do_not_read_live_logs_or_outputs (__main__.CollectorTests.test_missing_states_do_not_read_live_logs_or_outputs) ... FAIL
test_no_log_status_inconsistency_or_optimizer_mismatch (__main__.CollectorTests.test_no_log_status_inconsistency_or_optimizer_mismatch) ... FAIL
test_optional_terminal_summary_never_accepts_science (__main__.CollectorTests.test_optional_terminal_summary_never_accepts_science) ... FAIL
test_r52_success_build_and_both_fixed_outputs (__main__.CollectorTests.test_r52_success_build_and_both_fixed_outputs) ... FAIL
test_selected_sgd_cpu_path_only_and_optimizer_retained (__main__.CollectorTests.test_selected_sgd_cpu_path_only_and_optimizer_retained) ... FAIL
test_symlink_fifo_and_bounds_refuse_without_overread (__main__.CollectorTests.test_symlink_fifo_and_bounds_refuse_without_overread) ... FAIL
test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes (__main__.CollectorTests.test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes) ... FAIL

======================================================================
FAIL: test_all_r48_jobs_and_exact_ten_test_outputs (__main__.CollectorTests.test_all_r48_jobs_and_exact_ten_test_outputs)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader (__main__.CollectorTests.test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_bad_terminal_identity_argv_types_and_times_refuse_before_output (__main__.CollectorTests.test_bad_terminal_identity_argv_types_and_times_refuse_before_output)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_cmd_workdir_post_mismatch_retained_before_log_reads (__main__.CollectorTests.test_cmd_workdir_post_mismatch_retained_before_log_reads)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_each_reread_mutation_preserves_both_observations (__main__.CollectorTests.test_each_reread_mutation_preserves_both_observations)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_failed_watchdog_partial_and_failed_output_bytes_are_preserved (__main__.CollectorTests.test_failed_watchdog_partial_and_failed_output_bytes_are_preserved)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_invalid_family_or_cli_arity_refuses_before_reads (__main__.CollectorTests.test_invalid_family_or_cli_arity_refuses_before_reads)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_malformed_duplicate_and_recursive_operational_json_retained (__main__.CollectorTests.test_malformed_duplicate_and_recursive_operational_json_retained)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_missing_binary_does_not_imply_success_or_not_run (__main__.CollectorTests.test_missing_binary_does_not_imply_success_or_not_run)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_missing_states_do_not_read_live_logs_or_outputs (__main__.CollectorTests.test_missing_states_do_not_read_live_logs_or_outputs)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_no_log_status_inconsistency_or_optimizer_mismatch (__main__.CollectorTests.test_no_log_status_inconsistency_or_optimizer_mismatch)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_optional_terminal_summary_never_accepts_science (__main__.CollectorTests.test_optional_terminal_summary_never_accepts_science)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_r52_success_build_and_both_fixed_outputs (__main__.CollectorTests.test_r52_success_build_and_both_fixed_outputs)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_selected_sgd_cpu_path_only_and_optimizer_retained (__main__.CollectorTests.test_selected_sgd_cpu_path_only_and_optimizer_retained)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_symlink_fifo_and_bounds_refuse_without_overread (__main__.CollectorTests.test_symlink_fifo_and_bounds_refuse_without_overread)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

======================================================================
FAIL: test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes (__main__.CollectorTests.test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 33, in setUp
    self.assertIsNotNone(m, 'finite R48/R52 collector has not been implemented')
    ~~~~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: unexpectedly None : finite R48/R52 collector has not been implemented

----------------------------------------------------------------------
Ran 16 tests in 0.002s

FAILED (failures=16)
```

### task-48-52-terminal-collector-first-green.json

Command: `python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py -v`

Exit: 0

stdout:
```text
```

stderr:
```text
test_all_r48_jobs_and_exact_ten_test_outputs (__main__.CollectorTests.test_all_r48_jobs_and_exact_ten_test_outputs) ... ok
test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader (__main__.CollectorTests.test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader) ... ok
test_bad_terminal_identity_argv_types_and_times_refuse_before_output (__main__.CollectorTests.test_bad_terminal_identity_argv_types_and_times_refuse_before_output) ... ok
test_cmd_workdir_post_mismatch_retained_before_log_reads (__main__.CollectorTests.test_cmd_workdir_post_mismatch_retained_before_log_reads) ... ok
test_each_reread_mutation_preserves_both_observations (__main__.CollectorTests.test_each_reread_mutation_preserves_both_observations) ... ok
test_failed_watchdog_partial_and_failed_output_bytes_are_preserved (__main__.CollectorTests.test_failed_watchdog_partial_and_failed_output_bytes_are_preserved) ... ok
test_invalid_family_or_cli_arity_refuses_before_reads (__main__.CollectorTests.test_invalid_family_or_cli_arity_refuses_before_reads) ... ok
test_malformed_duplicate_and_recursive_operational_json_retained (__main__.CollectorTests.test_malformed_duplicate_and_recursive_operational_json_retained) ... ok
test_missing_binary_does_not_imply_success_or_not_run (__main__.CollectorTests.test_missing_binary_does_not_imply_success_or_not_run) ... ok
test_missing_states_do_not_read_live_logs_or_outputs (__main__.CollectorTests.test_missing_states_do_not_read_live_logs_or_outputs) ... ok
test_no_log_status_inconsistency_or_optimizer_mismatch (__main__.CollectorTests.test_no_log_status_inconsistency_or_optimizer_mismatch) ... ok
test_optional_terminal_summary_never_accepts_science (__main__.CollectorTests.test_optional_terminal_summary_never_accepts_science) ... ok
test_r52_success_build_and_both_fixed_outputs (__main__.CollectorTests.test_r52_success_build_and_both_fixed_outputs) ... ok
test_selected_sgd_cpu_path_only_and_optimizer_retained (__main__.CollectorTests.test_selected_sgd_cpu_path_only_and_optimizer_retained) ... ok
test_symlink_fifo_and_bounds_refuse_without_overread (__main__.CollectorTests.test_symlink_fifo_and_bounds_refuse_without_overread) ... ok
test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes (__main__.CollectorTests.test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes) ... ok

----------------------------------------------------------------------
Ran 16 tests in 0.375s

OK
```

### task-48-52-terminal-collector-type-red.json

Command: `python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_all_r48_jobs_and_exact_ten_test_outputs (__main__.CollectorTests.test_all_r48_jobs_and_exact_ten_test_outputs) ... ok
test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader (__main__.CollectorTests.test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader) ... ok
test_bad_terminal_identity_argv_types_and_times_refuse_before_output (__main__.CollectorTests.test_bad_terminal_identity_argv_types_and_times_refuse_before_output) ... ok
test_cmd_workdir_post_mismatch_retained_before_log_reads (__main__.CollectorTests.test_cmd_workdir_post_mismatch_retained_before_log_reads) ... ok
test_each_reread_mutation_preserves_both_observations (__main__.CollectorTests.test_each_reread_mutation_preserves_both_observations) ... ok
test_failed_watchdog_partial_and_failed_output_bytes_are_preserved (__main__.CollectorTests.test_failed_watchdog_partial_and_failed_output_bytes_are_preserved) ... ok
test_gate_config_integer_identity_cannot_be_float (__main__.CollectorTests.test_gate_config_integer_identity_cannot_be_float) ... FAIL
test_invalid_family_or_cli_arity_refuses_before_reads (__main__.CollectorTests.test_invalid_family_or_cli_arity_refuses_before_reads) ... ok
test_main_valid_family_serializes_raw_failure_evidence (__main__.CollectorTests.test_main_valid_family_serializes_raw_failure_evidence) ... ok
test_malformed_duplicate_and_recursive_operational_json_retained (__main__.CollectorTests.test_malformed_duplicate_and_recursive_operational_json_retained) ... ok
test_missing_binary_does_not_imply_success_or_not_run (__main__.CollectorTests.test_missing_binary_does_not_imply_success_or_not_run) ... ok
test_missing_required_runner_metadata_keeps_state_without_binary_reads (__main__.CollectorTests.test_missing_required_runner_metadata_keeps_state_without_binary_reads) ... ok
test_missing_states_do_not_read_live_logs_or_outputs (__main__.CollectorTests.test_missing_states_do_not_read_live_logs_or_outputs) ... ok
test_no_log_status_inconsistency_or_optimizer_mismatch (__main__.CollectorTests.test_no_log_status_inconsistency_or_optimizer_mismatch) ... ok
test_optional_terminal_summary_never_accepts_science (__main__.CollectorTests.test_optional_terminal_summary_never_accepts_science) ... ok
test_r52_success_build_and_both_fixed_outputs (__main__.CollectorTests.test_r52_success_build_and_both_fixed_outputs) ... ok
test_selected_sgd_cpu_path_only_and_optimizer_retained (__main__.CollectorTests.test_selected_sgd_cpu_path_only_and_optimizer_retained) ... ok
test_skip_oom_and_wrapper_status_are_operational_only (__main__.CollectorTests.test_skip_oom_and_wrapper_status_are_operational_only) ... ok
test_symlink_fifo_and_bounds_refuse_without_overread (__main__.CollectorTests.test_symlink_fifo_and_bounds_refuse_without_overread) ... ok
test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes (__main__.CollectorTests.test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes) ... ok

======================================================================
FAIL: test_gate_config_integer_identity_cannot_be_float (__main__.CollectorTests.test_gate_config_integer_identity_cannot_be_float)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py", line 328, in test_gate_config_integer_identity_cannot_be_float
    self.assertEqual(got['exit_code'],2)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2

----------------------------------------------------------------------
Ran 20 tests in 0.490s

FAILED (failures=1)
```

### task-48-52-terminal-collector-green.json

Command: `python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py -v`

Exit: 0

stdout:
```text
```

stderr:
```text
test_all_r48_jobs_and_exact_ten_test_outputs (__main__.CollectorTests.test_all_r48_jobs_and_exact_ten_test_outputs) ... ok
test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader (__main__.CollectorTests.test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader) ... ok
test_bad_terminal_identity_argv_types_and_times_refuse_before_output (__main__.CollectorTests.test_bad_terminal_identity_argv_types_and_times_refuse_before_output) ... ok
test_cmd_workdir_post_mismatch_retained_before_log_reads (__main__.CollectorTests.test_cmd_workdir_post_mismatch_retained_before_log_reads) ... ok
test_each_reread_mutation_preserves_both_observations (__main__.CollectorTests.test_each_reread_mutation_preserves_both_observations) ... ok
test_failed_watchdog_partial_and_failed_output_bytes_are_preserved (__main__.CollectorTests.test_failed_watchdog_partial_and_failed_output_bytes_are_preserved) ... ok
test_gate_config_integer_identity_cannot_be_float (__main__.CollectorTests.test_gate_config_integer_identity_cannot_be_float) ... ok
test_invalid_family_or_cli_arity_refuses_before_reads (__main__.CollectorTests.test_invalid_family_or_cli_arity_refuses_before_reads) ... ok
test_main_valid_family_serializes_raw_failure_evidence (__main__.CollectorTests.test_main_valid_family_serializes_raw_failure_evidence) ... ok
test_malformed_duplicate_and_recursive_operational_json_retained (__main__.CollectorTests.test_malformed_duplicate_and_recursive_operational_json_retained) ... ok
test_missing_binary_does_not_imply_success_or_not_run (__main__.CollectorTests.test_missing_binary_does_not_imply_success_or_not_run) ... ok
test_missing_required_runner_metadata_keeps_state_without_binary_reads (__main__.CollectorTests.test_missing_required_runner_metadata_keeps_state_without_binary_reads) ... ok
test_missing_states_do_not_read_live_logs_or_outputs (__main__.CollectorTests.test_missing_states_do_not_read_live_logs_or_outputs) ... ok
test_no_log_status_inconsistency_or_optimizer_mismatch (__main__.CollectorTests.test_no_log_status_inconsistency_or_optimizer_mismatch) ... ok
test_optional_terminal_summary_never_accepts_science (__main__.CollectorTests.test_optional_terminal_summary_never_accepts_science) ... ok
test_r52_success_build_and_both_fixed_outputs (__main__.CollectorTests.test_r52_success_build_and_both_fixed_outputs) ... ok
test_selected_sgd_cpu_path_only_and_optimizer_retained (__main__.CollectorTests.test_selected_sgd_cpu_path_only_and_optimizer_retained) ... ok
test_skip_oom_and_wrapper_status_are_operational_only (__main__.CollectorTests.test_skip_oom_and_wrapper_status_are_operational_only) ... ok
test_symlink_fifo_and_bounds_refuse_without_overread (__main__.CollectorTests.test_symlink_fifo_and_bounds_refuse_without_overread) ... ok
test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes (__main__.CollectorTests.test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes) ... ok

----------------------------------------------------------------------
Ran 20 tests in 0.503s

OK
```

## Limitations and required next action

Independent review of these exact sources must precede registration/controller release and any SSH invocation. No real R48/R52 terminal evidence was acquired; source preparation cannot establish that the queue reached these jobs. All job branches were exercised with synthetic fixtures, not production. Real Linux remote execution, transport/encoded stdout envelope, latency/timeouts, process signal races, disk ownership and files changing during kernel-level reads were not reproduced. The reader's ancestor/name race protections are inherited unchanged; the added mutation fixtures exercise changes between completed reads. Full 8 MiB / 32 MiB memory loads were not allocated; smaller temporary limit overrides exercise rejection/accounting branches. Optional metadata and failed scientific JSON are preserved, not scientifically validated. Downstream scientific review must separately verify original producer results, equality/tolerance/coverage and final model meaning.

The source reports original raw acquisition bytes only. A future controller must separately budget base64/JSON expansion, SSH transport and bounded execution, retain refusal stdout/stderr and protect a fresh local destination. This report releases none of that work, makes no measurement/performance claim, and does not complete Task48, Task52 or Task54.
