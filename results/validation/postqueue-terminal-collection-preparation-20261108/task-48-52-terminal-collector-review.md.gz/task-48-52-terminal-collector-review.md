# Independent R48/R52 terminal collector review

Date: 2026-11-08. Scope: local operational preparation only. SPEC: PASS. QUALITY: PASS. No actionable blocking findings were found in the reviewed fixed sources. This verdict does not release a controller or SSH request and does not establish research acceptance, deployment, collection, queue progress, or Task48/52/54 completion.

The engineering:code-review skill supplied the review dimensions. Review writes are restricted to this file. No source, test, queue, runner, Rust, research result, table, Git/index, or deployment was changed. No SSH, Cargo, HE/GPU/native workload or subagent was invoked. Read-only Git object inspection was used only to check the pinned R52 writer. Tests created automatically cleaned local temporary synthetic files; bytecode writing was disabled.

## Findings and verified contract

No required changes. Security, bounded acquisition, operational correctness and maintainability pass for the stated finite intake scope; the following evidence supports that conclusion.

- `task-48-52-terminal-collector.remote.py:13-21,107-136,332-340`: exactly one family selects compiled roots, full source pins, jobs, argv and binary outputs. There is no subprocess, dynamic command execution, caller path parameter, glob, directory walker, R47 recapture, profiler archive, or whole-queue-log read. Commands are compared as data. Queue commands/pins match `results/quadruped/scripts/post_full_queue.py:25-28,372-397,416`; shell quoting is decoded without execution.
- Collector `:24-88`: AST source-segment comparison independently confirms **byte-for-byte unchanged** `unique_object`, `stamp`, and `read_stable` against the requested R47 source. Own regular-file ownership, nofollow at every path edge, nonblocking final open, bounded read, descriptor/path-stamp checks and descriptor cleanup are retained. `parse_object` at `:90-104` is intentionally different: recursive nonfinite refusal, as correctly disclosed in preparation. No blanket unchanged-parser claim is made.
- Collector `:215-237,241-265`: originals are inserted before semantic parsing; 8 MiB per-file and 32 MiB total raw-byte limits include retained final observations. Family refusal and acquisition refusal retain the operational-only kind and `scientific_acceptance=false`. Owner and gate/config identities, primitive types and aware timestamps are checked. Queue terminal summary is optional, raw-preserved and never accepted science.
- Collector `:274-302`: missing exact job state produces `no_terminal_record_observed` and skips its potentially growing log/output. Present state must identify coherent original meta/cmd/workdir/post before log/binary intake. Validation agrees with runner `run_job.sh:31-39,59-96` for command, workdir, source marker, GPU, nice/thread fields, child exit, timestamps and final `JOB_DONE`. Whole-second start rounding is compatible with the retained R47 fix. Wrapper status remains separate from child status.
- Collector `:186-208,303-316`: coherent failed, watchdog, OOM, SKIP and R52 partial states are retained. Binary bytes are never parsed or rebuilt; failed-check/malformed binary JSON can therefore survive intact. Output-validation failures may have missing output and are not converted to an accepted row. Optional partial/projection/identity records are preserved as original bytes. Partial status remains an operational queue claim; the collector is not a scientific or termination-proof validator.
- Collector `:110-127,266-273,286-287,308-311`: all ten possible R48 test names match `docs/post-full-queue.md:147`; only exact compiled NAG/SGD ablation outputs are read. The optional GPU SGD job is captured only when its own terminal state exists; its absence is not called attempted, skipped, or not-run. R48 CPU command selection must match a present original optimizer record. This is finite capture, not reconstruction of causal queue ordering from possibly missing records; downstream acceptance must retain that distinction.
- Collector `:233-237,312-323`: state/meta and observed owner/gate/optimizer/queue-terminal identities are reread. Changed observations and earlier originals survive the refusal. Raw missing-file records never fabricate values or execution history. A snapshot is not an assertion that all jobs or files existed throughout the observation interval.
- `docs/post-full-queue.md:145` correctly defines future R48/R52 local archive destinations with exact job names, unchanged five core files, source mappings, optimizer and partial records. It does not claim that those destinations have been populated. Its failed R52-output warning is independently supported by read-only inspection of commit `9305d2e1f4f9999296cd4b4aaf55ea631fbca78e`, `crates/hekit-bench/src/bin/mnist/blocks.rs:1075-1077,1209-1219` (writes before failed-check Err), and `mnist.rs:922-936` (block dispatch and child exit 1). No Rust code was run.

## Test/evidence quality

The suite uses resolved temporary roots and independent literal command/output fixtures, not actual remote/mounted paths. The independent run passed 20 tests. It exercises family restrictions, every finite job, ten test outputs, selected SGD output only, failed/partial/watchdog/skip/OOM states, failed binary bytes, missing states/required metadata/outputs, primitive and identity errors, malformed/duplicate/nonfinite/deep JSON, metadata mutations, FIFO/symlink/ownership and reduced byte-limit refusal.

All four retained raw JSON transcripts were read and compared against their embedded preparation sections: stdout and stderr match exactly, with exit values 1/0/1/0. All preparation identity-table entries match current bytes/hashes. The first RED is explicitly setup/source-absence failure for 16 tests and must not be described as 16 independent behavioral regressions. The additional type-RED reproduces the concrete chain_pid float/int equality bug; current source fixes it. Those boundaries are accurately disclosed by the author.

Independent command (60-second subprocess timeout; cwd `/Users/marconi/Documents/research/hekit`; environment `PYTHONDONTWRITEBYTECODE=1`):

```text
python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py -v
```

Exit: 0. stdout: empty. Actual stderr:

```text
test_all_r48_jobs_and_exact_ten_test_outputs (__main__.CollectorTests.test_all_r48_jobs_and_exact_ten_test_outputs) ... ok
test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader (__main__.CollectorTests.test_ancestor_symlink_and_wrong_owner_rejected_by_shared_reader) ... ok
test_bad_terminal_identity_argv_types_and_times_refuse_before_output (__main__.CollectorTests.test_bad_terminal_identity_argv_types_and_times_refuse_before_output) ... ok
test_cmd_workdir_post_mismatch_retained_before_log_reads (__main__.CollectorTests.test_cmd_workdir_post_mismatch_retained_before_log_reads) ... ok
test_each_reread_mutation_preserves_both_observations (__main__.CollectorTests.test_each_reread_mutation_preserves_both_observations) ... ok
test_failed_watchdog_partial_and_failed_output_bytes_are_preserved (__main__.CollectorTests.test_failed_watchdog_partial_and_failed_output_bytes_are_preserved) ... ok
test_gate_config_integer_identity_cannot_be_float (__main__.CollectorTests.test_gate_config_integer_identity_cannot_be_float) ... ok
test_invalid_family_or_cli_arity_refuses_before_reads (__main__.CollectorTests.test_invalid_family_or_cli_arity_refuses_before_reads) ... ok
test_main_valid_family_serializes_raw_failure_evidence (__main__.CollectorTests.test_main_valid_family_serializes_raw_failure_evidence) ... ok
test_malformed_duplicate_and_recursive_operational_json_retained (__main__.CollectorTests.test_malformed_duplicate_and_recursive_operational_json_retained) ... ok
test_missing_binary_does_not_imply_success_or_not_run (__main__.CollectorTests.test_missing_binary_does_not_imply_success_or_not_run) ... ok
test_missing_required_runner_metadata_keeps_state_without_binary_reads (__main__.CollectorTests.test_missing_required_runner_metadata_keeps_state_without_binary_reads) ... ok
test_missing_states_do_not_read_live_logs_or_outputs (__main__.CollectorTests.test_missing_states_do_not_read_live_logs_or_outputs) ... ok
test_no_log_status_inconsistency_or_optimizer_mismatch (__main__.CollectorTests.test_no_log_status_inconsistency_or_optimizer_mismatch) ... ok
test_optional_terminal_summary_never_accepts_science (__main__.CollectorTests.test_optional_terminal_summary_never_accepts_science) ... ok
test_r52_success_build_and_both_fixed_outputs (__main__.CollectorTests.test_r52_success_build_and_both_fixed_outputs) ... ok
test_selected_sgd_cpu_path_only_and_optimizer_retained (__main__.CollectorTests.test_selected_sgd_cpu_path_only_and_optimizer_retained) ... ok
test_skip_oom_and_wrapper_status_are_operational_only (__main__.CollectorTests.test_skip_oom_and_wrapper_status_are_operational_only) ... ok
test_symlink_fifo_and_bounds_refuse_without_overread (__main__.CollectorTests.test_symlink_fifo_and_bounds_refuse_without_overread) ... ok
test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes (__main__.CollectorTests.test_wrong_owner_gate_and_primitive_types_preserve_refusal_bytes) ... ok

----------------------------------------------------------------------
Ran 20 tests in 0.525s

OK
```

## Source identities observed during review

| Source | Bytes | SHA256 |
|---|---:|---|
| `.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector.remote.py` | 19552 | `354b7787086d4a708579b90b115d598ef6217668f173a73cf4f0c79f2e42d2ea` |
| `.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/test_task_48_52_terminal_collector.py` | 23174 | `d76b90d0ae1c75b70e72e4b5f522f4ed82e718b9f5147f3f5eaa9b90e6118ef8` |
| `.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-47-terminal-collector.remote.py` | 11201 | `8e40fb7efa1cfdb90f826fe4b8b8c6046a876616f695790d5e5c27975c2a0d5a` |
| `results/quadruped/scripts/post_full_queue.py` | 23840 | `1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9` |
| `results/quadruped/scripts/run_job.sh` | 4998 | `46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736` |
| `docs/post-full-queue.md` | 24704 | `09bdab1997d0a1ee0352d159ee2c2d634c34f5c739313c5c5515ba3f7a0d06dc` |
| `.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-brief.md` | 4647 | `1d970e8412c3d4ef0531fb40464fb8ae22b0c4e9dd2a6dd339897965d8275701` |
| `.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-collector-preparation.md` | 37205 | `1d5bd2a609d041299f278d4c7c382c940b60c232b1e800e41cb9f73441124dc2` |

## Limits and release boundary

This checks finite local capture behavior only. No actual terminal artifacts were acquired, no controller was reviewed or released, and no scientific comparison or acceptance was performed. Linux remote execution, SSH/transport limits, scheduler/nice invocation, live kernel races, production ownership and full-size memory allocation were not tested. Raw-byte caps do not bound all parser/base64/JSON process memory; the future controller still needs explicit timeout, encoded-transport budget, fresh local destination, exact source registration, and refusal-output retention, as preparation already states.

Tests exercise metadata changes between reads and reduced-limit branches; they do not establish an atomic multi-file historical snapshot or process termination beyond the producer's recorded contract. Optional metadata and binary semantics remain downstream validation. The reviewed R47 helper source was compared exactly, not rerun as the historical full suite. Approval here applies to the listed source hashes and does not authorize reruns, repairs, synthesis of missing measurements, or altered result values.
