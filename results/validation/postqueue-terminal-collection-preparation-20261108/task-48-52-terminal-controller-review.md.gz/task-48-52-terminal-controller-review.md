# Independent R48/R52 one-shot controller review

Date: 2026-11-08. SPEC: PASS. QUALITY: PASS for both fixed-family local operations-source drafts. No actionable blocking findings. This verdict does not register or release any SSH request, invoke a collector, or establish measurement acceptance. The separately reviewed shared collector is SPEC/QUALITY PASS at the pinned 19552-byte SHA256 below.

Review used the engineering:code-review dimensions and is confined to the finite changes relative to the reviewed R47 transport/custody implementation. The initial R47 review and its superseding clarification were both read; the withdrawn failed-build finding is not repeated. Only this report was written for this added scope. No source/controller changes, SSH, GPU/HE/native/Cargo workload, actual result/table writes, Git mutations, or subagents.

## Findings and contract verification

No changes required for the stated preparation scope.

- Both controller files at lines 12-23 and 72-74 pin the exact reviewed shared collector length/SHA256 and pass one literal family argument, r48 or r52. Source bytes are read once, checked and later supplied unchanged to stdin. The sources differ from each other only in fixed prefix, literal family command and last-job name/error label. No arbitrary command/path capability was added to the remote collector.
- Controller lines 30-59 preserve the R47 observer transport/source/output hash/size, exact FULL2 final path and presence, and registered old-chain identity checks. Gone, same-identity Z/X, or a numerically different start identity establish that the original chain is not live; an unknown/live original chain refuses. These checks concern local archived observations reviewed by root. Hash consistency is not independent historical attestation or cryptographic authentication of arbitrary user-authored JSON.
- Controller lines 60-63 implement the planned fixed-family condition: gate-released.json plus either R-48-4.json / R-52-2.json respectively, or terminal.json. A family build record is intentionally not required. Source tracing confirms that a released queue can fail before reaching this family: post_full_queue.py:441-442 wraps all execute work in queue_lock, whose except BaseException at :111-113 writes failed terminal.json. Requiring this family's build would wrongly exclude that stated capture case. Conversely pending, wrong-family-only, or no-gate observations refuse. There is no weaker process-inactivity substitute for absent queue terminal evidence.
- Queue directory entry names are eligibility observations, not claims that files are scientifically valid or that all jobs ran. The shared collector independently checks current raw owner/gate/job data, reads only terminal-job artifacts, preserves failures/missing records and always marks scientific_acceptance=false. A gate-released terminal before family creation can therefore legitimately return missing family records, without inventing not-run or success.
- Controller lines 67-102 validate source and observation before any output reservation. --check-only returns before reservation and Popen. Six exact output names are reserved with xb before launch; a partial reservation remains unusable, and an existing prefix refuses. The two families have distinct task-48-terminal-fetch-v1 / task-52-terminal-fetch-v1 prefixes. Original observation stdout and metadata are copied unmodified and hashed in controller metadata.
- Lines 16-22 and 103-138 retain fixed key-only SSH flags, one connection, nice 10, the 110-second communicate timeout, termination only of the newly spawned local SSH child, no automatic retry, preserved raw stdout/stderr, child return/timeout status and stream hashes. The transport/custody body is unchanged from R47 except for the source-length pin in main. It does not execute captured commands or signal research processes.
- Lines 90-91 and 122-136 correctly label 64 MiB as a post-capture encoded stdout check, not a streaming cap or stderr hard limit. Hashing uses 65536-byte chunks. Excess changes controller status to refusal while retaining bytes. Remote original-byte limits remain the collector's separate 8 MiB/file and 32 MiB total bounds.

## Independent validation

Cwd: /Users/marconi/Documents/research/hekit. Commands below ran with PYTHONDONTWRITEBYTECODE=1 and a 60-second local subprocess timeout. The synthetic fixture patches Popen to reject any launch. The other two commands use --check-only, which cannot reach SSH or output reservation on either success or refusal.

Command:
```text
python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-52-terminal-controller-tests.py -v
```
Exit: 0. stdout: empty. stderr:
```text
test_fixed_family_preconditions (__main__.Precondition.test_fixed_family_preconditions) ... ok

----------------------------------------------------------------------
Ran 1 test in 0.054s

OK
```

Command:
```text
python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-48-terminal-controller.py --check-only .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/post-full-observation-20261108-1523
```
Exit: 2. stdout: empty. stderr:
```text
Controller refused before/around launch: FULL-2 result has not been observed
```

Command:
```text
python3 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-52-terminal-controller.py --check-only .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/post-full-observation-20261108-1523
```
Exit: 2. stdout: empty. stderr:
```text
Controller refused before/around launch: FULL-2 result has not been observed
```

The suite is one unittest with 20 pure synthetic subcases (two families times ten cases), not 20 independent test methods. Its case set checks the family last-job branch, released queue terminal before a family build, pending, wrong family, no gate, absent FULL2 result, live/unknown original chain, altered observer stdout hash and nonzero observer transport status. It also checks literal remote family commands, distinct prefixes and no additional fixture output creation.

The actual archived 15:23 observation's stdout SHA256 is bb348126615faa903067a89cc2447c610f6fae879303fbb44b833f5774a2c46e (2417 bytes), matching its transport record. It records full2_result_exists=false, the original live chain, and queue entries containing only owner.json. This is a stored observation, not a fresh server query. Both actual negative check-only invocations independently refused with exit 2; ledger inspection afterwards found no task-48-terminal-fetch-v1.* or task-52-terminal-fetch-v1.* outputs.

The retained RED/GREEN JSON was read. RED is source-absence failure in all 20 subcases (one test method); GREEN records the same 20-case fixture passing plus both actual negative check-only refusals. It does not demonstrate behavioral RED coverage of all branches. No positive remote transport, timeout, launch-error, excess-envelope or exclusive-reservation race execution is claimed.

## Reviewed identities

| File under ledger | Bytes | SHA256 |
|---|---:|---|
| `task-48-terminal-controller.py` | 7611 | `a2ada1a88e64d77372e728e30700e5798c7b02038fe79d81b459ca10efbbd01e` |
| `task-52-terminal-controller.py` | 7611 | `24b142678ad57812625093994bfa5159ef57214d0d3b9846d2631104798388f1` |
| `task-47-terminal-controller.py` | 7653 | `4de62d14af065aee39ae9c74e9e82b6bd71e39f921a0936901961beb7cc8a6d6` |
| `task-48-52-terminal-controller-tests.py` | 3469 | `cb5dfcd7bc185c526fc531786ded5348629cd26723cd0fa191925a0f2d6f2124` |
| `task-48-52-terminal-controller-plan.md` | 1598 | `be23308fbdc1a1fa7f5b093c8fd9d9b7f2250a9c070ee1fe9fec51d0f57629d0` |
| `task-48-52-terminal-controller-preparation.md` | 3285 | `057e0b643446f12f645f1e612183062c1934f8e24458d80d8cb6ed414e17916e` |
| `task-48-52-terminal-collector.remote.py` | 19552 | `354b7787086d4a708579b90b115d598ef6217668f173a73cf4f0c79f2e42d2ea` |

The R47 source identity matches the superseding R47 clarification's approved source. Diff inspection confirms no extra transport implementation changes. The original observer source hash remains 17550e5d285a03329782d8ca9f3af7ad5b4e39468596d41781607a942572c243.

## Limits and remaining authority

This review approves the specified local source candidates only. Exact request registration, root inspection of an actual qualifying observation, a fresh unused destination, and deliberate root invocation remain separate; none were performed here. Preparation language saying the collector review was pending is historical report-time state, superseded by the separate collector review, not a release.

The inherited transport is not reopened as a general security audit. Positive SSH/timeout/transport behavior is source-reviewed and remains unexecuted. --check-only validates source/observation eligibility, not live SSH reachability or fresh destination availability at a later invocation. Output hashes attest held/read bytes, not past execution or science. No new thresholds, experiment gates, fallback process controls, automatic retries, repairs or scientific acceptance were introduced.

