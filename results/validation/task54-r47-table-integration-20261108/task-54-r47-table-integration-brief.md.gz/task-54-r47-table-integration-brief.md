# Task54 bounded R47 table integration

Read this first; it is the exact requirements for this independent Python task.
BASE: 1a59ecea3abef192088c765520496b02355f6aaf
Original plan ../plans/2026-11-04-he-training-implementation-plan-m3-m5.md Task54 requires tools/tables.py to regenerate paper tables from actual results (LaTeX/Markdown), retaining sample/seed interpretation. Existing authority is tools/paper_tables.py; tools/tables.py is its compatibility entrypoint. Current table_gpu always emits a pending R-47-3 row, even if the future result is collected. Fix that concrete gap without changing other research paths.

## Ownership / process

Only edit tools/paper_tables.py and tools/test_paper_tables.py. A separate sole Rust writer is actively editing crates/; never touch its files, run Cargo/rustfmt/HE/native/SSH/GPU, alter Git/index/branches, stage/commit/push, change actual results/paper tables, or spawn subagents. Root owns integration/review/commit. Use tiny synthetic fixtures in temporary directories only, label them synthetic. Python tests/temporary-output generation are permitted; no heavy experiment. Independently read actual pinned project sources via git show (no checkout). No baseline/ReBoot/OpenFHE code or snippets may be introduced. Stdlib only, no new dependencies.

The parallel scope is explicitly limited to these two Python files; no shared Rust/source/generated-artifact ownership. Root recorded the workflow ruling before dispatch. Preserve original full Task54 scope; this closes only the R47 table slice and does not complete Step3/4 or the whole matrix.

## Producer and canonical inputs

Source: bd5cc493db166a282d26b05b1e069f2a0ee629ef:crates/hekit-cuda/examples/batch_streams.rs (project code). Queue commands and runner fields: results/quadruped/scripts/post_full_queue.py and run_job.sh, unchanged deployment. docs/post-full-queue.md intake map and docs/m4-report.md gate/interpretation remain governing.

Use future canonical original files under results/quadruped/raw/R-47-3/R-47-3-example/: program.log, meta.json, post.txt, cmd.txt, state.json. This maps directly to approved collector keys; root will copy original bytes there after actual collection and acceptance. No real files exist there now; do not create any in the real repository. No assembled replacement scientific JSON. Shorter results/quadruped/batch_streams_r47_3.log may be an archival alias later but must not be accepted as a stand-alone source without the canonical terminal provenance.

The producer has TWO pool thresholds (default256MiB / maxu64), each with THREE timing rows: one-stream sequential x4, two-stream batch x4, four-stream batch x4. Six rows total. Header n16_train,d64,level5,fourproducts,30repetitions; verify exact constants against source before implementing. It prints median/min/SD in milliseconds (sequential also per-product). Device synchronization is inside timing; CPU setup seconds are not CPU matvec latency. A five-repetition nsys log is a different job and must not substitute. Assertions check batch vs sequential residue equality; a successful process is needed, do not infer equality just from an earlier timing line in a subsequently failed log.

## Required behavior

- All canonical inputs absent: generated existing tables are byte-identical to current behavior (including pending row). Partial/malformed success input must fail with TableError, never silently render plausible metrics or select another historical run. Fixture overlays must exclude R-47-3 so later actual archives cannot be modified through symlinks.
- Establish expected original job R-47-3-example, exact full source pin, clean marker, workdir /home/kmihara/hekit-post-full-clones/hekit-post-full-r47, argv target/release/examples/batch_streams, nice10, threads12, GPUtrue, coherent timezone-qualified start/end and matching state/meta/post child exit. Use original queue/runner formats, not new invented provenance fields. Read raw bytes without mutation; distinguish capture-time/source hashes from historical proof. Root scientific review remains a separate acceptance step.
- Terminal success (child0/watchdogfalse) requires one exact header for the principal30-repetition job and six unique complete threshold/variant timing rows with finite sensible values and no duplicate/contradictory rows. Retain actual source-line attribution using Cell/Store conventions. No fake zeros/NaN, no data from old R47-2 substituted.
- A coherent nonzero child exit or watchdog is displayed as failed/unmeasured with original provenance attribution and NO extracted success timings. A malformed/inconsistent terminal record is an error, not a known failed measurement. Memory SKIP must not be invented because this example does not implement a successful capacity skip branch.
- Replace the unconditional pending placeholder with explicit R47-3 rows only when valid new success input exists. Preserve old R47-2 rows as historical. Show each threshold and variant with actual median; preserve min/SD/repetition count in table notes or an equally clear existing-format representation. Do not compute CPU speedups or HEonGPU ratios using unlike/historical denominators. If reporting stream speedup, denominator must be same-threshold same-run R47-3 sequential x4. Reporting no new ratio is acceptable.
- Make caption/notes distinguish old Criterion medians from new example medians when present. Thirty within-run repetitions are not30independent seeds; no end-to-end training or GPU peak claim. Do not convert source compilation or synthetic tests into measured data.
- Keep existing run_all/quick behavior compatible. No broader refactor or stricter unrelated archived schemas. Implement only what is needed for the finite registered producer and above success/failure/missing cases.

## Tests / evidence / review

Test first. Cover absent inputs (existing generated bytes unchanged), complete six-row success, failure after partial timing lines, malformed/duplicate/incomplete/nonfinite/negative timing rows, wrong pin/command/exit/post/provenance, five-repetition profile input, source attribution, and overlay write isolation. Use only tiny synthetic fixtures, never measured-result paths. Read actual existing Store/Input/output code before choosing smallest implementation.

Run focused tools/test_paper_tables.py and appropriate directly crossing table compatibility checks. Do not run unrelated HE or whole Rust suites. For actual repository regeneration verification use a temporary output/root as existing tests do, or --check (no source-result mutation). Preserve exact command stdout/stderr/exit and source hashes in this ledger. No additional independent reviewer from worker; root will review exact two-file diff.

Write full report L/task-54-r47-table-integration-report.md (L is this file's parent), with test-first RED/GREEN evidence, exact owned-file hashes/diff against BASE, behavior/limits and any concerns. Return only completion status, paths, concise tests and concerns. Do not mark wholeTask54 complete.
