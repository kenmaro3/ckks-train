# Task54 bounded R47 table integration report

This report covers only the two-file R47 table slice; the full Task54 and scientific acceptance remain incomplete.

## Test-first RED transcript

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... FAIL
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... 
  test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=101, watchdog=False) ... FAIL
  test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=143, watchdog=True) ... FAIL
  test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=0, watchdog=True) ... FAIL
  test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=3, watchdog=False) ... FAIL
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... FAIL
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... 
  test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='program.log') ... FAIL
  test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='meta.json') ... FAIL
  test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='post.txt') ... FAIL
  test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='cmd.txt') ... FAIL
  test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='state.json') ... FAIL
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... 
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='job', value='R-47-3-nsys') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='hekit_synced_commit', value=['commit bd5cc49', 'full aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'dirty_files 0']) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='hekit_synced_commit', value=['commit bd5cc49', 'full bd5cc493db166a282d26b05b1e069f2a0ee629ef', 'dirty_files 1']) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='hekit_synced_commit', value=['commit bd5cc49', 'full bd5cc493db166a282d26b05b1e069f2a0ee629ef', 'dirty_files 0', 'dirty_files 1']) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='workdir', value='/tmp/other') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='command', value='nsys target/release/examples/batch_streams') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='threads_cap', value=1) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='nice', value=0) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='gpu_job', value=False) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='env_thread_caps', value={}) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='start', value='2026-11-08T10:00:00') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='end', value='2026-11-08T09:59:00+09:00') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='wall_s_runner', value=1000) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='watchdog_killed', value='false') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='exit_status', value=1) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='rc', value=1) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='status', value='failed') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='command', value=['other']) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='workdir', value='/tmp/other') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='job', value='R-47-3-nsys') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='wrapper_rc', value='0') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='skip', value=True) ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='cmd.txt', text='nsys target/release/examples/batch_streams') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='post.txt', text='JOB_DONE rc=1\n') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='post.txt', text='JOB_DONE rc=0\nJOB_DONE rc=0\n') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', text='{') ... FAIL
  test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', text='{}') ... FAIL
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... 
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=0) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=1) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=2) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=3) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=4) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=5) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=6) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=7) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=8) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=9) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=10) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=11) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=12) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=13) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=14) ... FAIL
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=15) ... FAIL
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... FAIL
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
FAIL: test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 418, in test_r47_compatibility_entrypoint_renders_same_success_table
    self.assertIn(R47_DIR + '/program.log\tline 9', p.stdout)
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'results/quadruped/raw/R-47-3/R-47-3-example/program.log\tline 9' not found in 'table\trow\tcolumn\tvalue\tfile\tfield\tformula\ngpu_vs_cpu_ops\tadd\thekit GPU\t0.111\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_add/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tadd\tCPU 1 thr\t15.674\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_add/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tadd\tCPU 12 thr\t14.611\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_add/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tadd\tGPU speed-up (1 / 12 thr)\t141x / 132x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_add/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tadd\tGPU speed-up (1 / 12 thr)\t141x / 132x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_add/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tadd\tGPU speed-up (1 / 12 thr)\t141x / 132x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_add/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\thekit GPU\t4.671\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_relinearize/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\tCPU 1 thr\t639.639\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_relinearize/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\tCPU 12 thr\t240.070\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_relinearize/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\tGPU speed-up (1 / 12 thr)\t137x / 51x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_relinearize/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\tGPU speed-up (1 / 12 thr)\t137x / 51x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_relinearize/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\tGPU speed-up (1 / 12 thr)\t137x / 51x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_relinearize/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\tHEonGPU (RTX 4090)\t2.582 (l = 36, I = 4 primes per digit)\tresults/reference/literature.json\theongpu_rtx4090[0].value_us\t\ngpu_vs_cpu_ops\trelinearize\tHEonGPU (RTX 4090)\t2.582 (l = 36, I = 4 primes per digit)\tresults/reference/literature.json\theongpu_rtx4090[0].parameters\t\ngpu_vs_cpu_ops\trelinearize\tGPU / HEonGPU\t1.81x (nominal)\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_relinearize/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trelinearize\tGPU / HEonGPU\t1.81x (nominal)\tresults/reference/literature.json\theongpu_rtx4090[0].value_us\t\ngpu_vs_cpu_ops\tmul + relin + rescale\thekit GPU\t5.823\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_mul_relin_rescale/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmul + relin + rescale\tCPU 1 thr\t725.209\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_mul_relin_rescale/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmul + relin + rescale\tCPU 12 thr\t337.731\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_mul_relin_rescale/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmul + relin + rescale\tGPU speed-up (1 / 12 thr)\t125x / 58x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_mul_relin_rescale/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmul + relin + rescale\tGPU speed-up (1 / 12 thr)\t125x / 58x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_mul_relin_rescale/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmul + relin + rescale\tGPU speed-up (1 / 12 thr)\t125x / 58x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_mul_relin_rescale/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trotate(1)\thekit GPU\t3.990\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_rotate1/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trotate(1)\tCPU 1 thr\t622.046\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_rotate1/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trotate(1)\tCPU 12 thr\t223.880\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_rotate1/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trotate(1)\tGPU speed-up (1 / 12 thr)\t156x / 56x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_rotate1/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trotate(1)\tGPU speed-up (1 / 12 thr)\t156x / 56x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_rotate1/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\trotate(1)\tGPU speed-up (1 / 12 thr)\t156x / 56x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_rotate1/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16\thekit GPU\tskipped: needs 5580 MiB (2377 MiB free)\tresults/quadruped/cuda_ops_r47.log\tline 34\t\ngpu_vs_cpu_ops\thoisted rotate x16\tCPU 1 thr\t3765.068\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_hoisted_rotate_16/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16\tCPU 12 thr\t689.471\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_hoisted_rotate_16/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16 (capped keys)\thekit GPU\t4.984\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_hoisted_rotate_16_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16 (capped keys)\tCPU 1 thr\t1005.331\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_hoisted_rotate_16_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16 (capped keys)\tCPU 12 thr\t172.870\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_hoisted_rotate_16_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16 (capped keys)\tGPU speed-up (1 / 12 thr)\t202x / 35x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_hoisted_rotate_16_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16 (capped keys)\tGPU speed-up (1 / 12 thr)\t202x / 35x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_hoisted_rotate_16_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\thoisted rotate x16 (capped keys)\tGPU speed-up (1 / 12 thr)\t202x / 35x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_hoisted_rotate_16_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64\thekit GPU\tskipped: needs 7276 MiB (1929 MiB free)\tresults/quadruped/cuda_ops_r47.log\tline 42\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64\tCPU 1 thr\t12938.440\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_matvec_enc_d64/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64\tCPU 12 thr\t2325.173\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_matvec_enc_d64/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\thekit GPU\t16.120\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_matvec_enc_d64_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tCPU 1 thr\t2523.223\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_matvec_enc_d64_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tCPU 12 thr\t547.762\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_matvec_enc_d64_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tGPU speed-up (1 / 12 thr)\t157x / 34x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_matvec_enc_d64_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tGPU speed-up (1 / 12 thr)\t157x / 34x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_matvec_enc_d64_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tGPU speed-up (1 / 12 thr)\t157x / 34x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_matvec_enc_d64_L9/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\thekit GPU\t9.509\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_matvec_enc_d64_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tCPU 1 thr\t1391.064\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_matvec_enc_d64_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tCPU 12 thr\t314.649\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_matvec_enc_d64_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tGPU speed-up (1 / 12 thr)\t146x / 33x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_matvec_enc_d64_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tGPU speed-up (1 / 12 thr)\t146x / 33x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_1t_matvec_enc_d64_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc d = 64 (capped keys)\tGPU speed-up (1 / 12 thr)\t146x / 33x\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/cpu_12t_matvec_enc_d64_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc x4, 1 stream (sequential)\thekit GPU\t34.994\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_matvec_enc_x4_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tmatvec_enc x4, 4 streams (untuned R-47-2)\thekit GPU\t41.673\tresults/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/gpu_matvec_enc_batch4_L5/new/estimates.json\tmedian.point_estimate\t\ngpu_vs_cpu_ops\tnote 1\t\t\tresults/reference/literature.json\theongpu_rtx4090[0].source\t\ngpu_vs_cpu_ops\tnote 1\t\t\tresults/reference/literature.json\theongpu_rtx4090[0].caveat\t\n'

======================================================================
FAIL: test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=101, watchdog=False)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 320, in test_r47_failure_discards_partial_success_timings
    self.assertEqual(len(new), 1)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
AssertionError: 0 != 1

======================================================================
FAIL: test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=143, watchdog=True)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 320, in test_r47_failure_discards_partial_success_timings
    self.assertEqual(len(new), 1)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
AssertionError: 0 != 1

======================================================================
FAIL: test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=0, watchdog=True)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 320, in test_r47_failure_discards_partial_success_timings
    self.assertEqual(len(new), 1)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
AssertionError: 0 != 1

======================================================================
FAIL: test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) (rc=3, watchdog=False)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 320, in test_r47_failure_discards_partial_success_timings
    self.assertEqual(len(new), 1)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
AssertionError: 0 != 1

======================================================================
FAIL: test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 406, in test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it
    self.assertEqual(tables.main(['--root', str(self.root)]), 2)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2

======================================================================
FAIL: test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='program.log')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 339, in test_r47_rejects_partial_originals_and_alias_only_is_pending
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='meta.json')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 339, in test_r47_rejects_partial_originals_and_alias_only_is_pending
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='post.txt')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 339, in test_r47_rejects_partial_originals_and_alias_only_is_pending
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='cmd.txt')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 339, in test_r47_rejects_partial_originals_and_alias_only_is_pending
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) (name='state.json')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 339, in test_r47_rejects_partial_originals_and_alias_only_is_pending
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='job', value='R-47-3-nsys')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='hekit_synced_commit', value=['commit bd5cc49', 'full aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', 'dirty_files 0'])
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='hekit_synced_commit', value=['commit bd5cc49', 'full bd5cc493db166a282d26b05b1e069f2a0ee629ef', 'dirty_files 1'])
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='hekit_synced_commit', value=['commit bd5cc49', 'full bd5cc493db166a282d26b05b1e069f2a0ee629ef', 'dirty_files 0', 'dirty_files 1'])
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='workdir', value='/tmp/other')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='command', value='nsys target/release/examples/batch_streams')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='threads_cap', value=1)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='nice', value=0)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='gpu_job', value=False)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='env_thread_caps', value={})
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='start', value='2026-11-08T10:00:00')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='end', value='2026-11-08T09:59:00+09:00')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='wall_s_runner', value=1000)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='watchdog_killed', value='false')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', key='exit_status', value=1)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='rc', value=1)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='status', value='failed')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='command', value=['other'])
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='workdir', value='/tmp/other')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='job', value='R-47-3-nsys')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='wrapper_rc', value='0')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', key='skip', value=True)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 366, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='cmd.txt', text='nsys target/release/examples/batch_streams')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 374, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='post.txt', text='JOB_DONE rc=1\n')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 374, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='post.txt', text='JOB_DONE rc=0\nJOB_DONE rc=0\n')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 374, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='meta.json', text='{')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 374, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) (name='state.json', text='{}')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 374, in test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=0)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=1)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=2)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=3)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=4)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=5)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=6)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=7)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=8)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=9)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=10)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=11)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=12)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=13)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=14)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=15)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 399, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 291, in test_r47_success_six_rows_keep_statistics_and_actual_line_sources
    self.assertEqual(len(r47), 6)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^
AssertionError: 0 != 6

----------------------------------------------------------------------
Ran 23 tests in 1.659s

FAILED (failures=55)
```

## Additional edge-case RED transcript

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... 
  test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=16) ... FAIL
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... FAIL
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
FAIL: test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) (case=16)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 405, in test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 315, in test_r47_success_six_rows_keep_statistics_and_actual_line_sources
    self.assertIn((R47_DIR + '/program.log', 'line 1'), new_rows[0][1].sources)
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: ('results/quadruped/raw/R-47-3/R-47-3-example/program.log', 'line 1') not found in []

----------------------------------------------------------------------
Ran 23 tests in 1.525s

FAILED (failures=2)
```

## Implemented behavior and limits

- Owned implementation: `tools/paper_tables.py`; owned tests: `tools/test_paper_tables.py`. This required report is the only additional write outside those two files. No Rust/Cargo/Git-index/SSH/GPU work, actual result files, or real generated tables were written.
- The raw canonical five-file set is read once per generation and SHA256 is computed over those consumed original bytes. Partial canonical input raises TableError; an absent set retains the pending row. A shorter alias never supplies measurements.
- Validate the exact R-47-3-example job, full pinned source/clean marker, registered clone workdir, argv, nice 10, 12-thread runner caps, GPU flag, timezone-qualified monotonic times consistent with fractional wall time, terminal post child status and matching queue rc/status. Wrapper rc remains a separate field rather than a child status substitute.
- Success needs one n16_train/d64/L5/four-product/30-repetition header, both exact threshold declarations, and six unique complete finite rows. Values retain actual program.log line attribution. Minima, population SD and repetitions remain in notes; no CPU/HEonGPU ratios are computed for the new rows. The old Criterion rows remain historical.
- Coherent child failures/watchdogs emit one failed/unmeasured row and use no success timings, including timings printed before later equality assertions. No capacity SKIP is invented. Contradictory/malformed terminal evidence is an error.
- Hashes attest captured input/source bytes only. They are not historical execution proof. Scientific acceptance is root's separate review. This closes only the registered R47 table integration slice, not original full Task54, Step3/4, all M4/M5 work, or any scientific performance gate.
- All new example fixtures are tiny synthetic records in temporary directories. Their printed times are invented test numbers, never measurements. Overlays exclude future raw/R-47-3 archives before fixture creation; a synthetic future-archive sentinel verifies write isolation.
- An initial exploratory RED had 56 failures, including one invalid test comparison of FULL-omitting overlays against real FULL-populated tables. That test was corrected before the recorded 55-failure RED above. The final absent-input regression uses frozen BASE GPU MD/TeX/source-byte hashes, so future accepted real R47 tables will not redefine its expected pending behavior. Real-root --check independently verifies all existing generated files.
- An additional RED identified a watchdog log/flag contradiction and an unsourced new level cell; both were corrected before final GREEN. No unresolved test failures remain in the focused authorized scope. The skill's whole-project-suite suggestion was not followed because the brief expressly prohibits unrelated native/HE/Rust tests.

## Final GREEN / compatibility transcripts

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 23 tests in 1.392s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `git diff --check 1a59ecea3abef192088c765520496b02355f6aaf -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

## Source identity (SHA256 of exact bytes read)

- `git show bd5cc493db166a282d26b05b1e069f2a0ee629ef:crates/hekit-cuda/examples/batch_streams.rs` -> `e416c28d7a0c6b033d880afe5e0a64e097e18436716be2897cc896a37f9ca8e3`
- `git show bd5cc493db166a282d26b05b1e069f2a0ee629ef:crates/hekit-cuda/src/device.rs` -> `630c4fb623ca96b9b1fd7d631f195a41b82ceb5562301169904f8dd462c8c755`
- Current local source `results/quadruped/scripts/post_full_queue.py` -> `1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9`
- Current local source `results/quadruped/scripts/run_job.sh` -> `46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736`
- Current local source `docs/post-full-queue.md` -> `97779f687207bcad5701ec9258c4ed541eb76ab52c500de9b448a20dd05faa69`
- Current local source `docs/m4-report.md` -> `b270d88647819ad841d6082e3e5df00761e9509221ae7f90ae80dac5ced37ece`

The pinned producer declares d=64, level=5, four jobs, 30 default repetitions after three warmups. Each timing calls device sync. The two pool thresholds are the pinned device constant 256<<20 (268435456 bytes) and u64::MAX (18446744073709551615 bytes). The producer prints an upper-middle repetition median and population SD. Sequential output additionally prints median/4 per product. Equality assertions run after the printed batch timings, so only coherent successful terminal completion can support their interpretation. CPU setup seconds are excluded from performance comparisons. The queue explicitly sets HEKIT_BATCH_REPS=30 for the main example and 5 for nsys, which is rejected as the principal input.

## Owned-file identity and exact diff against BASE

BASE: `1a59ecea3abef192088c765520496b02355f6aaf`.

- `tools/paper_tables.py` BASE SHA256 `47468ae980ce082f99ea48daeb7c8d33cfedf3fa3255bef4a6f8a43ad5529741`; final SHA256 `29223799b8f2c975e08cf97ee20e30438147866f2d8a6bb3c5b21398268088df`
- `tools/test_paper_tables.py` BASE SHA256 `3009bbe3f32a72c83dc2ff5f7ac4c412839f07d829773ec58fc2f050979f336d`; final SHA256 `ac1fb95cf891c37d41061d68799f39ab0b37ac759b8386b2d7048fd5fb373657`

Command: `git diff 1a59ecea3abef192088c765520496b02355f6aaf -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```diff
diff --git a/tools/paper_tables.py b/tools/paper_tables.py
index 5dc91d1..fb6c4ed 100644
--- a/tools/paper_tables.py
+++ b/tools/paper_tables.py
@@ -27,11 +27,14 @@ the M0 model 37; 784 subset rows: the in-library Lazy measurement 35.06, the M3
   (d) ((K - 111H)/S) / R          bootstraps excluded on both sides
 """
 import argparse
+from datetime import datetime
+import hashlib
 import json
 import math
 from pathlib import Path
 import re
 import statistics
+import shlex
 import sys
 
 sys.path.insert(0, str(Path(__file__).resolve().parent))
@@ -201,6 +204,10 @@ REBOOT_PAPER = 'results/quadruped/raw/reboot_emlp1_paper_setting/summary.json'
 LAYOUT = 'results/mnist_reboot_layout.json'
 CRITERION = 'results/quadruped/raw/R-47-2/criterion/cuda_ops_n16_train/{}/new/estimates.json'
 R47_LOG = 'results/quadruped/cuda_ops_r47.log'
+R47_BATCH = 'results/quadruped/raw/R-47-3/R-47-3-example'
+R47_PIN = 'bd5cc493db166a282d26b05b1e069f2a0ee629ef'
+R47_WORKDIR = '/home/kmihara/hekit-post-full-clones/hekit-post-full-r47'
+R47_COMMAND = 'target/release/examples/batch_streams'
 LITERATURE = 'results/reference/literature.json'
 SECURITY_DOC = 'docs/security.md'
 
@@ -601,6 +608,155 @@ def table_ablation(s, inp):
     return t
 
 
+def r47_batch_input(s):
+    """Read the registered example's original runner/queue records, never an alias log.
+
+    This finite parser follows the project producer at R47_PIN, not Criterion or nsys.
+    Hashes identify bytes consumed now; they cannot establish historical execution.
+    """
+    names = ('program.log', 'meta.json', 'post.txt', 'cmd.txt', 'state.json')
+    paths = {name: f'{R47_BATCH}/{name}' for name in names}
+    present = [(s.root / rel).exists() for rel in paths.values()]
+    if not any(present):
+        return None
+    require(all(present), f'{R47_BATCH}: incomplete original terminal evidence')
+    raw, text = {}, {}
+    try:
+        for name, rel in paths.items():
+            raw[name] = (s.root / rel).read_bytes()
+            text[name] = raw[name].decode('utf-8')
+        meta = json.loads(raw['meta.json'], object_pairs_hook=rq1.unique_object)
+        state = json.loads(raw['state.json'], object_pairs_hook=rq1.unique_object)
+        rq1.finite_tree(meta)
+        rq1.finite_tree(state)
+    except (OSError, UnicodeError, ValueError, rq1.SummaryError) as exc:
+        raise TableError(f'{R47_BATCH}: {exc}') from exc
+    require(isinstance(meta, dict) and isinstance(state, dict), f'{R47_BATCH}: expected original objects')
+
+    def check(ok, message):
+        require(ok, f'{R47_BATCH}: {message}')
+
+    def timestamp(value):
+        try:
+            check(isinstance(value, str) and re.fullmatch(
+                r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}', value),
+                'expected timezone-qualified runner timestamp')
+            return datetime.fromisoformat(value).timestamp()
+        except (ValueError, OverflowError) as exc:
+            raise TableError(f'{R47_BATCH}: invalid runner timestamp') from exc
+
+    def argv(value):
+        check(isinstance(value, str), 'missing command record')
+        try:
+            return shlex.split(value)
+        except ValueError as exc:
+            raise TableError(f'{R47_BATCH}: malformed command record') from exc
+
+    check(meta.get('job') == state.get('job') == 'R-47-3-example', 'unexpected job identity')
+    check(meta.get('workdir') == state.get('workdir') == R47_WORKDIR, 'unexpected workdir')
+    check(meta.get('hekit_synced_commit') ==
+          ['commit bd5cc49', 'full ' + R47_PIN, 'dirty_files 0'], 'wrong source pin or clean marker')
+    check(argv(meta.get('command')) == argv(text['cmd.txt']) == [R47_COMMAND] and
+          state.get('command') == [R47_COMMAND], 'unexpected command')
+    check(type(meta.get('threads_cap')) is int and meta['threads_cap'] == 12 and
+          type(meta.get('nice')) is int and meta['nice'] == 10 and meta.get('gpu_job') is True,
+          'wrong thread/nice/GPU limits')
+    check(meta.get('env_thread_caps') == {key: '12' for key in
+          ('OMP_NUM_THREADS', 'RAYON_NUM_THREADS', 'CARGO_BUILD_JOBS')}, 'wrong thread environment')
+    start, end = timestamp(meta.get('start')), timestamp(meta.get('end'))
+    wall = meta.get('wall_s_runner')
+    check(type(wall) in (int, float) and math.isfinite(wall) and wall >= 0 and
+          end >= start and abs(wall - (end - start)) <= 2,
+          'incoherent start/end/wall time')  # date -Is rounds to seconds; wall retains fractions.
+    post = text['post.txt'].splitlines()
+    terminal = [(i, line) for i, line in enumerate(post, 1) if line.startswith('JOB_DONE')]
+    check(len(terminal) == 1 and terminal[0][0] == len(post), 'missing/duplicate/nonterminal JOB_DONE')
+    done = re.fullmatch(r'JOB_DONE rc=(\d+)', terminal[0][1])
+    check(done is not None, 'malformed JOB_DONE')
+    rc = meta.get('exit_status')
+    check(type(rc) is int and 0 <= rc <= 255 and type(state.get('rc')) is int and
+          state['rc'] == rc == int(done[1]), 'child exit mismatch')
+    check(type(state.get('wrapper_rc')) is int and 0 <= state['wrapper_rc'] <= 255,
+          'invalid wrapper exit (distinct from child exit)')
+    check(type(meta.get('watchdog_killed')) is bool, 'missing/invalid watchdog state')
+    check(post and post[0].startswith('date: ') and timestamp(post[0][6:]) >= end,
+          'post snapshot precedes terminal end')
+    check(state.get('log') == '/home/kmihara/hekit-runs/logs/R-47-3-example.log', 'wrong original log path')
+    log = text['program.log']
+    skips = [line for line in log.splitlines() if 'SKIP' in line]
+    check(state.get('skip') is bool(skips) and state.get('skip_lines') == skips, 'inconsistent skip record')
+    watchdog = meta['watchdog_killed']
+    check(watchdog or not any(line.startswith('WATCHDOG:') for line in log.splitlines()),
+          'watchdog log contradicts terminal flag')
+    expected = ('failed: RSS watchdog' if watchdog else
+                'failed: device OOM' if rc and re.search(r'device error|out of memory', log, re.I) else
+                'skipped' if rc == 3 and skips else 'failed' if rc else
+                'done_with_skips' if skips else 'done')
+    check(state.get('status') == expected, 'queue status contradicts child/watchdog/log')
+    sources = [(paths['meta.json'], field) for field in
+               ('job', 'workdir', 'command', 'hekit_synced_commit', 'threads_cap',
+                'env_thread_caps', 'nice', 'gpu_job', 'start', 'end', 'wall_s_runner',
+                'exit_status', 'watchdog_killed')]
+    sources += [(paths['state.json'], field) for field in
+                ('job', 'workdir', 'command', 'rc', 'wrapper_rc', 'status', 'skip', 'skip_lines', 'log')]
+    sources += [(paths['post.txt'], f'line {terminal[0][0]}'), (paths['cmd.txt'], 'line 1')]
+    result = {'rc': rc, 'watchdog': watchdog, 'sources': sources, 'rows': [],
+              'hashes': [(paths[name], hashlib.sha256(raw[name]).hexdigest()) for name in names]}
+    # Even a final timing line precedes equality assertions and pool cleanup in the producer.
+    # A failed child/watchdog never contributes success timings.
+    if rc or watchdog:
+        return result
+    check(not skips, 'this example has no successful capacity SKIP branch')
+    header = None
+    thresholds, timing = {}, {}
+    active = None
+    variants = ('sequential x4, 1 stream', 'batch x4, 2 streams', 'batch x4, 4 streams')
+    for line_no, line in enumerate(log.splitlines(), 1):
+        src = (paths['program.log'], f'line {line_no}')
+        if line.startswith('batch_streams:'):
+            m = re.fullmatch(r'batch_streams: n16_train, d = 64, level 5, 4 products, 30 reps; '
+                             r'CPU setup (\d+\.\d) s', line)
+            check(header is None and m is not None and math.isfinite(float(m[1])),
+                  'expected one principal 30-repetition header')
+            header = src
+        elif line.startswith('pool release threshold:'):
+            m = re.fullmatch(r'pool release threshold: (default|max) \((\d+) bytes\)', line)
+            check(m is not None, 'malformed pool threshold')
+            name, value = m[1], int(m[2])
+            check(header is not None and name not in thresholds and value ==
+                  {'default': 268435456, 'max': 18446744073709551615}[name],
+                  'duplicate/wrong pool threshold')
+            thresholds[name] = src
+            active = name
+        elif line.startswith('[') or 'median ' in line:
+            m = re.fullmatch(r'\[(default|max)\] (sequential x4, 1 stream|batch x4, [24] streams):\s+'
+                             r'median\s+(\d+\.\d{3}) ms\s+min\s+(\d+\.\d{3})\s+sd\s+(\d+\.\d{3})'
+                             r'(?:\s+\((\d+\.\d{3}) ms per product\))?', line)
+            check(m is not None, f'malformed timing at line {line_no}')
+            threshold, variant = m[1], m[2]
+            key = (threshold, variant)
+            check(header is not None and threshold == active and key not in timing,
+                  'duplicate/contradictory timing or threshold context')
+            med, minimum, sd = map(float, m.group(3, 4, 5))
+            check(all(math.isfinite(v) for v in (med, minimum, sd)) and
+                  0 < minimum <= med and sd >= 0, 'nonfinite/negative/incoherent timing')
+            per_product = m[6]
+            check((variant == variants[0]) == (per_product is not None), 'wrong per-product field')
+            if per_product is not None:
+                check(math.isfinite(float(per_product)) and abs(float(per_product) - med / 4) <= 0.000626,
+                      'per-product time contradicts median')  # Both fields are rounded to .001 ms.
+            timing[key] = (med, minimum, sd, src)
+    check(header is not None and set(thresholds) == {'default', 'max'} and
+          set(timing) == {(threshold, variant) for threshold in thresholds for variant in variants},
+          'incomplete principal header/threshold/variant timings')
+    for threshold in ('default', 'max'):
+        for variant in variants:
+            med, minimum, sd, src = timing[threshold, variant]
+            result['rows'].append((threshold, variant, med, minimum, sd,
+                                   [src, header, thresholds[threshold]]))
+    return result
+
+
 def table_gpu(s, inp):
     t = Table('gpu_vs_cpu_ops', 'GPU vs CPU vs HEonGPU, n16_train (R-47-2, criterion medians, ms)',
               ['Operation', 'Level', 'hekit GPU', 'CPU 1 thr', 'CPU 12 thr', 'GPU speed-up (1 / 12 thr)',
@@ -642,7 +798,32 @@ def table_gpu(s, inp):
                          ('matvec_enc x4, 4 streams (untuned R-47-2)', 'matvec_enc_batch4_L5')):
         g, gs = med('gpu_' + bench)
         t.row([label, 5, Cell(f(g, 3), [gs]), '—', '—', '—', 'none published', '—'])
-    t.row(['matvec_enc x4, re-measured after the fix round', 5, 'pending (R-47-3)', '—', '—', '—', '—', '—'])
+    batch = r47_batch_input(s)
+    if batch is None:
+        t.row(['matvec_enc x4, re-measured after the fix round', 5, 'pending (R-47-3)', '—', '—', '—', '—', '—'])
+    else:
+        t.title = 'GPU vs CPU vs HEonGPU, n16_train (historical R-47-2 Criterion; R-47-3 example medians, ms)'
+        if not batch['rows']:
+            t.row(['matvec_enc x4 (R-47-3)', 5,
+                   Cell(f'failed/unmeasured (child exit {batch["rc"]}; watchdog {str(batch["watchdog"]).lower()})',
+                        batch['sources']), '—', '—', '—', 'none published', '—'])
+        for threshold, variant, median, minimum, sd, sources in batch['rows']:
+            label = f'matvec_enc {variant} (R-47-3, pool {threshold})'
+            t.row([Cell(label, sources), Cell('5', [sources[1]]),
+                   Cell(f(median, 3), sources + batch['sources']),
+                   '—', '—', '—', 'none published', '—'])
+            t.note(f'{label}: min {minimum:.3f} ms; SD {sd:.3f} ms; 30 within-run repetitions.', sources)
+        if batch['rows']:
+            t.note('R-47-3 uses example medians, minima and population SD over 30 timed repetitions '
+                   'after 3 warmups, with device synchronization inside each timing; not 30 independent seeds. '
+                   'Successful child completion includes the producer assertions of batch/sequential residue equality. '
+                   'CPU setup seconds are not CPU matvec latency; these are not end-to-end training '
+                   'and not GPU peak measurements. R-47-2 Criterion rows remain historical; no unlike-run '
+                   'CPU speedups or HEonGPU ratios are computed for R-47-3.', batch['sources'])
+        t.note('R-47-3 original terminal provenance is checked here; scientific acceptance remains a separate review. '
+               'Input capture-time SHA256 (not historical execution proof): ' +
+               '; '.join(f'{path} = {digest}' for path, digest in batch['hashes']),
+               [(path, 'raw bytes (SHA256 at table generation)') for path, _ in batch['hashes']])
     for i, e in heon.values():
         t.note(f'HEonGPU {e["operation"]}: {e["source"]}. Caveat: {e["caveat"]}',
                [(LITERATURE, f'heongpu_rtx4090[{i}].source'), (LITERATURE, f'heongpu_rtx4090[{i}].caveat')])
diff --git a/tools/test_paper_tables.py b/tools/test_paper_tables.py
index a423717..60f302a 100644
--- a/tools/test_paper_tables.py
+++ b/tools/test_paper_tables.py
@@ -2,6 +2,7 @@
 import contextlib
 import copy
 import io
+import hashlib
 import json
 from pathlib import Path
 import subprocess
@@ -15,15 +16,15 @@ from test_rq1_summary import synthetic_full
 ROOT = Path(__file__).resolve().parents[1]
 
 
-def archived_overlay(root):
+def archived_overlay(root, source=ROOT):
     """Link read-only archived inputs; new fixture/output paths stay in the temp tree."""
-    (root / 'docs').symlink_to(ROOT / 'docs', target_is_directory=True)
+    (root / 'docs').symlink_to(source / 'docs', target_is_directory=True)
     for base in ('results', 'results/quadruped', 'results/quadruped/raw'):
         dest = root / base
         dest.mkdir(parents=True, exist_ok=True)
-        for p in (ROOT / base).iterdir():
+        for p in (source / base).iterdir():
             q = dest / p.name
-            if (q.exists() or p.name in ('run_all', 'tables', 'R-41-FULL-1', 'R-41-FULL-2',
+            if (q.exists() or p.name in ('run_all', 'tables', 'R-41-FULL-1', 'R-41-FULL-2', 'R-47-3',
                                          'ablation_cuda.json', 'ablation_cpu_l7.json')):
                 continue
             if p.is_file() or (p.is_dir() and base.endswith('/raw')) or p.name == 'reference':
@@ -47,6 +48,48 @@ def rows(table):
     return [[c.text for c in item] for kind, item in table.rows if kind == 'row']
 
 
+R47_DIR = 'results/quadruped/raw/R-47-3/R-47-3-example'
+R47_PIN = 'bd5cc493db166a282d26b05b1e069f2a0ee629ef'
+R47_WD = '/home/kmihara/hekit-post-full-clones/hekit-post-full-r47'
+R47_COMMAND = 'target/release/examples/batch_streams'
+R47_LOG = """batch_streams: n16_train, d = 64, level 5, 4 products, 30 reps; CPU setup 1.2 s
+pool release threshold: default (268435456 bytes)
+[default] sequential x4, 1 stream:   median   40.000 ms  min   38.000  sd  1.000  (10.000 ms per product)
+[default] batch x4, 2 streams:    median   30.000 ms  min   28.000  sd  2.000
+[default] batch x4, 4 streams:    median   20.000 ms  min   18.000  sd  3.000
+pool release threshold: max (18446744073709551615 bytes)
+[max] sequential x4, 1 stream:   median   32.000 ms  min   30.000  sd  0.500  (8.000 ms per product)
+[max] batch x4, 2 streams:    median   24.000 ms  min   22.000  sd  1.500
+[max] batch x4, 4 streams:    median   16.000 ms  min   14.000  sd  2.500
+"""
+
+
+def put_r47(root, rc=0, watchdog=False, log=R47_LOG):
+    """Tiny SYNTHETIC original-format runner/queue records; never measurements."""
+    dest = root / R47_DIR
+    dest.mkdir(parents=True, exist_ok=True)
+    meta = {
+        'job': 'R-47-3-example', 'workdir': R47_WD, 'command': R47_COMMAND,
+        'hekit_synced_commit': ['commit bd5cc49', 'full ' + R47_PIN, 'dirty_files 0'],
+        'threads_cap': 12, 'env_thread_caps': {name: '12' for name in
+            ('OMP_NUM_THREADS', 'RAYON_NUM_THREADS', 'CARGO_BUILD_JOBS')},
+        'nice': 10, 'gpu_job': True, 'start': '2026-11-08T10:00:00+09:00',
+        'end': '2026-11-08T10:00:10+09:00', 'wall_s_runner': 10.1,
+        'exit_status': rc, 'watchdog_killed': watchdog,
+    }
+    state = {'job': 'R-47-3-example', 'rc': rc, 'wrapper_rc': 0,
+             'status': 'failed: RSS watchdog' if watchdog else 'failed' if rc else 'done',
+             'skip': False, 'skip_lines': [], 'command': [R47_COMMAND],
+             'workdir': R47_WD, 'log': '/home/kmihara/hekit-runs/logs/R-47-3-example.log',
+             'evidence_lines': []}
+    originals = {'program.log': log, 'cmd.txt': R47_COMMAND + ' \n',
+                 'meta.json': json.dumps(meta), 'state.json': json.dumps(state),
+                 'post.txt': 'date: 2026-11-08T10:00:10+09:00\nJOB_DONE rc=' + str(rc) + '\n'}
+    for name, text in originals.items():
+        (dest / name).write_text(text)
+    return dest
+
+
 class PaperTablesTests(unittest.TestCase):
     def setUp(self):
         self.tmp = tempfile.TemporaryDirectory()
@@ -225,5 +268,179 @@ class PaperTablesTests(unittest.TestCase):
                     self.build(tables.table_ablation)
 
 
+    def test_r47_absent_keeps_existing_generated_bytes(self):
+        # Break caught: changing any historical table when canonical R47 originals are absent.
+        with contextlib.redirect_stdout(io.StringIO()):
+            self.assertEqual(tables.main(['--root', str(self.root)]), 0)
+        # Frozen bytes at BASE 1a59ecea; independent of a future accepted R47 archive
+        # and its regenerated tables. The real-repository --check covers every output.
+        expected = {
+            'paper/tables/gpu_vs_cpu_ops.tex': 'c9104367559251ee43275272c219c2e632b59225c1d56eda7170422afe3043cf',
+            'results/tables/gpu_vs_cpu_ops.md': 'af5f19dd3f4cc993b43643a49c3bcbc0600854ddee638adfa402f4fffd6ff242',
+        }
+        for rel, digest in expected.items():
+            self.assertEqual(hashlib.sha256((self.root / rel).read_bytes()).hexdigest(), digest)
+        gpu_sources = ''.join(line for line in
+            (self.root / 'results/tables/sources.tsv').read_text().splitlines(keepends=True)
+            if line.startswith('gpu_vs_cpu_ops\t'))
+        self.assertEqual(hashlib.sha256(gpu_sources.encode()).hexdigest(),
+                         '4b72fd7a51b2d88682c675aff653c736a8dac33418de08079f4d1cafb5207c80')
+
+    def test_r47_success_six_rows_keep_statistics_and_actual_line_sources(self):
+        # Break caught: leaving a pending row, mixing thresholds, losing min/SD or using old ratios.
+        dest = put_r47(self.root)
+        before = {p.name: p.read_bytes() for p in dest.iterdir()}
+        t = self.build(tables.table_gpu)
+        r47 = [r for r in rows(t) if 'R-47-3' in r[0]]
+        self.assertEqual(len(r47), 6)
+        self.assertEqual([r[2] for r in r47], ['40.000', '30.000', '20.000', '32.000', '24.000', '16.000'])
+        self.assertTrue(all(r[3:] == ['—', '—', '—', 'none published', '—'] for r in r47))
+        self.assertIn('default', r47[0][0])
+        self.assertIn('max', r47[3][0])
+        self.assertIn('Criterion', t.title)
+        self.assertIn('example', t.title)
+        md = tables.render_md(t, 'synthetic/')
+        self.assertNotIn('pending (R-47-3)', md)
+        self.assertIn('min 38.000 ms; SD 1.000 ms; 30 within-run repetitions', md)
+        self.assertIn('not 30 independent seeds', md)
+        self.assertIn('not end-to-end training', md)
+        self.assertIn('not GPU peak', md)
+        sources = '\n'.join(tables.source_lines(t))
+        for n in (3, 4, 5, 7, 8, 9):
+            self.assertIn(R47_DIR + '/program.log\tline ' + str(n), sources)
+        self.assertIn(R47_DIR + '/meta.json\texit_status', sources)
+        self.assertIn(R47_DIR + '/post.txt\tline 2', sources)
+        self.assertIn('capture-time SHA256', md)
+        self.assertIn('not historical execution proof', md)
+        for name, raw in before.items():
+            self.assertIn(hashlib.sha256(raw).hexdigest(), md)
+        new_rows = [item for kind, item in t.rows if kind == 'row' and 'R-47-3' in item[0].text]
+        self.assertIn((R47_DIR + '/program.log', 'line 1'), new_rows[0][1].sources)
+        self.assertEqual(before, {p.name: p.read_bytes() for p in dest.iterdir()})
+
+    def test_r47_failure_discards_partial_success_timings(self):
+        # Break caught: accepting timing lines printed before a later assertion/watchdog failure.
+        for rc, watchdog in ((101, False), (143, True), (0, True), (3, False)):
+            with self.subTest(rc=rc, watchdog=watchdog):
+                put_r47(self.root, rc, watchdog, '\n'.join(R47_LOG.splitlines()[:4]) + '\npanic: synthetic failure\n')
+                t = self.build(tables.table_gpu)
+                new = [r for r in rows(t) if 'R-47-3' in r[0]]
+                self.assertEqual(len(new), 1)
+                self.assertIn('failed/unmeasured', new[0][2])
+                self.assertNotIn('40.000', tables.render_md(t, 'synthetic/'))
+                self.assertNotIn('Memory SKIP', tables.render_md(t, 'synthetic/'))
+                self.assertIn(R47_DIR + '/meta.json', '\n'.join(tables.source_lines(t)))
+
+    def test_r47_rejects_partial_originals_and_alias_only_is_pending(self):
+        # Break caught: silently selecting an alias or historical data for a partial canonical job.
+        alias = self.root / 'results/quadruped/batch_streams_r47_3.log'
+        # Overlay may link a future alias; remove the temp link before fixture writes.
+        if alias.is_symlink():
+            alias.unlink()
+        alias.write_text(R47_LOG)
+        self.assertTrue(any('pending (R-47-3)' in r for r in rows(self.build(tables.table_gpu))))
+        dest = put_r47(self.root)
+        for name in ('program.log', 'meta.json', 'post.txt', 'cmd.txt', 'state.json'):
+            with self.subTest(name=name):
+                original = (dest / name).read_bytes()
+                (dest / name).unlink()
+                with self.assertRaises(tables.TableError):
+                    self.build(tables.table_gpu)
+                (dest / name).write_bytes(original)
+
+    def test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance(self):
+        # Break caught: accepting another pin/job/command or untrustworthy terminal records.
+        mutations = [
+            ('meta.json', 'job', 'R-47-3-nsys'),
+            ('meta.json', 'hekit_synced_commit', ['commit bd5cc49', 'full ' + 'a'*40, 'dirty_files 0']),
+            ('meta.json', 'hekit_synced_commit', ['commit bd5cc49', 'full ' + R47_PIN, 'dirty_files 1']),
+            ('meta.json', 'hekit_synced_commit', ['commit bd5cc49', 'full ' + R47_PIN, 'dirty_files 0', 'dirty_files 1']),
+            ('meta.json', 'workdir', '/tmp/other'), ('meta.json', 'command', 'nsys ' + R47_COMMAND),
+            ('meta.json', 'threads_cap', 1), ('meta.json', 'nice', 0), ('meta.json', 'gpu_job', False),
+            ('meta.json', 'env_thread_caps', {}), ('meta.json', 'start', '2026-11-08T10:00:00'),
+            ('meta.json', 'end', '2026-11-08T09:59:00+09:00'),
+            ('meta.json', 'wall_s_runner', 1000), ('meta.json', 'watchdog_killed', 'false'),
+            ('meta.json', 'exit_status', 1), ('state.json', 'rc', 1),
+            ('state.json', 'status', 'failed'), ('state.json', 'command', ['other']),
+            ('state.json', 'workdir', '/tmp/other'), ('state.json', 'job', 'R-47-3-nsys'),
+            ('state.json', 'wrapper_rc', '0'), ('state.json', 'skip', True),
+        ]
+        for name, key, value in mutations:
+            with self.subTest(name=name, key=key, value=value):
+                dest = put_r47(self.root)
+                doc = json.loads((dest / name).read_text())
+                doc[key] = value
+                (dest / name).write_text(json.dumps(doc))
+                with self.assertRaises(tables.TableError):
+                    self.build(tables.table_gpu)
+        for name, text in [('cmd.txt', 'nsys ' + R47_COMMAND), ('post.txt', 'JOB_DONE rc=1\n'),
+                           ('post.txt', 'JOB_DONE rc=0\nJOB_DONE rc=0\n'),
+                           ('meta.json', '{'), ('state.json', '{}')]:
+            with self.subTest(name=name, text=text):
+                dest = put_r47(self.root)
+                (dest / name).write_text(text)
+                with self.assertRaises(tables.TableError):
+                    self.build(tables.table_gpu)
+
+    def test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings(self):
+        # Break caught: plausible metrics from malformed logs or the separate five-rep profile.
+        invalid = [
+            R47_LOG.replace('30 reps', '5 reps'), R47_LOG.replace('d = 64', 'd = 32'),
+            R47_LOG + R47_LOG.splitlines()[0] + '\n',
+            R47_LOG + R47_LOG.splitlines()[3] + '\n',
+            R47_LOG.replace(R47_LOG.splitlines()[4] + '\n', ''),
+            R47_LOG.replace('268435456 bytes', '0 bytes'),
+            R47_LOG.replace('[max] batch x4, 4', '[max] batch x4, 3'),
+            R47_LOG.replace('30.000 ms', 'nan ms'),
+            R47_LOG.replace('30.000 ms', 'inf ms'),
+            R47_LOG.replace('30.000 ms', '-30.000 ms'),
+            R47_LOG.replace('30.000 ms', '0.000 ms'),
+            R47_LOG.replace('min   28.000', 'min   38.000'),
+            R47_LOG.replace('sd  2.000', 'sd -2.000'),
+            R47_LOG.replace('(10.000 ms per product)', '(11.000 ms per product)'),
+            R47_LOG + 'SKIP: synthetic capacity\n',
+            R47_LOG + '[other] batch x4, 4 streams: median 1.000 ms min 1.000 sd 0.000\n',
+            R47_LOG + 'WATCHDOG: tree RSS 100 kB > 90 kB, killing own job tree\n',
+        ]
+        for case, log in enumerate(invalid):
+            with self.subTest(case=case):
+                put_r47(self.root, log=log)
+                with self.assertRaises(tables.TableError):
+                    self.build(tables.table_gpu)
+
+    def test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it(self):
+        # Break caught: a late R47 parse failure leaving plausible partial paper output.
+        dest = put_r47(self.root, log=R47_LOG.replace('30 reps', '5 reps'))
+        with contextlib.redirect_stderr(io.StringIO()), contextlib.redirect_stdout(io.StringIO()):
+            self.assertEqual(tables.main(['--root', str(self.root)]), 2)
+            self.assertFalse((self.root / 'paper').exists())
+            self.assertEqual(tables.main(['--root', str(self.root), '--from-run-all', 'quick']), 0)
+        self.assertTrue(dest.is_dir())
+
+    def test_r47_compatibility_entrypoint_renders_same_success_table(self):
+        # Break caught: exposing the R47 data only through one CLI, or dropping it in full mode.
+        put_r47(self.root)
+        for args in ([], ['--from-run-all', 'full']):
+            p = subprocess.run([sys.executable, str(ROOT / 'tools/tables.py'), '--root', str(self.root),
+                                '--sources', 'gpu_vs_cpu_ops', *args], capture_output=True, text=True)
+            self.assertEqual(p.returncode, 0, p.stderr)
+            self.assertIn(R47_DIR + '/program.log\tline 9', p.stdout)
+
+    def test_r47_overlay_excludes_future_archives_from_fixture_writes(self):
+        # Break caught: future actual R47 archive symlinked into a fixture then overwritten.
+        with tempfile.TemporaryDirectory() as archived, tempfile.TemporaryDirectory() as fixture:
+            archived = Path(archived)
+            fixture = Path(fixture)
+            for directory in ('docs', 'results/quadruped/raw/R-47-3'):
+                (archived / directory).mkdir(parents=True, exist_ok=True)
+            sentinel = archived / 'results/quadruped/raw/R-47-3/original.log'
+            sentinel.write_text('SYNTHETIC original')
+            archived_overlay(fixture, source=archived)
+            dest = put_r47(fixture)
+            self.assertFalse((fixture / 'results/quadruped/raw/R-47-3').is_symlink())
+            self.assertNotEqual(dest.resolve(), archived / R47_DIR)
+            self.assertEqual(sentinel.read_text(), 'SYNTHETIC original')
+
+
 if __name__ == '__main__':
     unittest.main()
```

stderr (verbatim):
```text
```

## Concerns / handoff

No blocking implementation concern found in this bounded slice. Raw canonical inputs are still absent; all populated-branch validation is synthetic. Root should review exactly the two-file diff and report, then retain the original full Task54 and collection/scientific acceptance gates. No claim of R47 collection, actual GPU timing, independent seeds, training speedup, peak memory, or full milestone completion is made.
