# Task54 R47 table integration independent review

Date: 2026-11-08. Repository: /Users/marconi/Documents/research/hekit.
BASE: `1a59ecea3abef192088c765520496b02355f6aaf`.

SPEC: **PASS** for the bounded R47 table integration slice.
QUALITY: **PASS** for the same slice. No actionable findings.

## Reviewed scope and evidence

Reviewed the complete BASE-relative diff of `tools/paper_tables.py`, `tools/test_paper_tables.py`, and only the added canonical-archive paragraph in `docs/post-full-queue.md:143`. Read the integration brief, bounded sections of its large report (RED failures, additional RED, GREEN, source identities and limits), the existing Store/Cell/render/output code, the exact pinned producer through `git show`, its pinned pool constant, and relevant local queue/runner and M4 interpretation source. No broad mutable Rust review.

The requested Python hashes match both at review start and after validation. Exact source identities and canonical absence are retained in the raw probe output below.

## Specification checks

- `paper_tables.py:611-757`: all five absent canonical originals return the historical pending behavior; any partial set errors. An alias alone is ignored. The actual canonical directory is absent at this review.
- `paper_tables.py:644-706`: job, exact full pin plus clean marker, workdir, command, nice/thread/GPU values, timezone-qualified coherent times, meta/state/post child exit, watchdog and queue classification follow the original runner/queue fields. Wrapper status remains distinct from child status. Duplicate JSON keys and nonfinite JSON values are rejected.
- The pinned producer has d64, level5, four products, 30 repetitions, three warmups, default256MiB/maxu64 thresholds, and one/two/four-stream variants. Each timing includes device synchronization. Its reported median is the sorted element at index n/2 (upper middle for 30); its SD uses population variance. The parser retains the printed median rather than recomputing it.
- `paper_tables.py:709-711`: coherent nonzero child exit/watchdog returns before extraction, including failure after all six timing lines. The producer's residue assertions and pool cleanup happen after timing prints, so this ordering prevents partial success promotion. No capacity SKIP measurement is invented.
- `paper_tables.py:712-757`: principal header, exact threshold values, six unique complete rows, threshold context, finite positive timing/minimum, nonnegative SD and rounded sequential per-product consistency are checked. Duplicate/malformed/incomplete/profile-five-repetition inputs fail.
- `paper_tables.py:801-827`: six success rows retain medians, min/SD/repetition notes and actual program.log line sources. New row level comes from header attribution. Historical R47-2 rows remain. New CPU/HEonGPU ratios are absent. Notes distinguish within-run repetitions from seeds, setup from CPU latency, and these timings from training or GPU peak.
- Input SHA256 values identify the exact consumed bytes and are explicitly not historical execution proof. Scientific acceptance remains separate.
- `test_paper_tables.py:19-32,334-346,429-442`: overlays exclude future R-47-3 archives; alias fixture writes unlink an overlay symlink first; isolated synthetic sentinel verifies future-archive protection. All new fixture writes are temporary.
- Existing render-before-write behavior prevents partial generated outputs on parse failure. Both real-root check-only entrypoints pass; absent-input GPU Markdown/TeX/source regression hashes pass. Quick mode bypasses malformed R47 input as intended; full compatibility entrypoint exposes synthetic R47 sources.
- The root documentation paragraph names the same five-file destination contract, preserves other captured originals/observations, and explicitly states that actual measurement files have not yet been retrieved.

## Quality assessment

Correctness: PASS, supported by producer/runner comparison and positive/negative synthetic coverage.
Security and data integrity: PASS within local archive intake; raw originals are read only, ambiguous evidence fails closed, and future archive fixture writes are isolated.
Performance: PASS for the registered small finite log intake; no native work is introduced.
Maintainability: PASS; a single finite parser and a localized GPU-table branch preserve existing table architecture. Stdlib only, no unrelated schema tightening.

## Independent verification

All subprocesses below inherited `PYTHONDONTWRITEBYTECODE=1`; no real generated-table write command was run. stdout/stderr are verbatim. Each command had a 60-second subprocess timeout.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 23 tests in 1.546s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout:
```text
```

stderr:
```text
```

Command: `git diff --check 1a59ecea3abef192088c765520496b02355f6aaf -- tools/paper_tables.py tools/test_paper_tables.py docs/post-full-queue.md`

Exit: 0

stdout:
```text
```

stderr:
```text
```

## Additional independent synthetic probes and exact identities

Command: `PYTHONDONTWRITEBYTECODE=1 python3 -` with the following stdin (run from repository root):

```python
import sys, json, tempfile, hashlib, subprocess
from pathlib import Path
sys.path.insert(0, 'tools')
import paper_tables as p
from test_paper_tables import put_r47, R47_LOG
with tempfile.TemporaryDirectory(prefix='synthetic-r47-review-') as tmp:
 root=Path(tmp)
 dest=put_r47(root, rc=101, log=R47_LOG+'panic: synthetic late assertion failure\n')
 result=p.r47_batch_input(p.Store(root))
 assert result['rows']==[] and result['rc']==101
 print('PASS: six earlier synthetic timing rows discarded after late child failure')
 dest=put_r47(root, rc=1, log='Device error: synthetic out of memory\n')
 state=json.loads((dest/'state.json').read_text()); state['status']='failed: device OOM'
 (dest/'state.json').write_text(json.dumps(state))
 assert p.r47_batch_input(p.Store(root))['rows']==[]
 print('PASS: coherent device-OOM failure is unmeasured')
 for name, change in (
  ('duplicate JSON key', lambda d:(d/'meta.json').write_text((d/'meta.json').read_text()[:-1]+', "job": "R-47-3-example"}')),
  ('nonfinite JSON', lambda d:(d/'meta.json').write_text((d/'meta.json').read_text().replace('"wall_s_runner": 10.1', '"wall_s_runner": NaN'))),
  ('nonterminal post marker', lambda d:(d/'post.txt').write_text((d/'post.txt').read_text()+'synthetic trailing output\n')),
  ('inconsistent skip lines', lambda d:(d/'program.log').write_text(R47_LOG+'SKIP: synthetic\n')),
 ):
  dest=put_r47(root); change(dest)
  try:p.r47_batch_input(p.Store(root))
  except p.TableError:print('PASS: rejected '+name)
  else:raise AssertionError('accepted '+name)
paths=['tools/paper_tables.py','tools/test_paper_tables.py','docs/post-full-queue.md','docs/m4-report.md','results/quadruped/scripts/post_full_queue.py','results/quadruped/scripts/run_job.sh','.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r47-table-integration-brief.md','.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r47-table-integration-report.md']
for path in paths: print(hashlib.sha256(Path(path).read_bytes()).hexdigest(),path)
for path in ['crates/hekit-cuda/examples/batch_streams.rs','crates/hekit-cuda/src/device.rs']:
 spec='bd5cc493db166a282d26b05b1e069f2a0ee629ef:'+path
 raw=subprocess.check_output(['git','show',spec]); print(hashlib.sha256(raw).hexdigest(),spec)
print('canonical_present', (Path('results/quadruped/raw/R-47-3/R-47-3-example')).exists())
```

Exit: 0

stdout:
```text
PASS: six earlier synthetic timing rows discarded after late child failure
PASS: coherent device-OOM failure is unmeasured
PASS: rejected duplicate JSON key
PASS: rejected nonfinite JSON
PASS: rejected nonterminal post marker
PASS: rejected inconsistent skip lines
29223799b8f2c975e08cf97ee20e30438147866f2d8a6bb3c5b21398268088df tools/paper_tables.py
ac1fb95cf891c37d41061d68799f39ab0b37ac759b8386b2d7048fd5fb373657 tools/test_paper_tables.py
97779f687207bcad5701ec9258c4ed541eb76ab52c500de9b448a20dd05faa69 docs/post-full-queue.md
b270d88647819ad841d6082e3e5df00761e9509221ae7f90ae80dac5ced37ece docs/m4-report.md
1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9 results/quadruped/scripts/post_full_queue.py
46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736 results/quadruped/scripts/run_job.sh
bc450b5fd0d2bfd71a1b7a2643fb1d91a3134dc36c6dd90da7253c0157c4a9b8 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r47-table-integration-brief.md
28a13ef440785be99fdc31d6dc96f8a423881531c4ab4d9790a0d6b7ebd0f827 .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r47-table-integration-report.md
e416c28d7a0c6b033d880afe5e0a64e097e18436716be2897cc896a37f9ca8e3 bd5cc493db166a282d26b05b1e069f2a0ee629ef:crates/hekit-cuda/examples/batch_streams.rs
630c4fb623ca96b9b1fd7d631f195a41b82ceb5562301169904f8dd462c8c755 bd5cc493db166a282d26b05b1e069f2a0ee629ef:crates/hekit-cuda/src/device.rs
canonical_present False
```

stderr: empty.

## Limitations

This is source review and bounded Python synthetic/check-only validation, not real R47 measurement, historical execution proof, native/scientific acceptance, or whole Task54 completion. No actual R47 originals were available. Population-distribution plausibility beyond the explicit finite/min/median/per-product checks cannot be established from aggregate printed values alone. No PDF build or rendered-paper layout inspection was performed. Original RED transcripts were inspected from the worker's report, not rerun against an earlier implementation. No Cargo/Rust execution, SSH/GPU/HE work, Git mutation, actual-results mutation, generated-table writes, or other agents were used. The only persistent review write is this report.

