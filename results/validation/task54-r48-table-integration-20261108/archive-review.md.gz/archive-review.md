# R48 table integration archive/docs independent review

SPEC: **PASS**. QUALITY: **PASS**. No actionable finding in the reviewed eleven-file archive snapshot and the single new final R48 section of docs/m5-report.md.

## Scope and result

Reviewed results/validation/task54-r48-table-integration-20261108 at its eleven-file pre-archive-review state: README.md, manifest.json, reviewed.diff.gz, six Markdown evidence gzip files and two layout-record gzip files. This report itself is not yet part of that snapshot; root's later lossless addition and resulting manifest bytes are outside the exact hashes below.

All eight compressed original evidence files decompress byte-for-byte to their corresponding ledger originals. Their original lengths, original SHA256 and stored SHA256 agree with manifest.json. The retained initial failure review, author RED evidence, FIX1 correction and PASS rereview remain distinct originals.

The manifest pins the final independently reviewed FIX1 sources:
- tools/paper_tables.py: 106815 bytes, SHA256 `f7e3774f7124fe24e5a7a882df902ea7584aaa62ece7855a43def5d880af6b38`.
- tools/test_paper_tables.py: 74518 bytes, SHA256 `a791c10d58485b0262dae7aee70be390ac72d7d7ea15aa7416a773257d414402`.

reviewed.diff.gz decompresses exactly to the current two-file diff against original BASE `3090d1e6c71e38e8efb8e713a0d265b9d788b522`: 47784 bytes, SHA256 `51d3e6d4046a11534237d153ce755bda49548de3104ddb197f72d13ce4488ca4`. No unrelated current documentation or Rust changes enter that diff.

README.md SHA256 `598e37f4f5c33ba392d7ff23040669ed9ea139c170e2af9ab35b6424aa641193` and manifest.json SHA256 `a93a4b22740fb3d796f941dd30c76228259bf3dc2494e8229bea3dc7ad2dbc70` accurately distinguish implementation validation from measurement. They retain the P2 history, finite fix, standalone CPU limits, actual workload-label limitations and absent-evidence behavior.

docs/m5-report.md is append-only against HEAD in this reviewed state. The sole new section is 938 bytes, SHA256 `ce04f8a204373314bf4518b876c3347db39c497c14af3b62916d578b04613208`; the complete current document is 177708 bytes, SHA256 `7a7fbd3356375bb755beb4f5efd5bcba19194402b7094bcae36f0add3f495d06`. Its link resolves to the reviewed archive README. The section's 52-test/entrypoint/rereview claims agree with the preserved final report and independent rereview. The original R48 archive and all five canonical binaries are still absent locally. No remote state was observed.

## Layout and claim boundaries

The original layout record pins initial source, an 11-page marked synthetic PDF, its log and page-09.png. Its visual-inspection map contains page09 only; scope explicitly excludes other pages and future actual-result layout. The README and final R48 document section preserve that restriction and do not claim a complete final-paper inspection. Existing PDF/log/PNG bytes at the recorded MicroSD path match all recorded lengths and hashes. The log confirms eleven pages and zero occurrences of the four recorded warning categories.

The FIX1 byte-comparison record pins the reviewed final sources and the same prior PDF directory, identifies seven unique table names with both TeX and Markdown hashes, and pins the complete source index. All seven existing TeX inputs, seven Markdown inputs and sources.tsv at that exact saved layout directory match the record. This corroborates the archived comparison's exact target bytes. The previous independent FIX1 review additionally established valid R48 rendering identity and source-identical renderers/R47/R52 paths. No new fixture regeneration or PDF compilation was needed here.

The README and R48 section correctly keep R48-1 mandatory training acceptance, real R48 measurements/scientific adoption, final actual-result PDF and full Task54 incomplete. Within-seed tests and synthetic layout evidence are not upgraded into research results. Statements about previous unchanged generated tables are supported by the preserved independent check-only results, not a new write or build in this archive review.

## Exact bounded verification command and raw result

The command below is read-only: gzip decoding is in memory, Git is used only for show/diff, and existing MicroSD files are hashed without rendering or modifying them.

```sh
python3 -B - <<'PY'
from pathlib import Path
import gzip,json,hashlib,subprocess,re
A=Path('results/validation/task54-r48-table-integration-20261108')
L=Path('.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5')
sha=lambda b:hashlib.sha256(b).hexdigest()
manifest=json.loads((A/'manifest.json').read_bytes())
expected={'README.md','manifest.json','reviewed.diff.gz'}|{e['file'] for e in manifest['original_evidence']}
assert {p.name for p in A.iterdir()}==expected
print('ARCHIVE_FILE_COUNT',len(expected))
for path in sorted(A.iterdir()):
 raw=path.read_bytes();print('ARCHIVE',path.name,len(raw),sha(raw))
for e in manifest['original_evidence']:
 raw=(A/e['file']).read_bytes();decoded=gzip.decompress(raw);original=(L/e['file'][:-3]).read_bytes()
 assert raw and decoded==original and len(decoded)==e['original_bytes'] and sha(decoded)==e['original_sha256'] and sha(raw)==e['stored_sha256']
 print('LOSSLESS',e['file'],len(decoded),sha(decoded))
for path,pin in manifest['sources'].items():
 raw=Path(path).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'];print('SOURCE_PIN',path,len(raw),sha(raw))
diff=subprocess.check_output(['git','diff',manifest['base'],'--',*manifest['sources']])
archived=gzip.decompress((A/'reviewed.diff.gz').read_bytes());assert diff==archived and sha(diff)==manifest['reviewed_diff_sha256']
print('DIFF_EXACT_BASE',manifest['base'],len(diff),sha(diff))
docs=Path('docs/m5-report.md');raw=docs.read_bytes();head=subprocess.check_output(['git','show','HEAD:docs/m5-report.md'])
assert raw.startswith(head);added=raw[len(head):]
assert added.decode().count('## ')==1 and 'R48アブレーションの表入力を準備' in added.decode()
for link in re.findall(r'\]\(([^)]+)\)',added.decode()):
 target=docs.parent/link;assert target.is_file();print('ADDED_DOC_LINK',link,'exists')
print('DOC_PIN',len(raw),sha(raw));print('APPEND_ONLY_SECTION_PIN',len(added),sha(added))
for rel in ('raw/R-48','ablation_cuda.json','ablation_cuda_sgd.json','ablation_cpu_l7.json','ablation_cpu_l7_sgd.json','ablation_cpu.json'):
 path=Path('results/quadruped')/rel;assert not path.exists() and not path.is_symlink();print('ACTUAL_R48_ABSENT',path)
layout=json.loads((L/'task-54-r48-layout-verification.json').read_bytes())
comparison=json.loads((L/'task-54-r48-fix1-layout-byte-verification.json').read_bytes())
assert layout['directory']==comparison['prior_marked_pdf_directory']
assert layout['pages']==11 and layout['compiler_exit']==0
assert set(layout['visual_inspection'])=={'page-09.png'}
assert all(v==0 for v in layout['warning_counts'].values())
for path,pin in comparison['fixed_source_pins'].items():assert sha(Path(path).read_bytes())==pin
directory=Path(layout['directory'])
for rel,pin in layout['files'].items():
 raw=(directory/rel).read_bytes();assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'];print('LAYOUT_ARTIFACT_PIN',rel,len(raw),sha(raw))
assert len(comparison['tables'])==len({t['name'] for t in comparison['tables']})==7
for t in comparison['tables']:
 for kind,folder in [('tex','source/tables'),('md','synthetic-markdown-tables')]:
  path=directory/folder/(t['name']+'.'+kind);raw=path.read_bytes();pin=t[kind]
  assert len(raw)==pin['bytes'] and sha(raw)==pin['sha256'];print('EXACT_PDF_INPUT_PIN',t['name'],kind,len(raw),sha(raw))
raw=(directory/'synthetic-markdown-tables/sources.tsv').read_bytes();assert sha(raw)==comparison['source_index_sha256'];print('SOURCE_INDEX_PIN',len(raw),sha(raw))
log=(directory/'build/main.log').read_text()
for token in layout['warning_counts']:
 assert log.count(token)==layout['warning_counts'][token];print('LOG_COUNT',repr(token),log.count(token))
for line in log.splitlines():
 if 'Output written on' in line:print('LOG_PDF_OUTPUT',line)
print('VERDICT','archive/docs consistency checks PASS; no tests or build run')
PY
```

Exit: 0. Raw combined exec_command output:
```text
ARCHIVE_FILE_COUNT 11
ARCHIVE README.md 2360 598e37f4f5c33ba392d7ff23040669ed9ea139c170e2af9ab35b6424aa641193
ARCHIVE manifest.json 2849 a93a4b22740fb3d796f941dd30c76228259bf3dc2494e8229bea3dc7ad2dbc70
ARCHIVE reviewed.diff.gz 13233 9d7bc764ae2a12ed5b874accc114880213daedace8950827a0b7fb2b075f74e7
ARCHIVE task-54-r48-fix1-layout-byte-verification.json.gz 1272 50a386481d88f87a15464faf0bcd54ce90778b640f04621859b5031b43b847b4
ARCHIVE task-54-r48-layout-verification.json.gz 851 1c6cca0707030f857a23e47de4f3f6be1a817bcd78056f0e50b6bd9842388e07
ARCHIVE task-54-r48-standalone-cpu-ruling.md.gz 1004 436e1482b3f92e193c15d08cb2e913759430d2780516dd7e154c5c9aec388941
ARCHIVE task-54-r48-table-integration-brief.md.gz 2957 b67fdb3bc1d3d515fe6bc5a388c0a86113bba8d2453a7bda3505295f609d01d0
ARCHIVE task-54-r48-table-integration-fix1-report.md.gz 8895 c57dc3495eed9221d292cb4bf981af8f19b6df52cc9916121cebcadb24d9641e
ARCHIVE task-54-r48-table-integration-fix1-review.md.gz 7973 19792b50d394f87b4899b4d1458cce196db3e244865d505066bfd02bba1d6454
ARCHIVE task-54-r48-table-integration-report.md.gz 26967 2eb5cda6d06019342c7b9a1a9685d147efadb11f7e034430fb5d9b298eeccfb6
ARCHIVE task-54-r48-table-integration-review.md.gz 7528 710841725585c1d821673f2d84e88b31784db94f313fd27bd784180734ea6794
LOSSLESS task-54-r48-table-integration-brief.md.gz 5676 00f0425fc0e2a50aaf156a2de35a6d5175bb68db577e74981281cdebbb14e6d6
LOSSLESS task-54-r48-standalone-cpu-ruling.md.gz 1812 06756d949c8c16891b462fb5c72007a4c218486b2da90a8e0eb68c83c5b48a44
LOSSLESS task-54-r48-table-integration-report.md.gz 160586 366a81203504343a61a47dd2c95cf37b1b2a1df41a8bb6fd1c8a47798fc31354
LOSSLESS task-54-r48-table-integration-review.md.gz 22745 b8274e24432a4ae14a42a54e33bc77e58f0ca945a2409ad4897fcd4bde70d0c4
LOSSLESS task-54-r48-table-integration-fix1-report.md.gz 91133 2be493e140a7f4a557036b16cc1779bd8f9f7c4c4e845c1f1c2a1183c59089ea
LOSSLESS task-54-r48-table-integration-fix1-review.md.gz 26368 911a4a68c0305ca1699e294d4ca6716c41fd12bdf7f55151ad00004555975895
LOSSLESS task-54-r48-layout-verification.json.gz 1471 85abe9758527c7287603c118141781e5a981a3b204d329b02876a8231ff4362a
LOSSLESS task-54-r48-fix1-layout-byte-verification.json.gz 2832 59de0558199576962196b8db22a4d3a61904e966ae5574e0e21d48845709338a
SOURCE_PIN tools/paper_tables.py 106815 f7e3774f7124fe24e5a7a882df902ea7584aaa62ece7855a43def5d880af6b38
SOURCE_PIN tools/test_paper_tables.py 74518 a791c10d58485b0262dae7aee70be390ac72d7d7ea15aa7416a773257d414402
DIFF_EXACT_BASE 3090d1e6c71e38e8efb8e713a0d265b9d788b522 47784 51d3e6d4046a11534237d153ce755bda49548de3104ddb197f72d13ce4488ca4
ADDED_DOC_LINK ../results/validation/task54-r48-table-integration-20261108/README.md exists
DOC_PIN 177708 7a7fbd3356375bb755beb4f5efd5bcba19194402b7094bcae36f0add3f495d06
APPEND_ONLY_SECTION_PIN 938 ce04f8a204373314bf4518b876c3347db39c497c14af3b62916d578b04613208
ACTUAL_R48_ABSENT results/quadruped/raw/R-48
ACTUAL_R48_ABSENT results/quadruped/ablation_cuda.json
ACTUAL_R48_ABSENT results/quadruped/ablation_cuda_sgd.json
ACTUAL_R48_ABSENT results/quadruped/ablation_cpu_l7.json
ACTUAL_R48_ABSENT results/quadruped/ablation_cpu_l7_sgd.json
ACTUAL_R48_ABSENT results/quadruped/ablation_cpu.json
LAYOUT_ARTIFACT_PIN build/main.pdf 525544 edf21ba3f4d9c6f8bfaf37c577889d3580df3e6fa6ab8156388aa1536a33cbbc
LAYOUT_ARTIFACT_PIN build/main.log 61943 e2bc8ad183d90b5a19c857afe0571a4bd93967c91fec52bdc8790c3b41ac2e5e
LAYOUT_ARTIFACT_PIN build/page-09.png 610169 347fd9da3c2ffa8644ab99ee6cb815ffbb3d0f150b70c8ed54dc6b13db4ac503
EXACT_PDF_INPUT_PIN rq1_ks tex 3129 6ec8922b0dfed196376ca573cb930a9c9588abc0f98065378b6c56f9ecea19ae
EXACT_PDF_INPUT_PIN rq1_ks md 2921 3d69af80f393e85184adb5a9648882985bd10c2ac8ee455a8eaf851082552762
EXACT_PDF_INPUT_PIN wallclock_same_cpu tex 2107 cd532fe2f7cc1b0390221bfadd5a0a5138d805960512d68957b321471cb12daa
EXACT_PDF_INPUT_PIN wallclock_same_cpu md 1859 2d3efc94cec6162da5722f64ca2463075b63acfc16db26855b0b82cabd9e2895
EXACT_PDF_INPUT_PIN accuracy_vs_reboot tex 5232 11bf5c4ed18ba4335674d34db96db373694c6e6512ca7dfb6b202ade183d9d3a
EXACT_PDF_INPUT_PIN accuracy_vs_reboot md 9562 150f210ab26f99d1e1aafb3d510a0743e8cad15e7b963ff17d0177a2d35715ef
EXACT_PDF_INPUT_PIN rq3_ablation tex 9570 19e651bfe1bd63b5202300ba8f1956ea5969ab7ad23329d011d8937e923f3ba8
EXACT_PDF_INPUT_PIN rq3_ablation md 9297 478327a79d58603f3e7e6a44668a2683749b96a0eca638f25ffe47eabf874cac
EXACT_PDF_INPUT_PIN gpu_vs_cpu_ops tex 5598 831ebdf6ac2cc2c8e7b0e9276e7e0f326f828d04b99bbe7c91aee6f1127ae12b
EXACT_PDF_INPUT_PIN gpu_vs_cpu_ops md 5347 59f0a0e95aab768e55633214986a2cb6eb257c99dd383bfdac8100b290b0d2ec
EXACT_PDF_INPUT_PIN security tex 1361 3b30d20da49c757d274b6b30501bb524ab448150301d0f153b3e2d60d31c019e
EXACT_PDF_INPUT_PIN security md 1050 b7ba5e0bd84756808ac3581a3a39f001e4aedf919bead0da1c35c6f2608d473e
EXACT_PDF_INPUT_PIN plain_datasets tex 1535 1667a75790194a9dc0fef7b36af3fc6cc5aeda22ac87b395ef19d82d9db7a6fe
EXACT_PDF_INPUT_PIN plain_datasets md 1279 0fa907d7b9d3d382e9ad7a169f4c68309f13be01e295e45b020dfb8125e6bd65
SOURCE_INDEX_PIN 266985 3c10eaeab8fd5575c6c2e6b5693c9cd5e1ab4202e2d5305675f07622b11147f9
LOG_COUNT 'Overfull' 0
LOG_COUNT 'Float too large' 0
LOG_COUNT 'undefined' 0
LOG_COUNT 'Missing character' 0
LOG_PDF_OUTPUT Output written on /Volumes/Untitled/ckks-train-storage/exports/2026-11-08-SYNTHETIC-r47-r48-r52-layout/build/main.pdf (11 pages, 525544 bytes).
VERDICT archive/docs consistency checks PASS; no tests or build run
```

## Limits

Only this ledger review file was written. No tests were repeated, no source changes/Git mutations/native/Rust/Cargo/SSH/server/GPU/HE operations occurred, and no PDF, image, generated table or actual result was produced or changed. Existing synthetic PDF/PNG were hashed, not visually reinspected here. Physical MicroSD identity was not independently re-established in this archive review; the recorded destination and its existing artifact bytes were verified.

This PASS covers packaging/doc consistency for the exact snapshot above. It does not prove historical execution or consumed scientific-input bytes, independently replay P48 checks, accept any measurement, satisfy R48-1, or complete Task54. Subsequent root additions/commit/publication are separate actions.

