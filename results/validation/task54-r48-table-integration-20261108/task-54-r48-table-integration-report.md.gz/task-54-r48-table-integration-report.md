# Bounded R48 table integration report

BASE3090d1e6c71e38e8efb8e713a0d265b9d788b522. Only the two owned Python files and this report are written.

## Test-first RED

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... FAIL
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... 
  test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=0) ... FAIL
  test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=3) ... FAIL
  test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=1) ... FAIL
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... FAIL
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... FAIL
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... FAIL
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... FAIL
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... 
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.written_by') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.git_commit') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.build.features.cuda') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.machine.host') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.finished_unix') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.gpu') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='setup.lr') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='setup.dims') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='setup.timed_iterations') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.hoist') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.closed_form_matches') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.counter_constant_over_iterations') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.counts_equal_hoist_on_counterpart') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.4.weights_bit_identical_to_hoist_on_counterpart') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.counter_per_iteration.key_switches') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.closed_form.rotations') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.step_s') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.step_s_median') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.step_time_over_default') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.iteration_s_median') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.log2_max_abs_weight_diff_vs_default') ... FAIL
  test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='protocol') ... FAIL
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... FAIL
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... FAIL
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... 
  test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='threads_cap') ... FAIL
  test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='hekit_synced_commit') ... FAIL
  test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='gpu_job') ... FAIL
  test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='state.json', key='rc') ... FAIL
  test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='state.json', key='output_sha256') ... FAIL
  test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='state.json', key='command') ... FAIL
  test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='start') ... FAIL
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... FAIL
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
FAIL: test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1007, in test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed
    with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=0)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 970, in test_r48_conditional_sgd_both_skip_and_failed_sgd_choices
    self.assertTrue(any('R-48-2' in n.text and 'capacity SKIP' in n.text for n in table.notes))
    ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: False is not true

======================================================================
FAIL: test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=3)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 969, in test_r48_conditional_sgd_both_skip_and_failed_sgd_choices
    if sgd_rc:self.assertIn('unmeasured',gpu[0][7])
              ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'unmeasured' not found in 'pending (R-48-2)'

======================================================================
FAIL: test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=1)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 969, in test_r48_conditional_sgd_both_skip_and_failed_sgd_choices
    if sgd_rc:self.assertIn('unmeasured',gpu[0][7])
              ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'unmeasured' not found in 'pending (R-48-2)'

======================================================================
FAIL: test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 986, in test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu
    with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1070, in test_r48_full_alias_same_original_and_both_entrypoints
    with self.assertRaises(tables.TableError):tables.table_ablation(store,tables.Inputs(store,'full'))
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 997, in test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured
    self.assertEqual(len(gpu),1);self.assertIn('failed/unmeasured',gpu[0][7])
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^
AssertionError: 8 != 1

======================================================================
FAIL: test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 948, in test_r48_registered_nag_pair_l31_context_and_sources
    self.assertIn('5 timed iterations',md);self.assertIn('3 timed iterations',md)
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: '5 timed iterations' not found in "# RQ3 ablation: one interactive eMLP-1 iteration under each EvalConfig\n\n<!-- generated by tools/paper_tables.py from synthetic/; do not edit -->\n\n| Source | Backend / level | hoist bsgs lazy | Rotations | Relins | KS/iter | Closed form | Step median (s) | Step / default | Max \\|ΔW\\| vs default |\n|---|---|---|---|---|---|---|---|---|---|\n| CPU, n16_train, level 31 | cpu, level max | 1 1 1 | 571 | 62 | 633 | match | 1.000 | 1.000 | 0 |\n| CPU, n16_train, level 31 | cpu, level max | 1 1 0 | 571 | 114 | 685 | match | 1.100 | 1.100 | 7.83e-09 |\n| CPU, n16_train, level 31 | cpu, level max | 1 0 1 | 610 | 101 | 711 | match | 1.200 | 1.200 | 6.90e-09 |\n| CPU, n16_train, level 31 | cpu, level max | 1 0 0 | 610 | 114 | 724 | match | 1.300 | 1.300 | 7.39e-09 |\n| CPU, n16_train, level 31 | cpu, level max | 0 1 1 | 571 | 62 | 633 | match | 1.400 | 1.400 | 0 |\n| CPU, n16_train, level 31 | cpu, level max | 0 1 0 | 571 | 114 | 685 | match | 1.500 | 1.500 | 7.83e-09 |\n| CPU, n16_train, level 31 | cpu, level max | 0 0 1 | 610 | 101 | 711 | match | 1.600 | 1.600 | 6.90e-09 |\n| CPU, n16_train, level 31 | cpu, level max | 0 0 0 | 610 | 114 | 724 | match | 1.700 | 1.700 | 7.39e-09 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 1 1 1 | 571 | 62 | 633 | match | 1.000 | 1.000 | 0 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 1 1 0 | 571 | 114 | 685 | match | 1.100 | 1.100 | 7.83e-09 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 1 0 1 | 610 | 101 | 711 | match | 1.200 | 1.200 | 6.90e-09 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 1 0 0 | 610 | 114 | 724 | match | 1.300 | 1.300 | 7.39e-09 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 0 1 1 | 571 | 62 | 633 | match | 1.400 | 1.400 | 0 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 0 1 0 | 571 | 114 | 685 | match | 1.500 | 1.500 | 7.83e-09 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 0 0 1 | 610 | 101 | 711 | match | 1.600 | 1.600 | 6.90e-09 |\n| GPU, n16_train, level 7 | SYNTHETIC GPU, level 7 | 0 0 0 | 610 | 114 | 724 | match | 1.700 | 1.700 | 7.39e-09 |\n| CPU, n16_train, level 7 | cpu, level 7 | 1 1 1 | 571 | 62 | 633 | match | 1.000 | 1.000 | 0 |\n| CPU, n16_train, level 7 | cpu, level 7 | 1 1 0 | 571 | 114 | 685 | match | 1.100 | 1.100 | 7.83e-09 |\n| CPU, n16_train, level 7 | cpu, level 7 | 1 0 1 | 610 | 101 | 711 | match | 1.200 | 1.200 | 6.90e-09 |\n| CPU, n16_train, level 7 | cpu, level 7 | 1 0 0 | 610 | 114 | 724 | match | 1.300 | 1.300 | 7.39e-09 |\n| CPU, n16_train, level 7 | cpu, level 7 | 0 1 1 | 571 | 62 | 633 | match | 1.400 | 1.400 | 0 |\n| CPU, n16_train, level 7 | cpu, level 7 | 0 1 0 | 571 | 114 | 685 | match | 1.500 | 1.500 | 7.83e-09 |\n| CPU, n16_train, level 7 | cpu, level 7 | 0 0 1 | 610 | 101 | 711 | match | 1.600 | 1.600 | 6.90e-09 |\n| CPU, n16_train, level 7 | cpu, level 7 | 0 0 0 | 610 | 114 | 724 | match | 1.700 | 1.700 | 7.39e-09 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 1 1 1 | 171 | 62 | 233 | match | n/a (smoke) | n/a (smoke) | 0 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 1 1 0 | 171 | 114 | 285 | match | n/a (smoke) | n/a (smoke) | 7.83e-09 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 1 0 1 | 210 | 101 | 311 | match | n/a (smoke) | n/a (smoke) | 6.90e-09 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 1 0 0 | 210 | 114 | 324 | match | n/a (smoke) | n/a (smoke) | 7.39e-09 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 0 1 1 | 171 | 62 | 233 | match | n/a (smoke) | n/a (smoke) | 0 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 0 1 0 | 171 | 114 | 285 | match | n/a (smoke) | n/a (smoke) | 7.83e-09 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 0 0 1 | 210 | 101 | 311 | match | n/a (smoke) | n/a (smoke) | 6.90e-09 |\n| CPU smoke (insecure N = 2^12: counts only) | cpu, level max | 0 0 0 | 210 | 114 | 324 | match | n/a (smoke) | n/a (smoke) | 7.39e-09 |\n\n- CPU, n16_train, level 31: optimizer nag, B = 32, layout d = 1024, start level 31. Rows with unlike conditions are not a CPU/GPU speed comparison.\n- GPU, n16_train, level 7: optimizer nag, B = 32, layout d = 1024, start level 7. Rows with unlike conditions are not a CPU/GPU speed comparison.\n- CPU, n16_train, level 7: optimizer nag, B = 32, layout d = 1024, start level 7. Rows with unlike conditions are not a CPU/GPU speed comparison.\n- CPU smoke: optimizer nag, B = 2, layout d = 1024, start level 10. Rows with unlike conditions are not a CPU/GPU speed comparison.\n- 1. **Definition of `bsgs = false`.** The giant rotation is not shared; the weights keep the same pre-rotated (BSGS) layout and the same Galois keys. Every product with a nonzero giant shift is finished (relinearized) and rotated on its own; the products of the zero-shift block are summed as with BSGS. Per matvec of dimension `d` (offset 0): `d - 1` rotations, of which only the `baby - 1` rotations of `x` can be hoisted; with `lazy_relin` `1 + d - baby` relins, without it `d` ([`EvalConfig::matvec_rotations`], [`EvalConfig::matvec_enc_relins`]). At `d = 16` (`baby = giant = 4`), as (hoistable rotations / individual rotations / relins): \\| form \\| hoistable rot. \\| individual rot. \\| relins (lazy) \\| relins (not lazy) \\| \\|---\\|---\\|---\\|---\\|---\\| \\| default BSGS \\| 3 \\| 3 \\| 4 \\| 16 \\| \\| `bsgs = false` (this library) \\| 3 \\| 12 \\| 13 \\| 16 \\| \\| textbook diagonal method (not implemented) \\| 15 \\| 0 \\| 1 \\| 16 \\| The textbook (Halevi-Shoup) diagonal method rotates `x` by all `d - 1` steps (all hoistable) and sums the products lazily; it needs un-pre-rotated diagonals, i.e. another weight layout and gradient form, so it is not implemented. The all-off configuration has the same counts in both forms (15 rotations, 16 relins at `d = 16`).\n- 2. **Bias.** Against the strongest naive baseline (the textbook method with hoisting and lazy relinearization), the cost of the `bsgs = false` rows overstates what BSGS gains: the measured BSGS gain is an **upper bound**. Conversely, the marginal gains of `hoist` and `lazy_relin` measured inside `bsgs = false` configurations are **lower bounds** (only `baby - 1` rotations can be hoisted and only the zero-shift block summed lazily: e.g. `lazy_relin` saves 3 relins at `d = 16` instead of 15).\n- 3. **`hoist` changes no [`OpCounter`] value.** The counter does not distinguish hoisted from individual rotations, so the effect of `hoist` shows only in wall-clock time, never in key-switch counts.\n- 4. **`bsgs` does not touch the gradient's outer product** (`Dense::weight_grad_scaled`, `Dense::weight_grad_reduced`): its `(baby - 1) + (giant - 1)` input rotations are what the pre-rotated weight layout requires, not a BSGS choice; only `hoist` changes how they run. The interactive gradient multiplies each diagonal with one [`Evaluator::mul`] (nothing to sum lazily), so `lazy_relin` does not change it either.\n- The smoke rows (insecure N = 2^12, high Mac load) check counts and closed forms only; their times are not comparative.\n"

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.written_by')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.git_commit')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.build.features.cuda')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.machine.host')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.finished_unix')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='provenance.gpu')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='setup.lr')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='setup.dims')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='setup.timed_iterations')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.hoist')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.closed_form_matches')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.counter_constant_over_iterations')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.counts_equal_hoist_on_counterpart')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.4.weights_bit_identical_to_hoist_on_counterpart')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.counter_per_iteration.key_switches')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.closed_form.rotations')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.step_s')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.step_s_median')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.step_time_over_default')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.iteration_s_median')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='configs.0.log2_max_abs_weight_diff_vs_default')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) (field='protocol')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1045, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                   ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1048, in test_r48_rejects_bad_binary_flags_counts_stats_and_protocol
    with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1056, in test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times
    self.assertEqual(len(gpu),1);self.assertIn('invalid-workload/unmeasured',gpu[0][7])
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^
AssertionError: 8 != 1

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='threads_cap')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1021, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='hekit_synced_commit')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1021, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='gpu_job')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1021, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='state.json', key='rc')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1021, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='state.json', key='output_sha256')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1021, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='state.json', key='command')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1021, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) (name='meta.json', key='start')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1021, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
                                         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1024, in test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs
    self.assertEqual(tables.main(['--root',str(self.root)]),2)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2

----------------------------------------------------------------------
Ran 48 tests in 5.197s

FAILED (failures=40)
```

## Exact post-SGD branch / original SKIP line RED

Source line383 uses rc3 plus raw skip even if another status (e.g. watchdog) takes precedence. NAG triggering still requires status skipped at line380.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... ok
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... 
  test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=3) ... ERROR
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... ok
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... ok
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... ok
test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending) ... FAIL
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... ok
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... ok
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... ok
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
ERROR: test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) (sgd_rc=3)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 967, in test_r48_conditional_sgd_both_skip_and_failed_sgd_choices
    table=self.build(tables.table_ablation)
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 303, in build
    return fn(store, tables.Inputs(store))
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 1131, in table_ablation
    registered = r48_inputs(s, inp)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 880, in r48_inputs
    return read_r48_inputs(s, inp)
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 1015, in read_r48_inputs
    check(optimizer is None or expected_opt is None or optimizer == expected_opt, 'optimizer record contradicts present preceding jobs')
    ~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 910, in check
    require(ok, 'R48: ' + message)
    ~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^
  File "/Users/marconi/Documents/research/hekit/tools/paper_tables.py", line 53, in require
    raise TableError(message)
paper_tables.TableError: R48: optimizer record contradicts present preceding jobs

======================================================================
FAIL: test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1000, in test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending
    self.assertIn('R-48/R-48-2/program.log\tline 1',source)
    ~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 'R-48/R-48-2/program.log\tline 1' not found in 'rq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tjob\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\thost\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tworkdir\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tcommand\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\thekit_synced_commit\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tnice\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tthreads_cap\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tenv_thread_caps\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tgpu_job\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tstart\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\tend\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\twall_s_runner\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\texit_status\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/meta.json\twatchdog_killed\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\trc\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\twrapper_rc\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\tstatus\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\tskip\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\tskip_lines\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\tcommand\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\tworkdir\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/state.json\tlog\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/post.txt\tline 2\t\nrq3_ablation\tGPU, n16_train, level 7\tSource\tGPU, n16_train, level 7\tresults/quadruped/raw/R-48/R-48-2/cmd.txt\tline 1\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tjob\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\thost\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tworkdir\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tcommand\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\thekit_synced_commit\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tnice\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tthreads_cap\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tenv_thread_caps\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tgpu_job\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tstart\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\tend\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\twall_s_runner\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\texit_status\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/meta.json\twatchdog_killed\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\trc\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\twrapper_rc\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\tstatus\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\tskip\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\tskip_lines\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\tcommand\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\tworkdir\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/state.json\tlog\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/post.txt\tline 2\t\nrq3_ablation\tGPU, n16_train, level 7\tStep median (s)\tcapacity SKIP/unmeasured\tresults/quadruped/raw/R-48/R-48-2/cmd.txt\tline 1\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t1 1 1\tresults/ablation_cpu_smoke_small.json\tconfigs[0].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t171\tresults/ablation_cpu_smoke_small.json\tconfigs[0].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t62\tresults/ablation_cpu_smoke_small.json\tconfigs[0].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t233\tresults/ablation_cpu_smoke_small.json\tconfigs[0].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[0].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[0].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[0].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t0\tresults/ablation_cpu_smoke_small.json\tconfigs[0].max_abs_weight_diff_vs_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t1 1 0\tresults/ablation_cpu_smoke_small.json\tconfigs[1].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t171\tresults/ablation_cpu_smoke_small.json\tconfigs[1].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t114\tresults/ablation_cpu_smoke_small.json\tconfigs[1].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t285\tresults/ablation_cpu_smoke_small.json\tconfigs[1].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[1].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[1].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[1].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t7.83e-09\tresults/ablation_cpu_smoke_small.json\tconfigs[1].max_abs_weight_diff_vs_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t1 0 1\tresults/ablation_cpu_smoke_small.json\tconfigs[2].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t210\tresults/ablation_cpu_smoke_small.json\tconfigs[2].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t101\tresults/ablation_cpu_smoke_small.json\tconfigs[2].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t311\tresults/ablation_cpu_smoke_small.json\tconfigs[2].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[2].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[2].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[2].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t6.90e-09\tresults/ablation_cpu_smoke_small.json\tconfigs[2].max_abs_weight_diff_vs_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t1 0 0\tresults/ablation_cpu_smoke_small.json\tconfigs[3].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t210\tresults/ablation_cpu_smoke_small.json\tconfigs[3].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t114\tresults/ablation_cpu_smoke_small.json\tconfigs[3].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t324\tresults/ablation_cpu_smoke_small.json\tconfigs[3].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[3].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[3].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[3].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t7.39e-09\tresults/ablation_cpu_smoke_small.json\tconfigs[3].max_abs_weight_diff_vs_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t0 1 1\tresults/ablation_cpu_smoke_small.json\tconfigs[4].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t171\tresults/ablation_cpu_smoke_small.json\tconfigs[4].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t62\tresults/ablation_cpu_smoke_small.json\tconfigs[4].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t233\tresults/ablation_cpu_smoke_small.json\tconfigs[4].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[4].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[4].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[4].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t0\tresults/ablation_cpu_smoke_small.json\tconfigs[4].max_abs_weight_diff_vs_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t0 1 0\tresults/ablation_cpu_smoke_small.json\tconfigs[5].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t171\tresults/ablation_cpu_smoke_small.json\tconfigs[5].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t114\tresults/ablation_cpu_smoke_small.json\tconfigs[5].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t285\tresults/ablation_cpu_smoke_small.json\tconfigs[5].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[5].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[5].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[5].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t7.83e-09\tresults/ablation_cpu_smoke_small.json\tconfigs[5].max_abs_weight_diff_vs_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t0 0 1\tresults/ablation_cpu_smoke_small.json\tconfigs[6].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t210\tresults/ablation_cpu_smoke_small.json\tconfigs[6].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t101\tresults/ablation_cpu_smoke_small.json\tconfigs[6].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t311\tresults/ablation_cpu_smoke_small.json\tconfigs[6].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[6].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[6].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[6].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t6.90e-09\tresults/ablation_cpu_smoke_small.json\tconfigs[6].max_abs_weight_diff_vs_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tSource\tCPU smoke (insecure N = 2^12: counts only)\tresults/ablation_cpu_smoke_small.json\tsetup.params\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.device\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tBackend / level\tcpu, level max\tresults/ablation_cpu_smoke_small.json\tbackend.options.top_level\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\thoist bsgs lazy\t0 0 0\tresults/ablation_cpu_smoke_small.json\tconfigs[7].config\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRotations\t210\tresults/ablation_cpu_smoke_small.json\tconfigs[7].counter_per_iteration.rotations\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tRelins\t114\tresults/ablation_cpu_smoke_small.json\tconfigs[7].counter_per_iteration.relins\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tKS/iter\t324\tresults/ablation_cpu_smoke_small.json\tconfigs[7].counter_per_iteration.key_switches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tClosed form\tmatch\tresults/ablation_cpu_smoke_small.json\tconfigs[7].closed_form_matches\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep median (s)\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[7].step_s_median\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tStep / default\tn/a (smoke)\tresults/ablation_cpu_smoke_small.json\tconfigs[7].step_time_over_default\t\nrq3_ablation\tCPU smoke (insecure N = 2^12: counts only)\tMax |ΔW| vs default\t7.39e-09\tresults/ablation_cpu_smoke_small.json\tconfigs[7].max_abs_weight_diff_vs_default\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tjob\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\thost\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tworkdir\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tcommand\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\thekit_synced_commit\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tnice\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tthreads_cap\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tenv_thread_caps\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tgpu_job\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tstart\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\tend\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\twall_s_runner\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\texit_status\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/meta.json\twatchdog_killed\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\trc\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\twrapper_rc\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\tstatus\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\tskip\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\tskip_lines\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\tcommand\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\tworkdir\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/state.json\tlog\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/post.txt\tline 2\t\nrq3_ablation\tnote 1\t\t\tresults/quadruped/raw/R-48/R-48-2/cmd.txt\tline 1\t\nrq3_ablation\tnote 2\t\t\tresults/ablation_cpu_smoke_small.json\tsetup.optimizer\t\nrq3_ablation\tnote 2\t\t\tresults/ablation_cpu_smoke_small.json\tsetup.lanes_b\t\nrq3_ablation\tnote 2\t\t\tresults/ablation_cpu_smoke_small.json\tsetup.layout_d\t\nrq3_ablation\tnote 2\t\t\tresults/ablation_cpu_smoke_small.json\tsetup.start_level\t\nrq3_ablation\tnote 3\t\t\tresults/ablation_cpu_smoke_small.json\tcaveats[0]\t\nrq3_ablation\tnote 4\t\t\tresults/ablation_cpu_smoke_small.json\tcaveats[1]\t\nrq3_ablation\tnote 5\t\t\tresults/ablation_cpu_smoke_small.json\tcaveats[2]\t\nrq3_ablation\tnote 6\t\t\tresults/ablation_cpu_smoke_small.json\tcaveats[3]\t'

----------------------------------------------------------------------
Ran 49 tests in 5.384s

FAILED (failures=1, errors=1)
```

## Actual P48 capacity diagnostic RED

Pinned main() prefixes the error with ablation:, so capacity fixtures were made exact to that printed form before validating actual capacity evidence. Queue skip substring alone is insufficient to invent producer capacity evidence.

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout:
```text
```

stderr:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... ok
test_r48_capacity_skip_requires_the_actual_producer_marker (test_paper_tables.PaperTablesTests.test_r48_capacity_skip_requires_the_actual_producer_marker) ... FAIL
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... ok
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... ok
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... ok
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... ok
test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending) ... ok
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... ok
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... ok
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... ok
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
FAIL: test_r48_capacity_skip_requires_the_actual_producer_marker (test_paper_tables.PaperTablesTests.test_r48_capacity_skip_requires_the_actual_producer_marker)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1034, in test_r48_capacity_skip_requires_the_actual_producer_marker
    with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

----------------------------------------------------------------------
Ran 50 tests in 5.453s

FAILED (failures=1)
```

## Final bounded behavior / decisions

Only `tools/paper_tables.py`, `tools/test_paper_tables.py` and this report were written. Original BASE3090d1e6c71e38e8efb8e713a0d265b9d788b522 remains the diff baseline; subsequent root observation/documentation commits do not change that ownership. No Git mutation, Rust/Cargo/native/SSH/GPU/HE/subagent work, real scientific-result JSON, or generated repository table writes occurred.

### Original terminal and binary intake

Canonical binary names remain unchanged. The five unchanged original files per ablation job use the adopted raw/R-48/J archive paths; original R-48-optimizer.json is read from raw/R-48/. All absent remains the exact existing pending output. Any partial/malformed five-file evidence is rejected. Child/post/meta/state matching, full P48 pin and clean marker, exact command/workdir, CPU/GPU flag, nice10/thread12, aware/coherent runner times, and separate wrapper status are checked. Coherent failed/watchdog/output-validation failures become failed/unmeasured without accepting saved/printed timings. Success requires exact original state.output_sha256 over selected raw binary bytes, the matching original binary writer/provenance/build/host/thread/time/GPU facts and registered P48 schema. Full aliases need the same original association and byte identity; quick mode remains separate. An unselected GPU-SGD archive or conflicting CPU output cannot silently become a historical substitute.

CPU ablation correctly accepts the actual CUDA-feature/parallel Linux release build, package0.0.0, with binary provenance.gpu=null and backend.device=cpu. GPU members require actual named GPU/free/total provenance consistent with their device description. Recorded GPU memory facts/estimates do not become peak-memory claims.

### Exact conditional selection and standalone CPU ruling

Root's before-edit ruling task-54-r48-standalone-cpu-ruling.md SHA06756d949c8c16891b462fb5c72007a4c218486b2da90a8e0eb68c83c5b48a44 is implemented narrowly: an original optimizer record plus CPU job/command/binary may establish that CPU member with unseen GPU members still pending. Missing/malformed optimizer records cannot establish an observed CPU L7 job. Every present predecessor must agree, and no unseen GPU trajectory/comparison is inferred.

Both actual capacity-SKIP attempts retain their own source evidence: the NAG R-48-2 job, and conditional R-48-2-sgd. The actual P48 main prefixes its capacity diagnostic `ablation: SKIP ablation: needs ... MiB of GPU memory ({...}), only ... MiB free; GPU run unmeasured`. The consumer verifies this producer-shaped diagnostic (including finite estimate fields) rather than inventing capacity SKIP from a generic substring or missing JSON. Matching original log lines and state skip fields remain attributed. A no-usable-CUDA-device error is ordinary failure; the source's capacity branch alone uses the SKIP prefix/exit3.

The deployed queue lines380-383 have deliberately different branch conditions: NAG triggers the conditional SGD job only on rc3 + actual SKIP + status skipped. After SGD, CPU optimizer is NAG on SGD rc3 + raw skip, without another status condition; otherwise it is SGD even if that attempt failed. An additional RED caught and corrected this distinction for a watchdog-marked SGD rc3/SKIP record. Ordinary NAG OOM/rc1 never selects SGD. Both skipped→CPU NAG; failed SGD→CPU SGD; preceding GPU failure is retained without demanding later optimizer/CPU evidence. Absence alone remains pending, and unselected SGD is not called an attempted failure.

### Accepted-grid and workload conditions

P48 n16_train/L7 or separate CPU L31, default seed48/B32/hidden32/lr0.001/momentum0.9/dims784→32→10/layoutd1024/reuse options, one warmup and 5 L7 or 3 L31 timed iterations, exact pinned protocol and four verbatim caveats are checked. Eight unique boolean triples/config labels, actual per-row success flags, nonnegative integer counters, KS=rotations+relins, zero interactive bootstraps, hoist counterpart checks, relative closed-form agreement, finite positive step samples, declared median/default/all-off ratios, iteration=sum(step median,refresh median), and legitimate zero error/null log2 are validated. No un-emitted refresh sample list is demanded.

The registered relative count deltas are traced to P48 ops.rs/linalg.rs: for matvec dims32,16,16, bsgs_split gives (8,4),(4,4),(4,4); bsgs-off adds39 rotations, lazy-off adds52 relins, and bsgs-off/lazy-on adds39 relins relative to default. Absolute default counts remain the producer's measured baseline plus its actual reported checks; this consumer does not independently execute the structural predictor or HE.

The real-MNIST note must be exactly `MNIST training images (first in file order)`. The producer's actual `synthetic uniform pixels (MNIST IDX files not found)` fallback is retained as an original invalid-workload/unmeasured diagnostic, with no accepted timings; it is not relabeled real-MNIST training. Unknown notes or contradictory fields are errors. These are producer-written workload labels, not independent historical input-byte hashes; source/terminal validation cannot prove which historical IDX bytes were consumed.

With two accepted L7 members, matching params/level/optimizer/dimensions/layout/batch/seed/lr/momentum/data/repetition conditions are checked; exact protocol validation also fixes their timing definition. One accepted member does not manufacture its counterpart. No new CPU/GPU or literature ratio is computed. Within-config Step/default remains the original same-run producer ratio. Context notes preserve actual seed/repetitions/threads/start/end/load and original binary digest with field attribution, four caveats, and smoke counts-only suppression. No independent-seed SD, GPU peak, NI bootstrap or end-to-end training performance conclusion is claimed.

## Final GREEN / check-only / diffcheck transcripts

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... ok
test_r48_capacity_skip_requires_the_actual_producer_marker (test_paper_tables.PaperTablesTests.test_r48_capacity_skip_requires_the_actual_producer_marker) ... ok
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... ok
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... ok
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... ok
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... ok
test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending) ... ok
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... ok
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... ok
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... ok
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 50 tests in 5.574s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `git diff --check 3090d1e6c71e38e8efb8e713a0d265b9d788b522 -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

## Adopted R47/R52 source preservation

- `r47_batch_input`: exact function source unchanged from adopted BASE.
- `table_gpu`: exact function source unchanged from adopted BASE.
- `r52_input`: exact function source unchanged from adopted BASE.
- `read_r52_input`: exact function source unchanged from adopted BASE.
- `table_accuracy`: exact function source unchanged from adopted BASE.
- `source_lines`: exact function source unchanged from adopted BASE.
- `render_md`: exact function source unchanged from adopted BASE.
- `render_tex`: exact function source unchanged from adopted BASE.

Both current real-root --check commands pass with R48 outputs absent, establishing byte-identical current generated files without writing them. All 38 adopted test methods remain green alongside 12 R48 methods (50 total, with many negative/branch subcases).

## Exact pinned/current source hashes

- `git show 0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-bench/src/bin/ablation.rs`: SHA256 `2baf83ef4a04ed000b05f5228328bc6da424e8a6c8221ebeb32c96b72f9ae137` (32081 bytes).
- `git show 0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-bench/src/backend.rs`: SHA256 `cafdcebb6fa4e54e4220cc096c7528cd3c53db78c0a34c22f3d066ba0b1ceaf5` (24543 bytes).
- `git show 0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-bench/src/provenance.rs`: SHA256 `4d519fec381e63141185ba87aa1638f12d18698fb91f6285555d8f546c65820b` (6686 bytes).
- `git show 0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-ckks/src/ops.rs`: SHA256 `54df0f262234de512bb69642ac3502cbb2497381f163330062f589d9bdf7cf6e` (31115 bytes).
- `git show 0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-ckks/src/linalg.rs`: SHA256 `35ede5597a706bdcd3d23601594ff280efceaf10ed3ebcbb01b5e66171f8c2e4` (69024 bytes).

Pinned-source extraction independently confirms the exact four-caveat compact JSON SHA256 b793ad497f7b900a463c189066e258bda57a7a5081f7104584408091fde72a92 and protocol string SHA256 564663f4a3e29dc607b01a9734627389a5e5f01227426d50c9a8df19df34999f. These constants are finite project-producer text identities, not copied external baseline code or performance evidence.
- Current local source `results/quadruped/scripts/post_full_queue.py`: SHA256 `1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9` (23840 bytes).
- Current local source `results/quadruped/scripts/run_job.sh`: SHA256 `46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736` (4998 bytes).
- Current local source `docs/post-full-queue.md`: SHA256 `4db7e2c0aa00be375a8eff9b9f2c2aabb7801766ca515e71de297e6d47566340` (25164 bytes).
- Current local source `docs/m4-report.md`: SHA256 `b270d88647819ad841d6082e3e5df00761e9509221ae7f90ae80dac5ced37ece` (40347 bytes).
- Current local source `docs/m5-report.md`: SHA256 `911f7b0f9f1c79d4723bff4d207c0126e9b23f2e945da3af64f71ee8f649dc97` (176770 bytes).
- Current local source `.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-table-integration-brief.md`: SHA256 `00f0425fc0e2a50aaf156a2de35a6d5175bb68db577e74981281cdebbb14e6d6` (5676 bytes).
- Current local source `.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-standalone-cpu-ruling.md`: SHA256 `06756d949c8c16891b462fb5c72007a4c218486b2da90a8e0eb68c83c5b48a44` (1812 bytes).

## Owned final hashes and exact diff against original BASE

- `tools/paper_tables.py`: BASE SHA256 `2eb7f241d0bc6302ad5d1892ab3bb1980120d92787c76cf70f0c15fef85da1c1`; final SHA256 `f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0`.
- `tools/test_paper_tables.py`: BASE SHA256 `8cf932dd06c41c3405c62db2361ef78ece5ae649b41cfe3c72c2b62130d345c5`; final SHA256 `73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0`.

Command: `git diff 3090d1e6c71e38e8efb8e713a0d265b9d788b522 -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```diff
diff --git a/tools/paper_tables.py b/tools/paper_tables.py
index 0fb179b..fcf2bf8 100644
--- a/tools/paper_tables.py
+++ b/tools/paper_tables.py
@@ -867,24 +867,328 @@ def table_accuracy(s, inp):
     return t
 
 
+R48_PIN = '0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3'
+R48_WORKDIR = '/home/kmihara/hekit-post-full-clones/hekit-post-full-r48'
+# Digests of the exact project P48 ablation.rs protocol and four verbatim caveats.
+R48_PROTOCOL_SHA = '564663f4a3e29dc607b01a9734627389a5e5f01227426d50c9a8df19df34999f'
+R48_CAVEATS_SHA = 'b793ad497f7b900a463c189066e258bda57a7a5081f7104584408091fde72a92'
+
+
+def r48_inputs(s, inp):
+    """Finite deployed P48 job selection; original runner records never replace binary JSON."""
+    try:
+        return read_r48_inputs(s, inp)
+    except TableError:
+        raise
+    except (OSError, UnicodeError, ValueError, TypeError, KeyError, IndexError, OverflowError,
+            rq1.SummaryError) as exc:
+        raise TableError(f'R48: invalid original evidence: {exc}') from exc
+
+
+def read_r48_inputs(s, inp):
+    if inp.run_all == 'quick':
+        return {}
+    root = 'results/quadruped/raw/R-48'
+    present = lambda rel: (s.root / rel).exists() or (s.root / rel).is_symlink()
+    raw = {}
+
+    def read(rel):
+        if rel not in raw:
+            raw[rel] = (s.root / rel).read_bytes()
+        return raw[rel]
+
+    def text(rel):
+        return read(rel).decode('utf-8')
+
+    def doc(rel):
+        d = json.loads(read(rel), object_pairs_hook=rq1.unique_object)
+        rq1.finite_tree(d)
+        require(isinstance(d, dict), f'{rel}: expected original object')
+        return d
+
+    def check(ok, message):
+        require(ok, 'R48: ' + message)
+
+    def num(value, name, integer=False, minimum=0):
+        check(type(value) is int if integer else type(value) in (int, float), name + ': wrong number type')
+        check(math.isfinite(value) and value >= minimum, name + ': nonfinite/out of range')
+        return value
+
+    def same(a, b, name):
+        num(a, name)
+        check(math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-9), name + ': inconsistent value')
+
+    def stamp(value):
+        check(isinstance(value, str) and re.fullmatch(
+            r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}', value), 'timezone-qualified runner time required')
+        return datetime.fromisoformat(value).timestamp()
+
+    def argv(value):
+        check(isinstance(value, str), 'missing command')
+        return shlex.split(value)
+
+    opt_rel = root + '/R-48-optimizer.json'
+    optimizer = None
+    if present(opt_rel):
+        d = doc(opt_rel)
+        check(set(d) == {'cpu_optimizer'} and d['cpu_optimizer'] in ('nag', 'sgd'), 'malformed original optimizer selection')
+        optimizer = d['cpu_optimizer']
+
+    def canonical(job, opt):
+        stem = ('ablation_cuda' + ('_sgd' if job.endswith('-sgd') else '') if job.startswith('R-48-2') else
+                'ablation_cpu' if job == 'R-48-4' else 'ablation_cpu_l7' + ('_sgd' if opt == 'sgd' else ''))
+        return 'results/quadruped/' + stem + '.json'
+
+    def observed(job, candidates=()):
+        return any(present(f'{root}/{job}/{name}') for name in ('program.log', 'meta.json', 'post.txt', 'cmd.txt', 'state.json')) or any(present(p) for p in candidates)
+
+    cpu_candidates = RUN['ABL-CPU-L7'][0]
+    cpu_alias = f'results/run_all/{inp.run_all}/ablation_cpu_l7.json' if inp.run_all else ''
+    cpu_seen = observed('R-48-3', cpu_candidates) or bool(cpu_alias and present(cpu_alias))
+    check(not cpu_seen or optimizer is not None, 'CPU level7 job requires original optimizer record')
+
+    def job(name, opt):
+        canon = canonical(name, opt)
+        if not observed(name, [canon]):
+            return None
+        paths = [f'{root}/{name}/{part}' for part in ('program.log', 'meta.json', 'post.txt', 'cmd.txt', 'state.json')]
+        check(all(present(p) for p in paths), name + ': incomplete original terminal evidence')
+        log_rel, meta_rel, post_rel, cmd_rel, state_rel = paths
+        log, meta, post, state = text(log_rel), doc(meta_rel), text(post_rel).splitlines(), doc(state_rel)
+        gpu, full = name.startswith('R-48-2'), name == 'R-48-4'
+        command = ['target/release/ablation', '--backend', 'cuda' if gpu else 'cpu', '--params', 'n16_train',
+                   *([] if full else ['--top-level', '7']), '--optimizer', opt, '--iters', '3' if full else '5',
+                   '--warmup', '1', '--data', R48_WORKDIR + '/data/mnist', '--out', canon]
+        check(meta.get('job') == state.get('job') == name and
+              meta.get('workdir') == state.get('workdir') == R48_WORKDIR, name + ': wrong job/workdir')
+        check(meta.get('hekit_synced_commit') == ['commit 0e07561', 'full ' + R48_PIN, 'dirty_files 0'], name + ': wrong pin/clean marker')
+        check(argv(meta.get('command')) == argv(text(cmd_rel)) == command and state.get('command') == command, name + ': wrong argv')
+        check(type(meta.get('nice')) is int and meta['nice'] == 10 and type(meta.get('threads_cap')) is int and
+              meta['threads_cap'] == 12 and meta.get('gpu_job') is gpu and meta.get('env_thread_caps') ==
+              {k: '12' for k in ('OMP_NUM_THREADS', 'RAYON_NUM_THREADS', 'CARGO_BUILD_JOBS')}, name + ': wrong runner limits')
+        start, end = stamp(meta.get('start')), stamp(meta.get('end'))
+        wall = num(meta.get('wall_s_runner'), 'runner wall')
+        check(end >= start and abs(wall - (end - start)) <= 2, name + ': incoherent runner time')
+        terminal = [(i, line) for i, line in enumerate(post, 1) if line.startswith('JOB_DONE')]
+        check(len(terminal) == 1 and terminal[0][0] == len(post), name + ': missing/duplicate/nonterminal JOB_DONE')
+        done = re.fullmatch(r'JOB_DONE rc=(\d+)', terminal[0][1])
+        check(done is not None, name + ': malformed JOB_DONE')
+        rc = num(meta.get('exit_status'), 'child exit', True)
+        check(rc <= 255 and type(state.get('rc')) is int and state['rc'] == rc == int(done[1]), name + ': child exit mismatch')
+        check(num(state.get('wrapper_rc'), 'separate wrapper exit', True) <= 255, name + ': wrong wrapper status')
+        check(type(meta.get('watchdog_killed')) is bool and post[0].startswith('date: ') and
+              stamp(post[0][6:]) >= end, name + ': invalid watchdog/post date')
+        watchdog = meta['watchdog_killed']
+        check(watchdog or not any(line.startswith('WATCHDOG:') for line in log.splitlines()), name + ': watchdog contradiction')
+        skips = [line for line in log.splitlines() if 'SKIP' in line]
+        check(state.get('skip') is bool(skips) and state.get('skip_lines') == skips and
+              state.get('log') == f'/home/kmihara/hekit-runs/logs/{name}.log', name + ': inconsistent original log/skip')
+        expected = ('failed: RSS watchdog' if watchdog else
+                    'failed: device OOM' if rc and re.search(r'device error|out of memory', log, re.I) else
+                    'skipped' if rc == 3 and skips else 'failed' if rc else 'done_with_skips' if skips else 'done')
+        rejected = state.get('status') == 'failed: output checks/provenance'
+        if rejected:
+            check(rc == 0 and isinstance(state.get('output_error'), str) and state['output_error'].strip() and
+                  'output_sha256' not in state, name + ': incoherent queue output rejection')
+        else:
+            check(state.get('status') == expected, name + ': contradictory queue outcome')
+        if gpu and rc == 3 and skips:
+            capacity = [re.fullmatch(r'ablation: SKIP ablation: needs ([0-9]+\.[0-9]) MiB of GPU memory '
+                                    r'\((\{.*\})\), only ([0-9]+\.[0-9]) MiB free; GPU run unmeasured', line)
+                        for line in skips]
+            check(len(capacity) == 1 and capacity[0] is not None, name + ': missing actual capacity SKIP diagnostic')
+            estimate = json.loads(capacity[0][2], object_pairs_hook=rq1.unique_object)
+            check(isinstance(estimate, dict) and set(estimate) ==
+                  {'total_mib', 'keys_mib', 'tables_mib', 'state_mib', 'work_mib'}, name + ': malformed capacity estimate')
+            for value in estimate.values():
+                num(value, 'capacity estimate')
+            same(float(capacity[0][1]), estimate['total_mib'], 'capacity diagnostic total')
+            num(float(capacity[0][3]), 'capacity diagnostic available memory')
+        skipped = gpu and rc == 3 and bool(skips) and state['status'] == 'skipped'
+        sources = [(meta_rel, field) for field in ('job', 'host', 'workdir', 'command', 'hekit_synced_commit', 'nice',
+                   'threads_cap', 'env_thread_caps', 'gpu_job', 'start', 'end', 'wall_s_runner', 'exit_status', 'watchdog_killed')]
+        sources += [(state_rel, field) for field in ('rc', 'wrapper_rc', 'status', 'skip', 'skip_lines', 'command', 'workdir', 'log')]
+        sources += [(post_rel, f'line {terminal[0][0]}'), (cmd_rel, 'line 1')]
+        sources += [(log_rel, f'line {i}') for i, line in enumerate(log.splitlines(), 1)
+                    if re.search(r'SKIP|WATCHDOG:|device error|out of memory', line, re.I)]
+        if rejected:
+            sources.append((state_rel, 'output_error'))
+        record = {'job': name, 'optimizer': opt, 'gpu': gpu, 'full': full, 'canonical': canon, 'rel': canon,
+                  'state_rel': state_rel, 'state': state, 'meta': meta, 'start': start, 'end': end, 'command': command,
+                  'rc': rc, 'watchdog': watchdog, 'skip': skipped, 'sources': sources,
+                  'status': 'capacity SKIP/unmeasured' if skipped else 'failed/unmeasured' if rc or watchdog or rejected else 'success'}
+        if record['status'] == 'success':
+            check(not skips, name + ': success with SKIP is not a completed measurement')
+        elif present(canon):
+            read(canon)  # Original failed JSON is retained, never parsed as accepted timing.
+        return record
+
+    nag, sgd = job('R-48-2', 'nag'), job('R-48-2-sgd', 'sgd')
+    check(sgd is None or nag is not None and nag['skip'], 'SGD GPU job lacks actual NAG capacity-SKIP trigger')
+    expected_opt = None
+    if nag:
+        if not nag['skip']:
+            expected_opt = 'nag'
+        elif sgd:
+            # The deployed post-SGD choice uses rc/skip, without a status condition.
+            expected_opt = 'nag' if sgd['rc'] == 3 and sgd['state']['skip'] else 'sgd'
+    check(optimizer is None or expected_opt is None or optimizer == expected_opt, 'optimizer record contradicts present preceding jobs')
+    cpu = job('R-48-3', optimizer) if cpu_seen else None
+    if cpu:
+        check(not any(present(rel) for rel in cpu_candidates if rel != cpu['canonical']), 'conflicting CPU optimizer output candidates')
+        cpu['sources'].append((opt_rel, 'cpu_optimizer'))
+    records = {'ABL-CUDA-L7': sgd or nag, 'ABL-CPU-L7': cpu, 'ABL-CPU-L31': job('R-48-4', 'nag')}
+
+    def validate(record, key):
+        rel = f'results/run_all/{inp.run_all}/{RUN[key][1]}.json' if inp.run_all else record['canonical']
+        record['rel'] = rel
+        if record['status'] != 'success':
+            if present(rel):
+                read(rel)
+            return
+        check(present(rel), record['job'] + ': successful terminal lacks selected binary bytes')
+        check(record['state'].get('output_sha256') == hashlib.sha256(read(rel)).hexdigest(), record['job'] + ': output SHA256 mismatch')
+        if rel != record['canonical'] and present(record['canonical']):
+            check(read(rel) == read(record['canonical']), 'run_all alias contradicts canonical original')
+        d = doc(rel)
+        p, setup, backend = d['provenance'], d['setup'], d['backend']
+        gpu, full = record['gpu'], record['full']
+        check(p['written_by'] == 'the ablation binary (raw output, not assembled)' and p['git_commit'] == R48_PIN and
+              p['git_modified_tracked_files'] == 'none' and p['command_line'] == ' '.join(record['command']), 'wrong binary provenance')
+        check(p['build'] == {'debug_assertions': False, 'package_version': '0.0.0', 'target_os': 'linux',
+                            'target_arch': 'x86_64', 'features': {'parallel': True, 'cuda': True}} and p['parallel_feature'] is True, 'wrong P48 build')
+        check(isinstance(record['meta'].get('host'), str) and record['meta']['host'].split('.')[0] == p['machine']['host'] and
+              all(isinstance(p['machine'][k], str) and p['machine'][k] not in ('', 'unknown') for k in ('host', 'cpu', 'os')), 'wrong binary/runner host')
+        check(isinstance(p['threads'], str) and re.fullmatch(r'rayon \(feature parallel\), RAYON_NUM_THREADS = 12, [1-9][0-9]* logical CPUs', p['threads']) and
+              d['machine']['threads'] == 'rayon (parallel feature), RAYON_NUM_THREADS=12', 'wrong binary thread context')
+        ps, pe = num(p['started_unix'], 'binary start'), num(p['finished_unix'], 'binary finish')
+        check(record['start'] <= ps < pe < record['end'] + 1, 'binary time outside runner interval')
+        check(all(isinstance(p[k], str) and p[k] not in ('', 'unknown') for k in ('load_start', 'load_end')), 'missing shared-load context')
+        if gpu:
+            info = p['gpu']
+            check(isinstance(info, dict) and isinstance(info.get('name'), str) and info['name'] and
+                  num(info['free_mib_at_start'], 'GPU free memory', minimum=1e-12) <= num(info['total_mib'], 'GPU total memory', minimum=1e-12) and
+                  backend['device'] == info['name'], 'missing/contradictory actual GPU provenance')
+        else:
+            check(p['gpu'] is None and backend['device'] == 'cpu', 'CPU P48 GPU provenance must be null')
+        flags = {'hoist': True, 'bsgs': True, 'lazy_relin': True, 'default': True}
+        check(backend['options'] == {'backend': 'cuda' if gpu else 'cpu', 'eval_config': flags, 'matvec': 'sequential',
+                                     'gpu_pool': 'default (256 MiB release threshold)', 'top_level': None if full else 7} and
+              all(type(v) is bool for v in backend['options']['eval_config'].values()), 'wrong actual backend options')
+        expected_setup = {'params': 'n16_train', 'log_n': 16, 'max_level': 31, 'start_level': 31 if full else 7,
+                          'level_capped': not full, 'dims': [784, 32, 10], 'layout_d': 1024, 'lanes_b': 32,
+                          'optimizer': record['optimizer'], 'lr': 0.001, 'momentum': 0.9, 'seed': 48,
+                          'transpose_keys': 'reuse (mlp_key_pool)', 'matvec_dims_per_step': [32, 16, 16],
+                          'warmup_iterations': 1, 'timed_iterations': 3 if full else 5}
+        check(all(setup[k] == value and type(setup[k]) is type(value) for k, value in expected_setup.items()), 'wrong registered setup/condition')
+        num(setup['keygen_s'], 'key generation seconds')
+        num(setup['galois_keys'], 'Galois key count', True, 1)
+        check(isinstance(d['protocol'], str) and hashlib.sha256(d['protocol'].encode()).hexdigest() == R48_PROTOCOL_SHA, 'wrong timing/check protocol')
+        check(isinstance(d['caveats'], list) and hashlib.sha256(json.dumps(d['caveats'], ensure_ascii=False, separators=(',', ':')).encode()).hexdigest() ==
+              R48_CAVEATS_SHA, 'missing/changed four producer caveats')
+        check(d['all_checks_pass'] is True and isinstance(d['configs'], list) and len(d['configs']) == 8, 'failed/incomplete configuration grid')
+        rows = {}
+        for i, row in enumerate(d['configs']):
+            triple = tuple(row[k] for k in ('hoist', 'bsgs', 'lazy_relin'))
+            check(all(type(v) is bool for v in triple) and triple not in rows and
+                  row['config'] == 'hoist={} bsgs={} lazy_relin={}'.format(*(int(v) for v in triple)), 'duplicate/malformed configuration')
+            rows[triple] = row
+            c = row['counter_per_iteration']
+            for field in ('rotations', 'relins', 'key_switches', 'ct_ct_tensor', 'ct_pt_mults', 'rescales', 'bootstraps'):
+                num(c[field], field, True)
+            check(c['key_switches'] == c['rotations'] + c['relins'] and c['bootstraps'] == 0 and
+                  row['counter_constant_over_iterations'] is True and row['closed_form_matches'] is True and
+                  row['counts_equal_hoist_on_counterpart'] is True and
+                  (row['weights_bit_identical_to_hoist_on_counterpart'] is None if triple[0] else
+                   row['weights_bit_identical_to_hoist_on_counterpart'] is True), 'counter/row checks contradict success')
+            samples = row['step_s']
+            check(isinstance(samples, list) and len(samples) == expected_setup['timed_iterations'], 'wrong timed repetition coverage')
+            for value in samples:
+                num(value, 'step sample', minimum=1e-12)
+            same(row['step_s_median'], statistics.median(samples), 'step median')
+            same(row['iteration_s_median'], row['step_s_median'] + num(row['refresh_s_median'], 'refresh median'), 'sum of step/refresh medians')
+            error = num(row['max_abs_weight_diff_vs_default'], 'weight difference')
+            logarithm = row['log2_max_abs_weight_diff_vs_default']
+            check(logarithm is None if error == 0 else type(logarithm) in (int, float) and math.isfinite(logarithm) and
+                  math.isclose(logarithm, math.log2(error), abs_tol=1e-9), 'inconsistent weight-difference log2')
+        check(set(rows) == {(h, b, l) for h in (True, False) for b in (True, False) for l in (True, False)}, 'incomplete boolean grid')
+        default, naive = rows[True, True, True], rows[False, False, False]
+        check(default['max_abs_weight_diff_vs_default'] == 0, 'default differs from itself')
+        for (hoist, bsgs, lazy), row in rows.items():
+            c, base = row['counter_per_iteration'], default['counter_per_iteration']
+            # P48 EvalConfig formulas for the registered d=32,16,16 matvecs.
+            predicted_rot = base['rotations'] + (0 if bsgs else 39)
+            predicted_relin = base['relins'] + (52 if not lazy else 0 if bsgs else 39)
+            check(num(row['closed_form']['rotations'], 'predicted rotations', True) == c['rotations'] == predicted_rot and
+                  num(row['closed_form']['relins'], 'predicted relins', True) == c['relins'] == predicted_relin, 'relative closed form disagrees')
+            counterpart = rows[True, bsgs, lazy]
+            check(c == counterpart['counter_per_iteration'] and row['max_abs_weight_diff_vs_default'] == counterpart['max_abs_weight_diff_vs_default'], 'hoist counterpart contradiction')
+            same(row['step_time_over_default'], row['step_s_median'] / default['step_s_median'], 'step/default ratio')
+            same(row['step_speedup_over_all_off'], naive['step_s_median'] / row['step_s_median'], 'all-off/step ratio')
+        check(setup['data'] in ('MNIST training images (first in file order)',
+                               'synthetic uniform pixels (MNIST IDX files not found)'), 'unknown workload data note')
+        if setup['data'] != 'MNIST training images (first in file order)':
+            record['status'] = 'invalid-workload/unmeasured'
+        record['data'] = d
+        s.cache[rel] = d
+        record['sources'] += [(record['state_rel'], 'output_sha256')] + [(rel, field) for field in
+                              ('provenance', 'all_checks_pass', 'protocol', 'setup.data', 'setup.timed_iterations', 'setup.warmup_iterations', 'setup.seed')]
+
+    for key, record in records.items():
+        alias = f'results/run_all/{inp.run_all}/{RUN[key][1]}.json' if inp.run_all else None
+        check(record is not None or not (alias and present(alias)), 'run_all binary lacks original job association')
+        if record:
+            validate(record, key)
+    records['attempts'] = [record for record in (nag, sgd) if record]
+    return records
+
+
 def table_ablation(s, inp):
     t = Table('rq3_ablation', 'RQ3 ablation: one interactive eMLP-1 iteration under each EvalConfig',
               ['Source', 'Backend / level', 'hoist bsgs lazy', 'Rotations', 'Relins', 'KS/iter',
                'Closed form', 'Step median (s)', 'Step / default', 'Max |ΔW| vs default'], wide=True)
     caveats = None
-    pair = [inp.path(key) for key in ('ABL-CUDA-L7', 'ABL-CPU-L7')]
+    registered = r48_inputs(s, inp)
+    pair = [registered.get(key)['rel'] if registered.get(key) and registered[key]['status'] == 'success' else None
+            for key in ('ABL-CUDA-L7', 'ABL-CPU-L7')]
     if all(pair):
-        conditions = ('params', 'start_level', 'optimizer', 'layout_d', 'lanes_b', 'seed')
+        conditions = ('params', 'start_level', 'optimizer', 'dims', 'layout_d', 'lanes_b', 'seed',
+                      'lr', 'momentum', 'data', 'warmup_iterations', 'timed_iterations')
         gpu_setup, cpu_setup = [s.get(rel, 'setup')[0] for rel in pair]
         require(all(gpu_setup.get(k) == cpu_setup.get(k) for k in conditions),
                 'RQ3 CPU/GPU pair must use the same params/level/optimizer/layout/batch/seed')
     for key, label in (('ABL-CPU-L31', 'CPU, n16_train, level 31'), ('ABL-CUDA-L7', 'GPU, n16_train, level 7'),
                        ('ABL-CPU-L7', 'CPU, n16_train, level 7'), ('ABL-SMOKE', 'CPU smoke')):
-        rel = inp.path(key)
+        record = registered.get(key)
+        rel = inp.path(key) if key == 'ABL-SMOKE' else record['rel'] if record else None
         if rel is None:
             if not (inp.run_all and RUN[key][1] is None):
                 t.row([label, '', '', '', '', '', '', inp.pending(key), '', ''])
             continue
+        if record:
+            sources = record['sources']
+            t.note(f'{record["job"]}: {record["status"]}; optimizer {record["optimizer"]}; '
+                   f'child exit {record["rc"]}; watchdog {str(record["watchdog"]).lower()}. '
+                   'Runner/queue fields and hashes identify captured bytes, not historical execution proof.', sources)
+            if record['status'] != 'success':
+                t.row([Cell(label, sources), '', '', '', '', '', '', Cell(record['status'], sources), '—', '—'])
+                if 'data' in record:
+                    if caveats is None:
+                        caveats = (rel, record['data']['caveats'])
+                    t.note(f'{record["job"]} original invalid workload: {record["data"]["setup"]["data"]}. '
+                           'Its recorded times are not accepted as real-MNIST performance.', [(rel, 'setup.data')])
+                continue
+            d, p = record['data'], record['data']['provenance']
+            t.note(f'{record["job"]}: one warmup; {d["setup"]["timed_iterations"]} timed iterations within seed 48, '
+                   'not independent seeds. Step is server work including device-queue wait; iteration_s_median '
+                   'is the sum of step and refresh medians, not a median of paired iteration totals. '
+                   'These are interactive client-refresh measurements, not NI bootstrap and not GPU peak measurements.',
+                   [(rel, field) for field in ('setup.timed_iterations', 'setup.warmup_iterations', 'setup.seed', 'protocol')])
+            t.note(f'{record["job"]}: {p["threads"]}; started {p["started_unix"]}; finished {p["finished_unix"]}; '
+                   f'load_start {p["load_start"]}; load_end {p["load_end"]}; original binary SHA256 '
+                   f'{record["state"]["output_sha256"]}.',
+                   [(rel, f'provenance.{field}') for field in ('threads', 'started_unix', 'finished_unix', 'load_start', 'load_end')] +
+                   [(record['state_rel'], 'output_sha256')])
         params, psrc = s.get(rel, 'setup.params')
         backend, bsrc = s.get(rel, 'backend.device')
         top, tsrc = s.get(rel, 'backend.options.top_level')
@@ -916,6 +1220,9 @@ def table_ablation(s, inp):
                    Cell('0' if dw == 0 else f'{dw:.2e}', [src('max_abs_weight_diff_vs_default')])])
         if caveats is None:
             caveats = (rel, s.get(rel, 'caveats')[0])
+    for attempt in registered.get('attempts', []):
+        if attempt is not registered.get('ABL-CUDA-L7'):
+            t.note(f'{attempt["job"]} preceding attempt: {attempt["status"]}; no timing accepted from that attempt.', attempt['sources'])
     if caveats:
         rel, items = caveats
         for i, text in enumerate(items):
diff --git a/tools/test_paper_tables.py b/tools/test_paper_tables.py
index 3461f07..fda0805 100644
--- a/tools/test_paper_tables.py
+++ b/tools/test_paper_tables.py
@@ -4,6 +4,7 @@ import copy
 import io
 import hashlib
 import json
+import math
 from pathlib import Path
 import subprocess
 import sys
@@ -24,10 +25,11 @@ def archived_overlay(root, source=ROOT):
         dest.mkdir(parents=True, exist_ok=True)
         for p in (source / base).iterdir():
             q = dest / p.name
-            if (q.exists() or p.name in ('run_all', 'tables', 'R-41-FULL-1', 'R-41-FULL-2', 'R-47-3', 'R-52',
+            if (q.exists() or p.name in ('run_all', 'tables', 'R-41-FULL-1', 'R-41-FULL-2', 'R-47-3', 'R-52', 'R-48',
                                          'mnist196_emlp2_ni_b48_subset1008_seed0.json',
                                          'mnist196_emlp3_ni_b48_subset1008_seed0.json',
-                                         'ablation_cuda.json', 'ablation_cpu_l7.json')):
+                                         'ablation_cuda.json', 'ablation_cuda_sgd.json', 'ablation_cpu_l7.json',
+                                         'ablation_cpu_l7_sgd.json', 'ablation_cpu.json')):
                 continue
             if p.is_file() or (p.is_dir() and base.endswith('/raw')) or p.name == 'reference':
                 q.symlink_to(p, target_is_directory=p.is_dir())
@@ -212,6 +214,86 @@ def refresh_r52_digest(dest, archive):
     (archive/'state.json').write_text(json.dumps(state))
 
 
+R48_PIN = '0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3'
+R48_WD = '/home/kmihara/hekit-post-full-clones/hekit-post-full-r48'
+
+
+def put_r48_optimizer(root, optimizer):
+    path = root / 'results/quadruped/raw/R-48/R-48-optimizer.json'
+    path.parent.mkdir(parents=True, exist_ok=True)
+    path.write_text(json.dumps({'cpu_optimizer': optimizer}))
+    return path
+
+
+def put_r48(root, job='R-48-2', optimizer='nag', rc=0, watchdog=False, skip=False, output=None, oom=False):
+    """Tiny SYNTHETIC actual-P48-shaped ablation and original terminal records."""
+    if output is None:
+        output = rc == 0
+    gpu = job in ('R-48-2', 'R-48-2-sgd')
+    full = job == 'R-48-4'
+    if job == 'R-48-2-sgd':
+        optimizer = 'sgd'
+    name = ('ablation_cuda' + ('_sgd' if optimizer == 'sgd' else '') if gpu else
+            'ablation_cpu' if full else 'ablation_cpu_l7' + ('_sgd' if optimizer == 'sgd' else ''))
+    rel = f'results/quadruped/{name}.json'
+    argv = ['target/release/ablation', '--backend', 'cuda' if gpu else 'cpu', '--params', 'n16_train',
+            *([] if full else ['--top-level', '7']), '--optimizer', optimizer, '--iters', '3' if full else '5',
+            '--warmup', '1', '--data', R48_WD + '/data/mnist', '--out', rel]
+    doc = json.loads((ROOT / 'results/ablation_cpu_smoke_small.json').read_bytes())
+    doc['provenance'].update(written_by='the ablation binary (raw output, not assembled)',git_commit=R48_PIN,
+        git_modified_tracked_files='none',command_line=' '.join(argv),parallel_feature=True,
+        build={'debug_assertions':False,'package_version':'0.0.0','target_os':'linux','target_arch':'x86_64',
+               'features':{'parallel':True,'cuda':True}},
+        machine={'cpu':'synthetic CPU','host':'synthetic-host','os':'Linux','logical_cpus':32,'memory_bytes':'1000'},
+        threads='rayon (feature parallel), RAYON_NUM_THREADS = 12, 32 logical CPUs',
+        load_start='1.0 2.0 3.0 1/100 1',load_end='2.0 3.0 4.0 1/100 1',
+        started_unix=1794099601.0,finished_unix=1794099609.0,
+        gpu={'name':'SYNTHETIC GPU','free_mib_at_start':3000.0,'total_mib':24000.0} if gpu else None)
+    doc['backend']['options'].update(backend='cuda' if gpu else 'cpu',
+        eval_config={'hoist':True,'bsgs':True,'lazy_relin':True,'default':True},
+        top_level=None if full else 7,matvec='sequential',gpu_pool='default (256 MiB release threshold)')
+    doc['backend']['device'] = 'SYNTHETIC GPU' if gpu else 'cpu'
+    doc['setup'].update(params='n16_train',log_n=16,max_level=31,start_level=31 if full else 7,
+        level_capped=not full,dims=[784,32,10],layout_d=1024,lanes_b=32,optimizer=optimizer,
+        lr=0.001,momentum=0.9,seed=48,data='MNIST training images (first in file order)',
+        transpose_keys='reuse (mlp_key_pool)',matvec_dims_per_step=[32,16,16],
+        warmup_iterations=1,timed_iterations=3 if full else 5)
+    for i,row in enumerate(doc['configs']):
+        row['counter_per_iteration']['rotations'] += 400
+        row['counter_per_iteration']['key_switches'] += 400
+        row['closed_form']['rotations'] += 400
+        median = 1.0 + i/10
+        row.update(step_s=[median+j/10 for j in ([-1,0,1] if full else [-2,-1,0,1,2])],
+                   step_s_median=median,refresh_s_median=0.2,iteration_s_median=median+0.2,
+                   step_time_over_default=median,step_speedup_over_all_off=1.7/median)
+    doc['machine'].update(threads='rayon (parallel feature), RAYON_NUM_THREADS=12',wall_total_s=9.0)
+    dest=root/rel
+    if dest.is_symlink():dest.unlink()
+    if output:dest.write_text(json.dumps(doc))
+    elif dest.exists():dest.unlink()
+    archive=root/'results/quadruped/raw/R-48'/job
+    archive.mkdir(parents=True,exist_ok=True)
+    need = dict(doc['backend']['gpu_need_estimate'])
+    need['total_mib'] = 2456.0 if optimizer == 'nag' else 2072.0
+    log = (f'ablation: SKIP ablation: needs {need["total_mib"]:.1f} MiB of GPU memory ({json.dumps(need)}), '
+           'only 1000.0 MiB free; GPU run unmeasured\n' if skip else
+           'device error: synthetic out of memory\n' if oom else 'SYNTHETIC ablation terminal log\n')
+    meta={'job':job,'host':'synthetic-host','workdir':R48_WD,'command':' '.join(argv),
+          'hekit_synced_commit':['commit 0e07561','full '+R48_PIN,'dirty_files 0'],
+          'threads_cap':12,'env_thread_caps':{name:'12' for name in ('OMP_NUM_THREADS','RAYON_NUM_THREADS','CARGO_BUILD_JOBS')},
+          'nice':10,'gpu_job':gpu,'start':'2026-11-08T10:00:00+09:00','end':'2026-11-08T10:00:10+09:00',
+          'wall_s_runner':10.0,'exit_status':rc,'watchdog_killed':watchdog}
+    state={'job':job,'rc':rc,'wrapper_rc':0,'status':'failed: RSS watchdog' if watchdog else
+           'failed: device OOM' if oom and rc else 'skipped' if rc==3 and skip else 'failed' if rc else 'done',
+           'skip':skip,'skip_lines':log.splitlines() if skip else [],'command':argv,'workdir':R48_WD,
+           'log':f'/home/kmihara/hekit-runs/logs/{job}.log','evidence_lines':[]}
+    if output and rc==0:state['output_sha256']=hashlib.sha256(dest.read_bytes()).hexdigest()
+    for name,text in {'program.log':log,'meta.json':json.dumps(meta),'state.json':json.dumps(state),
+                      'cmd.txt':' '.join(argv)+' \n','post.txt':'date: 2026-11-08T10:00:10+09:00\nJOB_DONE rc='+str(rc)+'\n'}.items():
+        (archive/name).write_text(text)
+    return dest,archive
+
+
 class PaperTablesTests(unittest.TestCase):
     def setUp(self):
         self.tmp = tempfile.TemporaryDirectory()
@@ -858,5 +940,176 @@ class PaperTablesTests(unittest.TestCase):
             self.assertEqual(result.read_text(),'SYNTHETIC original');self.assertEqual(sentinel.read_text(),'SYNTHETIC original')
 
 
+    def test_r48_registered_nag_pair_l31_context_and_sources(self):
+        # Break caught: output fields render without original terminal/workload/iteration context.
+        for job in ('R-48-2','R-48-3','R-48-4'):put_r48(self.root,job)
+        put_r48_optimizer(self.root,'nag')
+        table=self.build(tables.table_ablation)
+        measured=[r for r in rows(table) if r[0].startswith(('GPU, n16_train','CPU, n16_train'))]
+        self.assertEqual(len(measured),24)
+        md=tables.render_md(table,'synthetic/')
+        self.assertIn('5 timed iterations',md);self.assertIn('3 timed iterations',md)
+        self.assertIn('within seed 48',md);self.assertIn('not independent seeds',md)
+        self.assertIn('load_start',md);self.assertIn('load_end',md)
+        self.assertIn('sum of step and refresh medians',md)
+        self.assertIn('not GPU peak',md);self.assertIn('not NI bootstrap',md)
+        src='\n'.join(tables.source_lines(table))
+        self.assertIn('R-48/R-48-2/post.txt\tline 2',src)
+        self.assertIn('setup.timed_iterations',src)
+        self.assertTrue(any('upper bound' in n.text for n in table.notes))
+
+    def test_r48_conditional_sgd_both_skip_and_failed_sgd_choices(self):
+        # Break caught: unlike CPU/GPU optimizers, hidden NAG skip, or failed SGD treated as successful.
+        for sgd_rc,sgd_skip,cpu_opt,watchdog in ((0,False,'sgd',False),(3,True,'nag',False),
+                                                   (1,False,'sgd',False),(3,True,'nag',True)):
+            with self.subTest(sgd_rc=sgd_rc):
+                put_r48(self.root,rc=3,skip=True)
+                put_r48(self.root,'R-48-2-sgd',rc=sgd_rc,skip=sgd_skip,watchdog=watchdog)
+                put_r48(self.root,'R-48-3',optimizer=cpu_opt)
+                put_r48_optimizer(self.root,cpu_opt)
+                table=self.build(tables.table_ablation)
+                gpu=[r for r in rows(table) if r[0].startswith('GPU, n16_train')]
+                self.assertEqual(len(gpu),8 if sgd_rc==0 else 1)
+                if sgd_rc:self.assertIn('unmeasured',gpu[0][7])
+                self.assertTrue(any('R-48-2' in n.text and 'capacity SKIP' in n.text for n in table.notes))
+                # Remove prior selected CPU variant in this isolated synthetic iteration.
+                for rel in ('ablation_cpu_l7.json','ablation_cpu_l7_sgd.json'):
+                    path=self.root/'results/quadruped'/rel
+                    if path.exists():path.unlink()
+
+    def test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu(self):
+        # Break caught: a standalone CPU record implies an unseen GPU run or requires one unnecessarily.
+        for optimizer in ('nag','sgd'):
+            dest,archive=put_r48(self.root,'R-48-3',optimizer=optimizer)
+            record=put_r48_optimizer(self.root,optimizer)
+            table=self.build(tables.table_ablation)
+            gpu=next(r for r in rows(table) if r[0].startswith('GPU, n16_train'))
+            self.assertIn('pending (R-48-2)',gpu)
+            self.assertEqual(len([r for r in rows(table) if r[0].startswith('CPU, n16_train, level 7')]),8)
+            record.unlink()
+            with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+            record.write_text('{"cpu_optimizer":"other"}')
+            with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+            dest.unlink()
+
+    def test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending(self):
+        # Break caught: later optimizer/CPU/SGD absence hides the actual preceding capacity skip.
+        put_r48(self.root,rc=3,skip=True)
+        table=self.build(tables.table_ablation)
+        gpu=next(r for r in rows(table) if r[0].startswith('GPU,'))
+        cpu=next(r for r in rows(table) if r[0].startswith('CPU, n16_train, level 7'))
+        self.assertIn('capacity SKIP/unmeasured',gpu[7]);self.assertIn('pending (R-48-3)',cpu)
+        source='\n'.join(tables.source_lines(table))
+        self.assertIn('R-48/R-48-2/program.log\tline 1',source)
+
+    def test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured(self):
+        # Break caught: printed/saved success JSON overrides a failed original terminal.
+        for rc,watchdog,oom in ((1,False,True),(143,True,False),(1,False,False)):
+            put_r48(self.root,rc=rc,watchdog=watchdog,oom=oom,output=True)
+            table=self.build(tables.table_ablation)
+            gpu=[r for r in rows(table) if r[0].startswith('GPU, n16_train')]
+            self.assertEqual(len(gpu),1);self.assertIn('failed/unmeasured',gpu[0][7])
+        dest,archive=put_r48(self.root)
+        state=json.loads((archive/'state.json').read_text())
+        state.update(status='failed: output checks/provenance',output_error='synthetic output rejection')
+        del state['output_sha256'];(archive/'state.json').write_text(json.dumps(state))
+        self.assertIn('failed/unmeasured',next(r for r in rows(self.build(tables.table_ablation)) if r[0].startswith('GPU,'))[7])
+
+    def test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed(self):
+        # Break caught: selecting SGD from mere presence, or contradictory predecessor/CPU choice.
+        put_r48(self.root,'R-48-2-sgd')
+        with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+        put_r48(self.root) # NAG succeeds: SGD was never selected.
+        with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+        put_r48(self.root,rc=3,skip=True)
+        put_r48(self.root,'R-48-3',optimizer='nag');put_r48_optimizer(self.root,'nag')
+        with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+
+    def test_r48_capacity_skip_requires_the_actual_producer_marker(self):
+        # Break caught: a generic SKIP substring is queue metadata, not the producer's capacity diagnostic.
+        _,archive=put_r48(self.root,rc=3,skip=True)
+        log='SYNTHETIC unrelated SKIP comment\n';(archive/'program.log').write_text(log)
+        state=json.loads((archive/'state.json').read_text());state['skip_lines']=log.splitlines()
+        (archive/'state.json').write_text(json.dumps(state))
+        with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+
+    def test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs(self):
+        # Break caught: canonical path bypasses provenance, or malformed input leaves partial generated files.
+        for name,key,value in [('meta.json','threads_cap',1),('meta.json','hekit_synced_commit',['full '+'a'*40]),
+             ('meta.json','gpu_job',False),('state.json','rc',1),('state.json','output_sha256','a'*64),
+             ('state.json','command',['other']),('meta.json','start','2026-11-08T10:00:00')]:
+            dest,archive=put_r48(self.root);d=json.loads((archive/name).read_text());d[key]=value
+            (archive/name).write_text(json.dumps(d))
+            with self.subTest(name=name,key=key),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+        dest,archive=put_r48(self.root);(archive/'post.txt').unlink()
+        with contextlib.redirect_stderr(io.StringIO()),contextlib.redirect_stdout(io.StringIO()):
+            self.assertEqual(tables.main(['--root',str(self.root)]),2)
+            self.assertFalse((self.root/'paper').exists())
+            self.assertEqual(tables.main(['--root',str(self.root),'--from-run-all','quick']),0)
+
+    def test_r48_rejects_bad_binary_flags_counts_stats_and_protocol(self):
+        # Break caught: len8/top-level success masks duplicate rows or contradictory actual fields.
+        mutations=[('provenance.written_by','runner'),('provenance.git_commit','a'*40),
+          ('provenance.build.features.cuda',False),('provenance.machine.host','other'),
+          ('provenance.finished_unix',1794099700),('provenance.gpu',None),
+          ('setup.lr',0.002),('setup.dims',[196,32,10]),('setup.timed_iterations',3),
+          ('configs.0.hoist',1),('configs.0.closed_form_matches',False),
+          ('configs.0.counter_constant_over_iterations',False),('configs.0.counts_equal_hoist_on_counterpart',False),
+          ('configs.4.weights_bit_identical_to_hoist_on_counterpart',False),
+          ('configs.0.counter_per_iteration.key_switches',0),('configs.0.closed_form.rotations',0),
+          ('configs.0.step_s',[0,1,2,3,4]),('configs.0.step_s_median',99),
+          ('configs.0.step_time_over_default',2),('configs.0.iteration_s_median',99),
+          ('configs.0.log2_max_abs_weight_diff_vs_default',-10),('protocol','other')]
+        for field,value in mutations:
+            dest,archive=put_r48(self.root);d=json.loads(dest.read_text());node=d;parts=field.split('.')
+            for part in parts[:-1]:node=node[int(part)] if isinstance(node,list) else node[part]
+            node[parts[-1]]=value;dest.write_text(json.dumps(d));refresh_r52_digest(dest,archive)
+            with self.subTest(field=field),self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+        dest,archive=put_r48(self.root);d=json.loads(dest.read_text());d['configs']=[d['configs'][0]]*8
+        dest.write_text(json.dumps(d));refresh_r52_digest(dest,archive)
+        with self.assertRaises(tables.TableError):self.build(tables.table_ablation)
+
+    def test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times(self):
+        # Break caught: P48's synthetic-pixel fallback silently becomes real-MNIST measured training.
+        dest,archive=put_r48(self.root);d=json.loads(dest.read_text())
+        d['setup']['data']='synthetic uniform pixels (MNIST IDX files not found)'
+        dest.write_text(json.dumps(d));refresh_r52_digest(dest,archive)
+        table=self.build(tables.table_ablation);gpu=[r for r in rows(table) if r[0].startswith('GPU,')]
+        self.assertEqual(len(gpu),1);self.assertIn('invalid-workload/unmeasured',gpu[0][7])
+        self.assertTrue(any('synthetic uniform pixels' in note.text for note in table.notes))
+
+    def test_r48_full_alias_same_original_and_both_entrypoints(self):
+        # Break caught: generic run_all aliases select historical/unassociated bytes.
+        dest,archive=put_r48(self.root)
+        alias=self.root/'results/run_all/full/ablation_cuda_l7.json';alias.parent.mkdir(parents=True)
+        alias.write_bytes(dest.read_bytes())
+        store=tables.Store(self.root);tables.table_ablation(store,tables.Inputs(store,'full'))
+        alias.write_text('{}')
+        store=tables.Store(self.root)
+        with self.assertRaises(tables.TableError):tables.table_ablation(store,tables.Inputs(store,'full'))
+        alias.write_bytes(dest.read_bytes());(archive/'post.txt').unlink()
+        store=tables.Store(self.root)
+        with self.assertRaises(tables.TableError):tables.table_ablation(store,tables.Inputs(store,'full'))
+        put_r48(self.root)
+        for entry in ('paper_tables.py','tables.py'):
+            p=subprocess.run([sys.executable,str(ROOT/'tools'/entry),'--root',str(self.root),'--sources','rq3_ablation'],capture_output=True,text=True)
+            self.assertEqual(p.returncode,0,p.stderr)
+            self.assertIn('R-48/R-48-2/post.txt',p.stdout)
+
+    def test_r48_future_archive_and_binary_overlay_write_isolation(self):
+        # Break caught: fixtures overwrite future actual R48 originals through symlinks.
+        with tempfile.TemporaryDirectory() as source,tempfile.TemporaryDirectory() as fixture:
+            source,fixture=Path(source),Path(fixture)
+            for rel in ('docs','results/quadruped/raw/R-48'):(source/rel).mkdir(parents=True,exist_ok=True)
+            names=('ablation_cuda.json','ablation_cuda_sgd.json','ablation_cpu_l7.json','ablation_cpu_l7_sgd.json','ablation_cpu.json')
+            for name in names:(source/'results/quadruped'/name).write_text('SYNTHETIC original')
+            archived_overlay(fixture,source)
+            self.assertFalse((fixture/'results/quadruped/raw/R-48').exists())
+            for name in names:
+                path=fixture/'results/quadruped'/name
+                self.assertFalse(path.exists());path.write_text('SYNTHETIC replacement')
+                self.assertEqual((source/'results/quadruped'/name).read_text(),'SYNTHETIC original')
+
+
 if __name__ == '__main__':
     unittest.main()
```

stderr (verbatim):
```text
```

## Actual input absence and limits

- `results/quadruped/raw/R-48`: exists=False.
- `results/quadruped/ablation_cuda.json`: exists=False.
- `results/quadruped/ablation_cuda_sgd.json`: exists=False.
- `results/quadruped/ablation_cpu_l7.json`: exists=False.
- `results/quadruped/ablation_cpu_l7_sgd.json`: exists=False.
- `results/quadruped/ablation_cpu.json`: exists=False.

All populated cases are tiny explicitly synthetic temporary fixtures, not measurements, real GPU runs or scientific acceptance. Fixture overlays exclude future raw/R-48 and all five canonical ablation outputs; write-isolation tests retain synthetic source sentinels. P48-shaped test records borrow the existing project smoke's output schema and verbatim caveats/protocol, with synthetic timings/host/GPU facts; those values never enter actual-result paths.

No unresolved contract ambiguity remains after the recorded standalone CPU ruling. Source self-reports, clean markers, workload notes and capture hashes do not independently attest historical execution/data consumption or replay every counter/weight check. The R48-1 mandatory training-test gate, real GPU peak memory, collection/scientific acceptance, full Task54/Step3/4 and the broader experiment matrix remain separate incomplete work. This slice only fixes registered ablation table intake/reporting. Root independent source review and any populated synthetic PDF layout validation remain pending; no PDF publication or actual result acceptance is claimed.
