# R48 table integration independent review

SPEC: **NEEDS FIX** (one P2 finding). QUALITY: **NEEDS FIX** for the same bounded fail-closed gap. The existing 50-method suite, both check-only entrypoints, and scoped diff whitespace check pass. No successful measurement is fabricated by the reproduced gap; contradictory present input is incorrectly hidden as pending.

## Scope and reviewed identity

Reviewed only the R48 change in tools/paper_tables.py and tools/test_paper_tables.py against original BASE `3090d1e6c71e38e8efb8e713a0d265b9d788b522`, the supplied brief and standalone CPU ruling, the implementation report (RED/final behavior/GREEN/source-pin/exact-diff/limitations sections), actual P48 producer sources through read-only git show, and the deployed queue/runner source. Root explicitly authorized read-only git show/diff/rev-parse; no Git mutation was performed. Intervening root documentation work is outside this review.

Frozen source hashes:
- tools/paper_tables.py: `f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0`.
- tools/test_paper_tables.py: `73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0`.
- BASE versions respectively: `2eb7f241d0bc6302ad5d1892ab3bb1980120d92787c76cf70f0c15fef85da1c1`, `8cf932dd06c41c3405c62db2361ef78ece5ae649b41cfe3c72c2b62130d345c5`.

Command `git diff 3090d1e6c71e38e8efb8e713a0d265b9d788b522 -- tools/paper_tables.py tools/test_paper_tables.py` was read through subprocess.check_output. Its 44395 bytes have SHA256 `2ac7b206acdb91f47e53b3ae8c0be41a0526f7eb0c26def0ac6ad5e5fc2e40e4`; equality against the report's sole fenced diff was True. Only the supplied two-file scope is asserted.

## P2: wrong CPU variant without terminal originals bypasses fail-closed intake

Location: tools/paper_tables.py lines945-953 and1036-1039.

With original optimizer record `{"cpu_optimizer":"nag"}`, a present `results/quadruped/ablation_cpu_l7_sgd.json`, and no R-48-3 terminal originals, the table returns `pending (R-48-3)` and the sources entrypoint exits0. The symmetric selected-SGD/present-NAG case behaves identically. The wrong candidate can even contain deliberately invalid producer JSON. This violates the brief's distinction between all-absent pending and partial/malformed/contradictory canonical evidence.

Mechanism: cpu_seen observes both CPU canonical candidates, but job('R-48-3', optimizer) checks only the selected canonical name plus terminal files and returns None. The conflicting-candidate check is guarded by `if cpu`, so it never executes in this case. Thus present contradictory canonical evidence disappears from the rendered diagnostic and source index. This is an input-validation/reporting defect, not a successful-timing promotion.

Requested bounded correction: whenever any CPU candidate or original CPU terminal is observed, require a coherent selected R-48-3 association and reject the nonselected CPU candidate independently of whether job() returned a record. Preserve true all-absent pending, valid standalone NAG/SGD CPU with its optimizer record, failed-job unmeasured behavior, and authorized alias-only selected-byte behavior with original terminal association. Add both optimizer directions as negative regressions with no terminal files and no selected canonical output; ensure table/source entrypoint fails and generation remains atomic. Do not infer an attempted CPU job from the wrong variant.

Independent reproducer (writes only a TemporaryDirectory; source fixtures remain read-only):
```sh
python3 -B - <<'PY'
import sys,tempfile,contextlib,io,json
from pathlib import Path
sys.path.insert(0,'tools')
import paper_tables as p
import test_paper_tables as t
for selected,wrong in [('nag','sgd'),('sgd','nag')]:
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);t.archived_overlay(root);t.put_r48_optimizer(root,selected)
  name='ablation_cpu_l7'+('_sgd' if wrong=='sgd' else '')+'.json'
  path=root/'results/quadruped'/name
  raw=b'{"SYNTHETIC": "wrong CPU candidate without terminal originals"}'
  path.write_bytes(raw)
  s=p.Store(root)
  try:
   table=p.table_ablation(s,p.Inputs(s))
   row=next(r for r in t.rows(table) if r[0].startswith('CPU, n16_train, level 7'))
   print('selected='+selected+' wrong='+wrong+' result='+row[7])
  except p.TableError as exc:print('REJECTED',exc)
  with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
   rc=p.main(['--root',str(root),'--sources','rq3_ablation'])
  print('sources_entrypoint_exit='+str(rc),'source_bytes_unchanged='+str(path.read_bytes()==raw),'generated_paper_exists='+str((root/'paper').exists()))
PY
```
Exit: 0. Tool-captured stdout/stderr:
```text
selected=nag wrong=sgd result=pending (R-48-3)
sources_entrypoint_exit=0 source_bytes_unchanged=True generated_paper_exists=False
selected=sgd wrong=nag result=pending (R-48-3)
sources_entrypoint_exit=0 source_bytes_unchanged=True generated_paper_exists=False
```

## Contract findings otherwise supported by this review

- P48 actual ablation.rs writes binary JSON before returning failure when all_checks_pass=false. Failed/watchdog/queue-output-rejected records do not consume saved timing JSON as success. Missing output alone is not SKIP. The actual capacity message is traced through backend.open_gpu and main's ablation prefix; its total and estimate fields both use one-decimal formatting, so the parser's displayed-total comparison matches the producer.
- Queue lines380-383 distinguish the NAG trigger (rc3, SKIP, status skipped) from the post-SGD optimizer choice (rc3 and raw skip only). Ordinary NAG OOM/rc1 cannot select SGD. The parser follows both branches, including watchdog-marked SGD rc3/SKIP. Original optimizer record, terminal fields, exact job/pin/clean/argv/workdir/limits, child/meta/post consistency, and distinct wrapper exit are retained.
- The standalone CPU ruling is implemented for valid originals: CPU NAG or SGD may stand without unseen GPU evidence; GPU remains pending. Present contradictory predecessor jobs and SGD without the NAG trigger are rejected. The P2 above concerns a malformed output-only input, not this authorized standalone path.
- Successful selected binary bytes must match original state.output_sha256 and, when present, canonical bytes. Writer/pin/build/command/host/thread/time/GPU context and actual backend/setup fields are checked. CPU uses cuda=true/parallel=true build with gpu=null. Quick is separate. Hashes and source self-reports are not historical-execution or historical-input proof.
- The eight boolean triples are unique and complete; labels, per-row flags, integer counters, KS sum, zero bootstraps, relative closed form and hoist counterparts are checked. P48 ops/linalg formulas give bsgs-off +39 rotations, lazy-off +52 relins, and bsgs-off/lazy-on +39 relins for dims32,16,16. Absolute default counts remain source-reported, not independently recomputed.
- Positive timed samples, 5 L7/3 L31 repetitions, one warmup, medians, ratios, zero-error/null-log2, and iteration=sum(step median,refresh median) follow emitted P48 fields. No absent refresh sample array is demanded. Real-MNIST producer note is required for accepted timing; actual synthetic-pixel fallback remains invalid-workload/unmeasured. This validates the recorded note, not the historical IDX bytes.
- Accepted L7 pairs require matching conditions; no new CPU/GPU or external performance ratio is introduced. The four original caveats and smoke counts-only suppression remain. Notes attribute load/thread/start-end/repetitions/digest to original fields and separate within-seed iterations from independent seeds.
- The new fixtures exclude future raw/R-48 and all five canonical outputs before writing. Existing R47/R52 function source and renderer/source-index functions are exactly unchanged from BASE. The complete 50-method suite covers both adopted paths. Current actual R48 inputs remain absent and both real-root --check commands pass without generated writes.

## Actual independent checks

Command: `python3 -B -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0. Raw combined output returned by exec_command:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... ok
test_r48_capacity_skip_requires_the_actual_producer_marker (test_paper_tables.PaperTablesTests.test_r48_capacity_skip_requires_the_actual_producer_marker) ... ok
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... ok
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... ok
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... ok
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... ok
test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending) ... ok
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... ok
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... ok
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... ok
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 50 tests in 5.757s

OK
```

The following exact bounded command records hashes, prior-function source equality, individual entrypoint/diffcheck statuses and empty outputs, and actual input absence:
```sh
python3 -B - <<'PY'
import subprocess,pathlib,hashlib,ast
base='3090d1e6c71e38e8efb8e713a0d265b9d788b522';pin='0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3'
L=pathlib.Path('.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5')
for path in [pathlib.Path('tools/paper_tables.py'),pathlib.Path('tools/test_paper_tables.py'),L/'task-54-r48-table-integration-brief.md',L/'task-54-r48-standalone-cpu-ruling.md',L/'task-54-r48-table-integration-report.md',pathlib.Path('results/quadruped/scripts/post_full_queue.py'),pathlib.Path('results/quadruped/scripts/run_job.sh')]:
 b=path.read_bytes();print(str(path),len(b),hashlib.sha256(b).hexdigest())
for name in ('crates/hekit-bench/src/bin/ablation.rs','crates/hekit-bench/src/backend.rs','crates/hekit-bench/src/provenance.rs','crates/hekit-ckks/src/ops.rs','crates/hekit-ckks/src/linalg.rs'):
 b=subprocess.check_output(['git','show',pin+':'+name]);print(pin+':'+name,len(b),hashlib.sha256(b).hexdigest())
old=subprocess.check_output(['git','show',base+':tools/paper_tables.py']).decode();new=pathlib.Path('tools/paper_tables.py').read_text()
def functions(src):return {n.name:ast.get_source_segment(src,n) for n in ast.parse(src).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=functions(old),functions(new)
for name in ('r47_batch_input','table_gpu','r52_input','read_r52_input','table_accuracy','source_lines','render_md','render_tex'):
 print('UNCHANGED',name,a[name]==b[name])
for command in (['python3','-B','tools/paper_tables.py','--check'],['python3','-B','tools/tables.py','--check'],['git','diff','--check',base,'--','tools/paper_tables.py','tools/test_paper_tables.py']):
 r=subprocess.run(command,capture_output=True,text=True);print('COMMAND',command,'EXIT',r.returncode,'STDOUT',repr(r.stdout),'STDERR',repr(r.stderr))
for name in ('raw/R-48','ablation_cuda.json','ablation_cuda_sgd.json','ablation_cpu_l7.json','ablation_cpu_l7_sgd.json','ablation_cpu.json'):
 path=pathlib.Path('results/quadruped')/name;print('ACTUAL_PATH',str(path),'exists',path.exists(),'symlink',path.is_symlink())
PY
```
Exit: 0. Raw output:
```text
tools/paper_tables.py 106748 f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0
tools/test_paper_tables.py 71248 73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0
.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-table-integration-brief.md 5676 00f0425fc0e2a50aaf156a2de35a6d5175bb68db577e74981281cdebbb14e6d6
.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-standalone-cpu-ruling.md 1812 06756d949c8c16891b462fb5c72007a4c218486b2da90a8e0eb68c83c5b48a44
.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-table-integration-report.md 160586 366a81203504343a61a47dd2c95cf37b1b2a1df41a8bb6fd1c8a47798fc31354
results/quadruped/scripts/post_full_queue.py 23840 1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9
results/quadruped/scripts/run_job.sh 4998 46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736
0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-bench/src/bin/ablation.rs 32081 2baf83ef4a04ed000b05f5228328bc6da424e8a6c8221ebeb32c96b72f9ae137
0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-bench/src/backend.rs 24543 cafdcebb6fa4e54e4220cc096c7528cd3c53db78c0a34c22f3d066ba0b1ceaf5
0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-bench/src/provenance.rs 6686 4d519fec381e63141185ba87aa1638f12d18698fb91f6285555d8f546c65820b
0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-ckks/src/ops.rs 31115 54df0f262234de512bb69642ac3502cbb2497381f163330062f589d9bdf7cf6e
0e075618ab6e28b0cf260f98feb7f80ee1ccf1f3:crates/hekit-ckks/src/linalg.rs 69024 35ede5597a706bdcd3d23601594ff280efceaf10ed3ebcbb01b5e66171f8c2e4
UNCHANGED r47_batch_input True
UNCHANGED table_gpu True
UNCHANGED r52_input True
UNCHANGED read_r52_input True
UNCHANGED table_accuracy True
UNCHANGED source_lines True
UNCHANGED render_md True
UNCHANGED render_tex True
COMMAND ['python3', '-B', 'tools/paper_tables.py', '--check'] EXIT 0 STDOUT '' STDERR ''
COMMAND ['python3', '-B', 'tools/tables.py', '--check'] EXIT 0 STDOUT '' STDERR ''
COMMAND ['git', 'diff', '--check', '3090d1e6c71e38e8efb8e713a0d265b9d788b522', '--', 'tools/paper_tables.py', 'tools/test_paper_tables.py'] EXIT 0 STDOUT '' STDERR ''
ACTUAL_PATH results/quadruped/raw/R-48 exists False symlink False
ACTUAL_PATH results/quadruped/ablation_cuda.json exists False symlink False
ACTUAL_PATH results/quadruped/ablation_cuda_sgd.json exists False symlink False
ACTUAL_PATH results/quadruped/ablation_cpu_l7.json exists False symlink False
ACTUAL_PATH results/quadruped/ablation_cpu_l7_sgd.json exists False symlink False
ACTUAL_PATH results/quadruped/ablation_cpu.json exists False symlink False
```

## Limits

This review changes only this ledger report. No source edits, Git mutations, native/Rust/Cargo/SSH/server/GPU/HE execution, collector invocation, actual-result mutation, or actual generated-table write occurred. The suite and reproducer used small explicitly synthetic temporary fixtures. Read-only checks of the repository's existing generated files passed.

P48 sources were read at the exact pin; no broad mutable Rust inspection or build occurred. Source text, producer assertions, recorded workload labels and hashes cannot prove historical execution, historical consumed-input bytes, independent replay of counters/weights, or scientific acceptance. No actual R48 terminal archive or binary was available. Root's separately reported synthetic populated-PDF/layout check is not an independent check performed here and does not alter this finding. R48-1, native acceptance, full Task54, remaining research gates and science conclusions are outside scope. After the single P2 is corrected, perform a focused independent rereview and affected regression checks before adopting this slice.

