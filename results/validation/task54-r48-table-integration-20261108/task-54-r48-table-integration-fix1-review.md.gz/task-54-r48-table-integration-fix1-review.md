# R48 table integration FIX1 independent rereview

SPEC: **PASS**. QUALITY: **PASS**. The sole P2 in task-54-r48-table-integration-review.md is closed. No additional actionable finding in this scoped correction and its affected regressions.

## Scope, pins, and conclusion

The reviewed implementation is tools/paper_tables.py SHA256 `f7e3774f7124fe24e5a7a882df902ea7584aaa62ece7855a43def5d880af6b38` (106815 bytes), with tools/test_paper_tables.py SHA256 `a791c10d58485b0262dae7aee70be390ac72d7d7ea15aa7416a773257d414402` (74518 bytes). FIX1 author report SHA256 `2be493e140a7f4a557036b16cc1779bd8f9f7c4c4e845c1f1c2a1183c59089ea` was read for RED evidence, finite correction, GREEN/checks, exact diff, identity and limitations. The large repetitive RED transcript is not a new execution by this reviewer.

Initial author report SHA256 `366a81203504343a61a47dd2c95cf37b1b2a1df41a8bb6fd1c8a47798fc31354` and initial independent review SHA256 `b8274e24432a4ae14a42a54e33bc77e58f0ca945a2409ad4897fcd4bde70d0c4` are unchanged. The exact initial candidate was reconstructed entirely in memory from original BASE `3090d1e6c71e38e8efb8e713a0d265b9d788b522` plus the preserved initial report diff, with every old hunk/context line asserted. Reconstructed hashes equal the original frozen source `f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0` and test `73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0`. Independently computed FIX1 unified diffs exactly match the two diffs retained in the FIX1 report.

The production diff only moves the opposite-canonical-candidate rejection ahead of job() and derives the selected path from the already-validated optimizer record whenever cpu_seen is true. It therefore runs even when the selected binary and terminal files are absent. A wrong variant is rejected as contradictory input; no attempted job or measurement is inferred.

Both selected-NAG/present-SGD and selected-SGD/present-NAG output-only cases now raise TableError. The new negative test checks direct table intake, both source entrypoints (exit2 with empty stdout), and generation (exit2 with neither generated directory created). The original wrong bytes remain untouched. Independent rerunning of the earlier review's exact reproducer also now returns the intended error in both directions.

Valid standalone NAG/SGD CPU with the original optimizer record continues to render without manufacturing a GPU member. Original terminal association with selected alias-only bytes remains supported in both directions; the original digest still governs acceptance. Failed original CPU jobs remain failed/unmeasured with no success timings. The all-absent pending case, CPU/GPU branch cases, R47/R52 regressions and fixture isolation all remain green.

## Independent validation and exact commands

Command: `python3 -B -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0. Raw combined exec_command output:
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... ok
test_r48_capacity_skip_requires_the_actual_producer_marker (test_paper_tables.PaperTablesTests.test_r48_capacity_skip_requires_the_actual_producer_marker) ... ok
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... ok
test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported (test_paper_tables.PaperTablesTests.test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported) ... ok
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... ok
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... ok
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... ok
test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending) ... ok
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... ok
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... ok
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... ok
test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) ... ok
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 52 tests in 6.367s

OK
```

Earlier review's exact bounded reproducer, rerun against FIX1:
```sh
python3 -B - <<'PY'
import sys,tempfile,contextlib,io,json
from pathlib import Path
sys.path.insert(0,'tools')
import paper_tables as p
import test_paper_tables as t
for selected,wrong in [('nag','sgd'),('sgd','nag')]:
 with tempfile.TemporaryDirectory() as tmp:
  root=Path(tmp);t.archived_overlay(root);t.put_r48_optimizer(root,selected)
  name='ablation_cpu_l7'+('_sgd' if wrong=='sgd' else '')+'.json'
  path=root/'results/quadruped'/name
  raw=b'{"SYNTHETIC": "wrong CPU candidate without terminal originals"}'
  path.write_bytes(raw)
  s=p.Store(root)
  try:
   table=p.table_ablation(s,p.Inputs(s))
   row=next(r for r in t.rows(table) if r[0].startswith('CPU, n16_train, level 7'))
   print('selected='+selected+' wrong='+wrong+' result='+row[7])
  except p.TableError as exc:print('REJECTED',exc)
  with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
   rc=p.main(['--root',str(root),'--sources','rq3_ablation'])
  print('sources_entrypoint_exit='+str(rc),'source_bytes_unchanged='+str(path.read_bytes()==raw),'generated_paper_exists='+str((root/'paper').exists()))
PY
```
Exit: 0. Raw combined exec_command output:
```text
REJECTED R48: conflicting CPU optimizer output candidates
sources_entrypoint_exit=2 source_bytes_unchanged=True generated_paper_exists=False
REJECTED R48: conflicting CPU optimizer output candidates
sources_entrypoint_exit=2 source_bytes_unchanged=True generated_paper_exists=False
```

The following independent harness reconstructs the exact initial source, verifies the reported scoped diff, checks hashes/function preservation, compares valid populated rendering in memory, and records individual status/stdout/stderr for both real-root --check entrypoints and scoped diff --check:
```sh
python3 -B - <<'PY'
from pathlib import Path
import re,subprocess,hashlib,difflib,ast,sys,types,tempfile
L=Path('.superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5')
base='3090d1e6c71e38e8efb8e713a0d265b9d788b522'
initial_report=(L/'task-54-r48-table-integration-report.md').read_text()
fix_report=(L/'task-54-r48-table-integration-fix1-report.md').read_text()
patch=initial_report.split('```diff\n')[1].split('```')[0]
def apply(base,patch):
 lines=base.splitlines(keepends=True);out=[];cursor=0
 p=patch.splitlines(keepends=True);i=0
 while i<len(p):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',p[i])
  if not m:i+=1;continue
  start=int(m[1])-1;assert start>=cursor;out+=lines[cursor:start];cursor=start;i+=1
  while i<len(p) and not p[i].startswith('@@'):
   line=p[i];i+=1
   if line.startswith((' ','-')):
    assert lines[cursor]==line[1:],(cursor,lines[cursor],line);cursor+=1
   if line.startswith((' ','+')):out.append(line[1:])
 out+=lines[cursor:];return ''.join(out)
initial={}
for name,expected in [('tools/paper_tables.py','f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0'),('tools/test_paper_tables.py','73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0')]:
 chunk=next(p for p in patch.split('diff --git ') if p.startswith('a/'+name+' '))
 original=subprocess.check_output(['git','show',base+':'+name]).decode()
 initial[name]=apply(original,chunk)
 sha=hashlib.sha256(initial[name].encode()).hexdigest();assert sha==expected
 new=Path(name).read_text()
 delta=''.join(difflib.unified_diff(initial[name].splitlines(keepends=True),new.splitlines(keepends=True),fromfile='frozen-initial/'+name,tofile='fix1/'+name))
 assert delta in fix_report
 print('INITIAL_RECONSTRUCTION',name,sha)
 print('SCOPED_DIFF_MATCHES_REPORT',name,'bytes',len(delta.encode()),'sha256',hashlib.sha256(delta.encode()).hexdigest())
 print(delta)
for path in [Path('tools/paper_tables.py'),Path('tools/test_paper_tables.py'),L/'task-54-r48-table-integration-report.md',L/'task-54-r48-table-integration-review.md',L/'task-54-r48-table-integration-fix1-report.md']:
 b=path.read_bytes();print('PIN',path,len(b),hashlib.sha256(b).hexdigest())
def funcs(src):return {n.name:ast.get_source_segment(src,n) for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(initial['tools/paper_tables.py']),funcs(Path('tools/paper_tables.py').read_text())
for name in ('r47_batch_input','table_gpu','r52_input','read_r52_input','table_accuracy','table_ablation','source_lines','render_md','render_tex'):
 assert a[name]==b[name];print('UNCHANGED',name)
sys.path.insert(0,str(Path('tools').resolve()))
import paper_tables as current
import test_paper_tables as fixtures
prior=types.ModuleType('r48_review_initial');prior.__file__=str(Path('tools/paper_tables.py').resolve());sys.modules[prior.__name__]=prior
exec(compile(initial['tools/paper_tables.py'],prior.__file__,'exec'),prior.__dict__)
with tempfile.TemporaryDirectory() as tmp:
 root=Path(tmp);fixtures.archived_overlay(root)
 for job in ('R-48-2','R-48-3','R-48-4'):fixtures.put_r48(root,job)
 fixtures.put_r48_optimizer(root,'nag')
 tables=[]
 for mod in (prior,current):
  store=mod.Store(root);tables.append(mod.table_ablation(store,mod.Inputs(store)))
 for name,fn in [('Markdown',lambda m,t:m.render_md(t,'synthetic/')),('TeX',lambda m,t:m.render_tex(t,'synthetic/')),('source_lines',lambda m,t:'\n'.join(m.source_lines(t)))]:
  x,y=[fn(m,t).encode() for m,t in zip((prior,current),tables)];assert x==y
  print('POPULATED_IDENTITY',name,len(y),hashlib.sha256(y).hexdigest())
for command in (['python3','-B','tools/paper_tables.py','--check'],['python3','-B','tools/tables.py','--check'],['git','diff','--check',base,'--','tools/paper_tables.py','tools/test_paper_tables.py']):
 r=subprocess.run(command,capture_output=True,text=True);print('COMMAND',command,'EXIT',r.returncode,'STDOUT',repr(r.stdout),'STDERR',repr(r.stderr));assert r.returncode==0
PY
```
Exit: 0. Raw combined output:
```text
INITIAL_RECONSTRUCTION tools/paper_tables.py f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0
SCOPED_DIFF_MATCHES_REPORT tools/paper_tables.py bytes 983 sha256 5a913c0b12babd4c7949140a213e8e3511c2e0345929ec6474dc7deaaee984a6
--- frozen-initial/tools/paper_tables.py
+++ fix1/tools/paper_tables.py
@@ -1033,9 +1033,11 @@
             # The deployed post-SGD choice uses rc/skip, without a status condition.
             expected_opt = 'nag' if sgd['rc'] == 3 and sgd['state']['skip'] else 'sgd'
     check(optimizer is None or expected_opt is None or optimizer == expected_opt, 'optimizer record contradicts present preceding jobs')
+    if cpu_seen:
+        selected_cpu = canonical('R-48-3', optimizer)
+        check(not any(present(rel) for rel in cpu_candidates if rel != selected_cpu), 'conflicting CPU optimizer output candidates')
     cpu = job('R-48-3', optimizer) if cpu_seen else None
     if cpu:
-        check(not any(present(rel) for rel in cpu_candidates if rel != cpu['canonical']), 'conflicting CPU optimizer output candidates')
         cpu['sources'].append((opt_rel, 'cpu_optimizer'))
     records = {'ABL-CUDA-L7': sgd or nag, 'ABL-CPU-L7': cpu, 'ABL-CPU-L31': job('R-48-4', 'nag')}
 

INITIAL_RECONSTRUCTION tools/test_paper_tables.py 73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0
SCOPED_DIFF_MATCHES_REPORT tools/test_paper_tables.py bytes 3803 sha256 4062300ab30024ad99cf2e512f44197deac1dd48c5217a48ed9b5f3b1c4e37fd
--- frozen-initial/tools/test_paper_tables.py
+++ fix1/tools/test_paper_tables.py
@@ -1096,6 +1096,56 @@
             self.assertEqual(p.returncode,0,p.stderr)
             self.assertIn('R-48/R-48-2/post.txt',p.stdout)
 
+    def test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically(self):
+        # Break caught: CPU detection sees both variants, but a missing selected variant used to hide the wrong one.
+        for selected, wrong in (('nag', 'sgd'), ('sgd', 'nag')):
+            put_r48_optimizer(self.root, selected)
+            filename = 'ablation_cpu_l7' + ('_sgd' if wrong == 'sgd' else '') + '.json'
+            candidate = self.root / 'results/quadruped' / filename
+            raw = b'{"SYNTHETIC":"wrong CPU variant without original terminal"}'
+            candidate.write_bytes(raw)
+            expected = self.root / 'results/quadruped' / ('ablation_cpu_l7' + ('_sgd' if selected == 'sgd' else '') + '.json')
+            self.assertFalse(expected.exists())
+            self.assertFalse((self.root / 'results/quadruped/raw/R-48/R-48-3').exists())
+            with self.subTest(selected=selected, consumer='table'):
+                with self.assertRaises(tables.TableError):
+                    self.build(tables.table_ablation)
+            for entry in ('paper_tables.py', 'tables.py'):
+                with self.subTest(selected=selected, consumer=entry):
+                    p = subprocess.run([sys.executable, str(ROOT / 'tools' / entry), '--root', str(self.root),
+                                        '--sources', 'rq3_ablation'], capture_output=True, text=True)
+                    self.assertEqual(p.returncode, 2, p.stdout)
+                    self.assertEqual(p.stdout, '')
+            with self.subTest(selected=selected, consumer='generate'):
+                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
+                    self.assertEqual(tables.main(['--root', str(self.root)]), 2)
+                self.assertFalse((self.root / 'paper').exists())
+                self.assertFalse((self.root / 'results/tables').exists())
+            self.assertEqual(candidate.read_bytes(), raw)
+            candidate.unlink()
+
+    def test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported(self):
+        # Break caught: rejecting a legitimate selected alias while moving the wrong-candidate guard.
+        alias = self.root / 'results/run_all/full/ablation_cpu_l7.json'
+        alias.parent.mkdir(parents=True)
+        for optimizer in ('nag', 'sgd'):
+            original, _ = put_r48(self.root, 'R-48-3', optimizer=optimizer)
+            put_r48_optimizer(self.root, optimizer)
+            alias.write_bytes(original.read_bytes())
+            original.unlink()
+            store = tables.Store(self.root)
+            table = tables.table_ablation(store, tables.Inputs(store, 'full'))
+            cpu = [r for r in rows(table) if r[0].startswith('CPU, n16_train, level 7')]
+            gpu = next(r for r in rows(table) if r[0].startswith('GPU,'))
+            self.assertEqual(len(cpu), 8)
+            self.assertIn('pending (R-48-2)', gpu)
+            alias.unlink()
+            put_r48(self.root, 'R-48-3', optimizer=optimizer, rc=1, output=False)
+            table = self.build(tables.table_ablation)
+            cpu = [r for r in rows(table) if r[0].startswith('CPU, n16_train, level 7')]
+            self.assertEqual(len(cpu), 1)
+            self.assertIn('failed/unmeasured', cpu[0][7])
+
     def test_r48_future_archive_and_binary_overlay_write_isolation(self):
         # Break caught: fixtures overwrite future actual R48 originals through symlinks.
         with tempfile.TemporaryDirectory() as source,tempfile.TemporaryDirectory() as fixture:

PIN tools/paper_tables.py 106815 f7e3774f7124fe24e5a7a882df902ea7584aaa62ece7855a43def5d880af6b38
PIN tools/test_paper_tables.py 74518 a791c10d58485b0262dae7aee70be390ac72d7d7ea15aa7416a773257d414402
PIN .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-table-integration-report.md 160586 366a81203504343a61a47dd2c95cf37b1b2a1df41a8bb6fd1c8a47798fc31354
PIN .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-table-integration-review.md 22745 b8274e24432a4ae14a42a54e33bc77e58f0ca945a2409ad4897fcd4bde70d0c4
PIN .superpowers/sdd/2026-11-04-he-training-implementation-plan-m3-m5/task-54-r48-table-integration-fix1-report.md 91133 2be493e140a7f4a557036b16cc1779bd8f9f7c4c4e845c1f1c2a1183c59089ea
UNCHANGED r47_batch_input
UNCHANGED table_gpu
UNCHANGED r52_input
UNCHANGED read_r52_input
UNCHANGED table_accuracy
UNCHANGED table_ablation
UNCHANGED source_lines
UNCHANGED render_md
UNCHANGED render_tex
POPULATED_IDENTITY Markdown 9299 a9ef53fdcadd79846f5b0773de2b54c39753c35b21577f2902da7d03cef64986
POPULATED_IDENTITY TeX 9572 af5d5ca0d67705986191deac60350f2ec57400659f808f1e538854793d4c04ba
POPULATED_IDENTITY source_lines 58361 50a76fffa39790b0016ddd98902a9103fdb20fc1c1cf9613c221b50cba27e9b4
COMMAND ['python3', '-B', 'tools/paper_tables.py', '--check'] EXIT 0 STDOUT '' STDERR ''
COMMAND ['python3', '-B', 'tools/tables.py', '--check'] EXIT 0 STDOUT '' STDERR ''
COMMAND ['git', 'diff', '--check', '3090d1e6c71e38e8efb8e713a0d265b9d788b522', '--', 'tools/paper_tables.py', 'tools/test_paper_tables.py'] EXIT 0 STDOUT '' STDERR ''
```

The valid NAG GPU + NAG CPU L7 + CPU L31 fixture produced identical complete Markdown and TeX bytes before/after correction, matching the author's Markdown/TeX hashes. source_lines output was also equal; this harness serializes that list with LF joins and no final LF, so its byte hash is explicitly tied to the command above rather than an unspecified list serialization. R47/R52 intake/table functions, table_ablation itself, renderers and source-index function are source-identical. Both --check commands returned0 with no output, preserving existing generated files without writing them.

## Limits

Only this review file was written persistently. Tests/fixtures used explicit synthetic TemporaryDirectory paths; old source modules and rendering comparisons existed only in memory. No source edits, Git mutation, native/Rust/Cargo/SSH/server/GPU/HE execution, collector invocation, actual-result changes, or actual generated-table writes occurred.

This is the finite P2 rereview, continuing the initial pinned P48/queue/runner review; it does not claim another source/producer audit or native execution. The author-recorded RED8 failures are consistent with the prior independent reproducer; this reviewer independently ran the final52-method suite, the prior reproducer, identity harness and check-only commands.

Root separately reports byte identity of the exact combined R47/R48/R52 layout fixture against its previous PDF inputs. No PDF was built or viewed in this rereview, and this PASS does not independently repeat root's visual inspection. Scientific acceptance, historical consumed-input proof, independent counter/weight replay, R48-1 acceptance, real collection, full Task54 and other research gates remain outside scope. Synthetic regression and rendering identity are not actual research measurements.

