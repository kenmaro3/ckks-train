# R48 opposite CPU candidate fix1

Root review SHA b8274e24432a4ae14a42a54e33bc77e58f0ca945a2409ad4897fcd4bde70d0c4. Frozen initial source SHAf35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0; tests SHA73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0. Initial160586-byte report is retained unchanged.

## Test-first RED

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 1

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... ok
test_r48_capacity_skip_requires_the_actual_producer_marker (test_paper_tables.PaperTablesTests.test_r48_capacity_skip_requires_the_actual_producer_marker) ... ok
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... ok
test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported (test_paper_tables.PaperTablesTests.test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported) ... ok
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... ok
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... ok
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... ok
test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending) ... ok
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... ok
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... ok
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... ok
test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) ... 
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='table') ... FAIL
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='paper_tables.py') ... FAIL
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='tables.py') ... FAIL
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='generate') ... FAIL
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='table') ... FAIL
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='paper_tables.py') ... FAIL
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='tables.py') ... FAIL
  test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='generate') ... FAIL
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='table')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1111, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='paper_tables.py')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1117, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    self.assertEqual(p.returncode, 2, p.stdout)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2 : table	row	column	value	file	field	formula
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 1	results/ablation_cpu_smoke_small.json	configs[0].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[0].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[0].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 0	results/ablation_cpu_smoke_small.json	configs[1].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[1].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[1].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 1	results/ablation_cpu_smoke_small.json	configs[2].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[2].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[2].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 0	results/ablation_cpu_smoke_small.json	configs[3].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[3].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[3].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 1	results/ablation_cpu_smoke_small.json	configs[4].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[4].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[4].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 0	results/ablation_cpu_smoke_small.json	configs[5].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[5].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[5].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 1	results/ablation_cpu_smoke_small.json	configs[6].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[6].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[6].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 0	results/ablation_cpu_smoke_small.json	configs[7].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[7].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[7].max_abs_weight_diff_vs_default	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.optimizer	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.lanes_b	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.layout_d	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.start_level	
rq3_ablation	note 2			results/ablation_cpu_smoke_small.json	caveats[0]	
rq3_ablation	note 3			results/ablation_cpu_smoke_small.json	caveats[1]	
rq3_ablation	note 4			results/ablation_cpu_smoke_small.json	caveats[2]	
rq3_ablation	note 5			results/ablation_cpu_smoke_small.json	caveats[3]	


======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='tables.py')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1117, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    self.assertEqual(p.returncode, 2, p.stdout)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2 : table	row	column	value	file	field	formula
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 1	results/ablation_cpu_smoke_small.json	configs[0].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[0].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[0].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 0	results/ablation_cpu_smoke_small.json	configs[1].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[1].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[1].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 1	results/ablation_cpu_smoke_small.json	configs[2].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[2].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[2].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 0	results/ablation_cpu_smoke_small.json	configs[3].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[3].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[3].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 1	results/ablation_cpu_smoke_small.json	configs[4].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[4].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[4].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 0	results/ablation_cpu_smoke_small.json	configs[5].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[5].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[5].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 1	results/ablation_cpu_smoke_small.json	configs[6].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[6].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[6].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 0	results/ablation_cpu_smoke_small.json	configs[7].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[7].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[7].max_abs_weight_diff_vs_default	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.optimizer	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.lanes_b	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.layout_d	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.start_level	
rq3_ablation	note 2			results/ablation_cpu_smoke_small.json	caveats[0]	
rq3_ablation	note 3			results/ablation_cpu_smoke_small.json	caveats[1]	
rq3_ablation	note 4			results/ablation_cpu_smoke_small.json	caveats[2]	
rq3_ablation	note 5			results/ablation_cpu_smoke_small.json	caveats[3]	


======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='nag', consumer='generate')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1121, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    self.assertEqual(tables.main(['--root', str(self.root)]), 2)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2

======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='table')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1111, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    with self.assertRaises(tables.TableError):
         ~~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^
AssertionError: TableError not raised

======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='paper_tables.py')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1117, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    self.assertEqual(p.returncode, 2, p.stdout)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2 : table	row	column	value	file	field	formula
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 1	results/ablation_cpu_smoke_small.json	configs[0].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[0].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[0].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 0	results/ablation_cpu_smoke_small.json	configs[1].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[1].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[1].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 1	results/ablation_cpu_smoke_small.json	configs[2].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[2].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[2].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 0	results/ablation_cpu_smoke_small.json	configs[3].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[3].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[3].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 1	results/ablation_cpu_smoke_small.json	configs[4].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[4].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[4].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 0	results/ablation_cpu_smoke_small.json	configs[5].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[5].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[5].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 1	results/ablation_cpu_smoke_small.json	configs[6].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[6].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[6].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 0	results/ablation_cpu_smoke_small.json	configs[7].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[7].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[7].max_abs_weight_diff_vs_default	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.optimizer	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.lanes_b	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.layout_d	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.start_level	
rq3_ablation	note 2			results/ablation_cpu_smoke_small.json	caveats[0]	
rq3_ablation	note 3			results/ablation_cpu_smoke_small.json	caveats[1]	
rq3_ablation	note 4			results/ablation_cpu_smoke_small.json	caveats[2]	
rq3_ablation	note 5			results/ablation_cpu_smoke_small.json	caveats[3]	


======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='tables.py')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1117, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    self.assertEqual(p.returncode, 2, p.stdout)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2 : table	row	column	value	file	field	formula
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 1	results/ablation_cpu_smoke_small.json	configs[0].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[0].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[0].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[0].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[0].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 1 0	results/ablation_cpu_smoke_small.json	configs[1].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[1].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[1].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[1].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[1].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 1	results/ablation_cpu_smoke_small.json	configs[2].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[2].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[2].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[2].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[2].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	1 0 0	results/ablation_cpu_smoke_small.json	configs[3].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[3].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[3].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[3].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[3].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 1	results/ablation_cpu_smoke_small.json	configs[4].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	62	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	233	results/ablation_cpu_smoke_small.json	configs[4].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[4].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[4].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	0	results/ablation_cpu_smoke_small.json	configs[4].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 1 0	results/ablation_cpu_smoke_small.json	configs[5].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	171	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	285	results/ablation_cpu_smoke_small.json	configs[5].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[5].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[5].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.83e-09	results/ablation_cpu_smoke_small.json	configs[5].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 1	results/ablation_cpu_smoke_small.json	configs[6].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	101	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	311	results/ablation_cpu_smoke_small.json	configs[6].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[6].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[6].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	6.90e-09	results/ablation_cpu_smoke_small.json	configs[6].max_abs_weight_diff_vs_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Source	CPU smoke (insecure N = 2^12: counts only)	results/ablation_cpu_smoke_small.json	setup.params	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.device	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Backend / level	cpu, level max	results/ablation_cpu_smoke_small.json	backend.options.top_level	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	hoist bsgs lazy	0 0 0	results/ablation_cpu_smoke_small.json	configs[7].config	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Rotations	210	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.rotations	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Relins	114	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.relins	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	KS/iter	324	results/ablation_cpu_smoke_small.json	configs[7].counter_per_iteration.key_switches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Closed form	match	results/ablation_cpu_smoke_small.json	configs[7].closed_form_matches	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step median (s)	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_s_median	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Step / default	n/a (smoke)	results/ablation_cpu_smoke_small.json	configs[7].step_time_over_default	
rq3_ablation	CPU smoke (insecure N = 2^12: counts only)	Max |ΔW| vs default	7.39e-09	results/ablation_cpu_smoke_small.json	configs[7].max_abs_weight_diff_vs_default	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.optimizer	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.lanes_b	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.layout_d	
rq3_ablation	note 1			results/ablation_cpu_smoke_small.json	setup.start_level	
rq3_ablation	note 2			results/ablation_cpu_smoke_small.json	caveats[0]	
rq3_ablation	note 3			results/ablation_cpu_smoke_small.json	caveats[1]	
rq3_ablation	note 4			results/ablation_cpu_smoke_small.json	caveats[2]	
rq3_ablation	note 5			results/ablation_cpu_smoke_small.json	caveats[3]	


======================================================================
FAIL: test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) (selected='sgd', consumer='generate')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/Users/marconi/Documents/research/hekit/tools/test_paper_tables.py", line 1121, in test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically
    self.assertEqual(tables.main(['--root', str(self.root)]), 2)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 0 != 2

----------------------------------------------------------------------
Ran 52 tests in 6.750s

FAILED (failures=8)
```

## Finite correction and scope

When any CPU evidence is observed, the consumer now computes the selected canonical path from the already validated original optimizer record and rejects the opposite canonical candidate before asking job() to return a CPU record. The prior guard only ran after a record existed, so an opposite-only output without terminal files disappeared as pending. This fix changes only that guard's placement/dependency. It does not infer an attempted CPU job from a wrong variant or change the standalone-member ruling.

Both selected-NAG/present-SGD and selected-SGD/present-NAG negatives have no CPU terminal and no selected canonical output. They now fail TableError, both source entrypoints return2 with no source header/output, and generation returns2 with no partial output directories. Original wrong-candidate bytes remain untouched. Positive regressions retain original standalone NAG/SGD CPU, alias-only selected bytes with actual terminal association, failed-job unmeasured outcomes, true all-absent pending, and all previously adopted R47/R52/R48 tests.

Only the same two owned Python files and this separate fix report were written. Initial author report160586B/SHA366a81203504343a61a47dd2c95cf37b1b2a1df41a8bb6fd1c8a47798fc31354 and independent review SHA b8274e24432a4ae14a42a54e33bc77e58f0ca945a2409ad4897fcd4bde70d0c4 remain unchanged. No renderer, numerical threshold, provenance field, queue/producer/source pin, actual input/result, generated root output, Git mutation, native/Rust/Cargo/SSH/GPU/HE or subagent work occurred.

## Final GREEN / regressions / check-only verification

Command: `python3 -m unittest discover -s tools -p test_paper_tables.py -v`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch (test_paper_tables.PaperTablesTests.test_ablation_gpu_cpu_pair_requires_the_same_optimizer_level_layout_and_batch) ... ok
test_compatibility_entrypoint_regenerates_identical_canonical_tables (test_paper_tables.PaperTablesTests.test_compatibility_entrypoint_regenerates_identical_canonical_tables) ... ok
test_each_consumer_rejects_malformed_full (test_paper_tables.PaperTablesTests.test_each_consumer_rejects_malformed_full) ... ok
test_explicit_tex_note_override_keeps_markdown_default_and_sources (test_paper_tables.PaperTablesTests.test_explicit_tex_note_override_keeps_markdown_default_and_sources) ... ok
test_failed_full_writes_no_partial_files (test_paper_tables.PaperTablesTests.test_failed_full_writes_no_partial_files) ... ok
test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate (test_paper_tables.PaperTablesTests.test_full_parameter_error_is_sourced_diagnostic_not_accuracy_gate) ... ok
test_inline_caveat_table_is_readable_prose_in_tex (test_paper_tables.PaperTablesTests.test_inline_caveat_table_is_readable_prose_in_tex) ... ok
test_interactive_reference_never_populates_ni_d_or_ways (test_paper_tables.PaperTablesTests.test_interactive_reference_never_populates_ni_d_or_ways) ... ok
test_new_full_directory_rejects_runner_only_and_annotated_provenance (test_paper_tables.PaperTablesTests.test_new_full_directory_rejects_runner_only_and_annotated_provenance) ... ok
test_present_full1_accuracy_renders_pdftex_safe_non_gate (test_paper_tables.PaperTablesTests.test_present_full1_accuracy_renders_pdftex_safe_non_gate) ... ok
test_quick_tables_do_not_validate_or_label_smokes_as_full (test_paper_tables.PaperTablesTests.test_quick_tables_do_not_validate_or_label_smokes_as_full) ... ok
test_r47_absent_keeps_existing_generated_bytes (test_paper_tables.PaperTablesTests.test_r47_absent_keeps_existing_generated_bytes) ... ok
test_r47_compatibility_entrypoint_renders_same_success_table (test_paper_tables.PaperTablesTests.test_r47_compatibility_entrypoint_renders_same_success_table) ... ok
test_r47_failure_discards_partial_success_timings (test_paper_tables.PaperTablesTests.test_r47_failure_discards_partial_success_timings) ... ok
test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it (test_paper_tables.PaperTablesTests.test_r47_malformed_input_writes_no_generated_files_and_quick_ignores_it) ... ok
test_r47_overlay_excludes_future_archives_from_fixture_writes (test_paper_tables.PaperTablesTests.test_r47_overlay_excludes_future_archives_from_fixture_writes) ... ok
test_r47_rejects_partial_originals_and_alias_only_is_pending (test_paper_tables.PaperTablesTests.test_r47_rejects_partial_originals_and_alias_only_is_pending) ... ok
test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance (test_paper_tables.PaperTablesTests.test_r47_rejects_wrong_identity_or_inconsistent_terminal_provenance) ... ok
test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings (test_paper_tables.PaperTablesTests.test_r47_success_rejects_wrong_incomplete_duplicate_or_invalid_timings) ... ok
test_r47_success_six_rows_keep_statistics_and_actual_line_sources (test_paper_tables.PaperTablesTests.test_r47_success_six_rows_keep_statistics_and_actual_line_sources) ... ok
test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed (test_paper_tables.PaperTablesTests.test_r48_branch_conflicts_and_missing_nag_trigger_fail_closed) ... ok
test_r48_capacity_skip_requires_the_actual_producer_marker (test_paper_tables.PaperTablesTests.test_r48_capacity_skip_requires_the_actual_producer_marker) ... ok
test_r48_conditional_sgd_both_skip_and_failed_sgd_choices (test_paper_tables.PaperTablesTests.test_r48_conditional_sgd_both_skip_and_failed_sgd_choices) ... ok
test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported (test_paper_tables.PaperTablesTests.test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported) ... ok
test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu (test_paper_tables.PaperTablesTests.test_r48_cpu_only_uses_optimizer_record_without_manufacturing_gpu) ... ok
test_r48_full_alias_same_original_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r48_full_alias_same_original_and_both_entrypoints) ... ok
test_r48_future_archive_and_binary_overlay_write_isolation (test_paper_tables.PaperTablesTests.test_r48_future_archive_and_binary_overlay_write_isolation) ... ok
test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured (test_paper_tables.PaperTablesTests.test_r48_oom_watchdog_late_failure_and_output_rejection_are_unmeasured) ... ok
test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending (test_paper_tables.PaperTablesTests.test_r48_preceding_skip_and_missing_optional_members_remain_unmeasured_or_pending) ... ok
test_r48_registered_nag_pair_l31_context_and_sources (test_paper_tables.PaperTablesTests.test_r48_registered_nag_pair_l31_context_and_sources) ... ok
test_r48_rejects_bad_binary_flags_counts_stats_and_protocol (test_paper_tables.PaperTablesTests.test_r48_rejects_bad_binary_flags_counts_stats_and_protocol) ... ok
test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times (test_paper_tables.PaperTablesTests.test_r48_synthetic_pixel_fallback_is_visible_invalid_workload_without_times) ... ok
test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically (test_paper_tables.PaperTablesTests.test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically) ... ok
test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs (test_paper_tables.PaperTablesTests.test_r48_wrong_terminal_and_binary_provenance_fail_without_partial_outputs) ... ok
test_r52_error_atomicity_quick_and_both_entrypoints (test_paper_tables.PaperTablesTests.test_r52_error_atomicity_quick_and_both_entrypoints) ... ok
test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy (test_paper_tables.PaperTablesTests.test_r52_failed_watchdog_partial_never_publish_saved_success_accuracy) ... ok
test_r52_future_archive_and_result_overlay_isolation (test_paper_tables.PaperTablesTests.test_r52_future_archive_and_result_overlay_isolation) ... ok
test_r52_nonzero_errors_and_registered_input_prefix_validation (test_paper_tables.PaperTablesTests.test_r52_nonzero_errors_and_registered_input_prefix_validation) ... ok
test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow (test_paper_tables.PaperTablesTests.test_r52_partial_rounding_and_queue_rejection_preserve_original_control_flow) ... ok
test_r52_projection_and_stop_evidence_must_each_match_original_format (test_paper_tables.PaperTablesTests.test_r52_projection_and_stop_evidence_must_each_match_original_format) ... ok
test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs (test_paper_tables.PaperTablesTests.test_r52_projection_only_preserves_success_failure_watchdog_for_both_jobs) ... ok
test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero (test_paper_tables.PaperTablesTests.test_r52_queue_output_validation_failure_is_unmeasured_even_with_child_zero) ... ok
test_r52_registered_input_hash_failure_is_not_success (test_paper_tables.PaperTablesTests.test_r52_registered_input_hash_failure_is_not_success) ... ok
test_r52_rejects_missing_partial_or_inconsistent_original_terminal (test_paper_tables.PaperTablesTests.test_r52_rejects_missing_partial_or_inconsistent_original_terminal) ... ok
test_r52_run_all_alias_requires_same_terminal_originals_and_bytes (test_paper_tables.PaperTablesTests.test_r52_run_all_alias_requires_same_terminal_originals_and_bytes) ... ok
test_r52_success_models_validate_original_schema_and_seed_handoff_sources (test_paper_tables.PaperTablesTests.test_r52_success_models_validate_original_schema_and_seed_handoff_sources) ... ok
test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff (test_paper_tables.PaperTablesTests.test_r52_success_rejects_false_checks_wrong_provenance_scope_and_handoff) ... ok
test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes (test_paper_tables.PaperTablesTests.test_r52_tex_summarizes_only_hash_inventory_and_md_keeps_full_hashes) ... ok
test_same_cpu_timing_rejects_thread_mismatch (test_paper_tables.PaperTablesTests.test_same_cpu_timing_rejects_thread_mismatch) ... ok
test_synthetic_full_rows_and_accuracy_gate (test_paper_tables.PaperTablesTests.test_synthetic_full_rows_and_accuracy_gate) ... ok
test_twin_comparison_uses_the_same_seed_subset (test_paper_tables.PaperTablesTests.test_twin_comparison_uses_the_same_seed_subset) ... ok
test_zero_samples_fail_as_table_error (test_paper_tables.PaperTablesTests.test_zero_samples_fail_as_table_error) ... ok

----------------------------------------------------------------------
Ran 52 tests in 5.839s

OK
```

Command: `python3 tools/paper_tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `python3 tools/tables.py --check`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

Command: `git diff --check 3090d1e6c71e38e8efb8e713a0d265b9d788b522 -- tools/paper_tables.py tools/test_paper_tables.py`

Exit: 0

stdout (verbatim):
```text
```

stderr (verbatim):
```text
```

## Populated valid NAG-pair/L31 identity against frozen initial implementation

A stdlib-only harness loaded the exact frozen initial source into an isolated in-memory module, created tiny clearly synthetic valid NAG GPU + NAG CPU L7 + CPU L31 fixtures in one TemporaryDirectory, then built the table with each version and compared complete MD/TeX/source_lines outputs. No populated artifact was written to the repository. Baseline source SHA256 `f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0`. Harness exit0 and stderr empty. Exact comparison output:

```json
{
  "Markdown": {
    "byte_identical": true,
    "sha256": "a9ef53fdcadd79846f5b0773de2b54c39753c35b21577f2902da7d03cef64986",
    "bytes": 9299
  },
  "TeX": {
    "byte_identical": true,
    "sha256": "af5d5ca0d67705986191deac60350f2ec57400659f808f1e538854793d4c04ba",
    "bytes": 9572
  },
  "source_lines": {
    "identical": true,
    "rows": 499,
    "sha256": "4d9a0e1a37a0bf5e66881128c9b38602eeef5032fdfeee7bf627e90f55569830"
  }
}
```

The valid populated table bytes are unchanged, so this correction does not invalidate root's prior synthetic PDF table/layout evidence. This worker did not independently rebuild a PDF or reassert visual inspection.

## Final hashes / exact diff from frozen initial candidate

- `tools/paper_tables.py`: prior SHA256 `f35a659693eaaa1c2df068948c4f913adae4c8e852bd9dfae7003dda1dfe59c0`; final SHA256 `f7e3774f7124fe24e5a7a882df902ea7584aaa62ece7855a43def5d880af6b38`.

```diff
--- frozen-initial/tools/paper_tables.py
+++ fix1/tools/paper_tables.py
@@ -1033,9 +1033,11 @@
             # The deployed post-SGD choice uses rc/skip, without a status condition.
             expected_opt = 'nag' if sgd['rc'] == 3 and sgd['state']['skip'] else 'sgd'
     check(optimizer is None or expected_opt is None or optimizer == expected_opt, 'optimizer record contradicts present preceding jobs')
+    if cpu_seen:
+        selected_cpu = canonical('R-48-3', optimizer)
+        check(not any(present(rel) for rel in cpu_candidates if rel != selected_cpu), 'conflicting CPU optimizer output candidates')
     cpu = job('R-48-3', optimizer) if cpu_seen else None
     if cpu:
-        check(not any(present(rel) for rel in cpu_candidates if rel != cpu['canonical']), 'conflicting CPU optimizer output candidates')
         cpu['sources'].append((opt_rel, 'cpu_optimizer'))
     records = {'ABL-CUDA-L7': sgd or nag, 'ABL-CPU-L7': cpu, 'ABL-CPU-L31': job('R-48-4', 'nag')}
 
```
- `tools/test_paper_tables.py`: prior SHA256 `73b1774e32a34132af2313ad804e2ccda11d95e1291610f34979ecf1d31ed6d0`; final SHA256 `a791c10d58485b0262dae7aee70be390ac72d7d7ea15aa7416a773257d414402`.

```diff
--- frozen-initial/tools/test_paper_tables.py
+++ fix1/tools/test_paper_tables.py
@@ -1096,6 +1096,56 @@
             self.assertEqual(p.returncode,0,p.stderr)
             self.assertIn('R-48/R-48-2/post.txt',p.stdout)
 
+    def test_r48_wrong_cpu_candidate_without_terminal_is_rejected_atomically(self):
+        # Break caught: CPU detection sees both variants, but a missing selected variant used to hide the wrong one.
+        for selected, wrong in (('nag', 'sgd'), ('sgd', 'nag')):
+            put_r48_optimizer(self.root, selected)
+            filename = 'ablation_cpu_l7' + ('_sgd' if wrong == 'sgd' else '') + '.json'
+            candidate = self.root / 'results/quadruped' / filename
+            raw = b'{"SYNTHETIC":"wrong CPU variant without original terminal"}'
+            candidate.write_bytes(raw)
+            expected = self.root / 'results/quadruped' / ('ablation_cpu_l7' + ('_sgd' if selected == 'sgd' else '') + '.json')
+            self.assertFalse(expected.exists())
+            self.assertFalse((self.root / 'results/quadruped/raw/R-48/R-48-3').exists())
+            with self.subTest(selected=selected, consumer='table'):
+                with self.assertRaises(tables.TableError):
+                    self.build(tables.table_ablation)
+            for entry in ('paper_tables.py', 'tables.py'):
+                with self.subTest(selected=selected, consumer=entry):
+                    p = subprocess.run([sys.executable, str(ROOT / 'tools' / entry), '--root', str(self.root),
+                                        '--sources', 'rq3_ablation'], capture_output=True, text=True)
+                    self.assertEqual(p.returncode, 2, p.stdout)
+                    self.assertEqual(p.stdout, '')
+            with self.subTest(selected=selected, consumer='generate'):
+                with contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
+                    self.assertEqual(tables.main(['--root', str(self.root)]), 2)
+                self.assertFalse((self.root / 'paper').exists())
+                self.assertFalse((self.root / 'results/tables').exists())
+            self.assertEqual(candidate.read_bytes(), raw)
+            candidate.unlink()
+
+    def test_r48_cpu_alias_only_selected_bytes_and_failed_original_stay_supported(self):
+        # Break caught: rejecting a legitimate selected alias while moving the wrong-candidate guard.
+        alias = self.root / 'results/run_all/full/ablation_cpu_l7.json'
+        alias.parent.mkdir(parents=True)
+        for optimizer in ('nag', 'sgd'):
+            original, _ = put_r48(self.root, 'R-48-3', optimizer=optimizer)
+            put_r48_optimizer(self.root, optimizer)
+            alias.write_bytes(original.read_bytes())
+            original.unlink()
+            store = tables.Store(self.root)
+            table = tables.table_ablation(store, tables.Inputs(store, 'full'))
+            cpu = [r for r in rows(table) if r[0].startswith('CPU, n16_train, level 7')]
+            gpu = next(r for r in rows(table) if r[0].startswith('GPU,'))
+            self.assertEqual(len(cpu), 8)
+            self.assertIn('pending (R-48-2)', gpu)
+            alias.unlink()
+            put_r48(self.root, 'R-48-3', optimizer=optimizer, rc=1, output=False)
+            table = self.build(tables.table_ablation)
+            cpu = [r for r in rows(table) if r[0].startswith('CPU, n16_train, level 7')]
+            self.assertEqual(len(cpu), 1)
+            self.assertIn('failed/unmeasured', cpu[0][7])
+
     def test_r48_future_archive_and_binary_overlay_write_isolation(self):
         # Break caught: fixtures overwrite future actual R48 originals through symlinks.
         with tempfile.TemporaryDirectory() as source,tempfile.TemporaryDirectory() as fixture:
```

## Preserved function source and evidence

- `r47_batch_input`: exact source unchanged from frozen initial candidate.
- `table_gpu`: exact source unchanged from frozen initial candidate.
- `r52_input`: exact source unchanged from frozen initial candidate.
- `read_r52_input`: exact source unchanged from frozen initial candidate.
- `table_accuracy`: exact source unchanged from frozen initial candidate.
- `table_ablation`: exact source unchanged from frozen initial candidate.
- `source_lines`: exact source unchanged from frozen initial candidate.
- `render_md`: exact source unchanged from frozen initial candidate.
- `render_tex`: exact source unchanged from frozen initial candidate.
- Original source `results/quadruped/scripts/post_full_queue.py`: SHA256 `1a5f780070e004ec826f21b7dcc187d9e9a65d44e694f2cd5e2f1831589a78f9`.
- Original source `results/quadruped/scripts/run_job.sh`: SHA256 `46d2e83cc3b7ec175813eab9072b49f3eebc7b592125b71c6512315a2146c736`.

## Handoff / limits

52 focused methods pass with no unresolved failure. Both current --check entrypoints pass, preserving all current generated bytes with actual R48 evidence absent. Root independent re-review is still required before adoption. Real collection, consumed-input proof, independent counter/weight replay, scientific acceptance, full Task54 and other gates remain outside this finite validation correction. All populated fixtures and byte comparisons are synthetic; no real measurement or PDF publication is claimed.
